// src/App.tsx
import { useEffect, useState } from "react";
import { Layout, Menu, Spin } from "antd";
import { BrowserRouter, Routes, Route, Link, Navigate } from "react-router-dom";
import { GenericResourcePage } from "./components/GenericResourcePage";
import { GenericReportPage } from "./components/GenericReportPage";
import { AdminDashboard } from "./pages/AdminDashboard";
import { ThemeEditorDashboard } from "./pages/ThemeEditorDashboard";
import { Login } from "./pages/Login";
import { AppHeader } from "./components/AppHeader";
import { PrivateRoute } from "./components/PrivateRoute";
import { getSwaggerResources, SwaggerResource } from "./utils/swaggerResources";
import { pluralize } from "./Pluralize";
import { ThemeProvider } from "./contexts/ThemeContext";
import SystemFlowPage from "./components/SystemFlowPage";
import Drawer from "antd/lib/drawer";

const { Sider, Content } = Layout;

export const App = () => {
  const [menuData, setMenuData] = useState<any[]>([]);
  const [resources, setResources] = useState<SwaggerResource[]>([]);
  const [loading, setLoading] = useState(true);
//const [searchTerm, setSearchTerm] = useState("");
const [drawerOpen, setDrawerOpen] = useState(false);
const [searchResults, setSearchResults] = useState<any[]>([]);
  const token = localStorage.getItem("token");
  if (!token && window.location.pathname !== "/login") {
    return <div>Redirecting...</div>;
  }

  useEffect(() => {
    loadMenu();
    loadSwagger();
  }, []);

  // ------------------------------
  // Load Buckets & SubBuckets
  // ------------------------------
  const loadMenu = async () => {
    const [bucketsRes, subBucketsRes, bucketsRolesRes] = await Promise.all([
      fetch("http://localhost:3000/api/Buckets", {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      }),
      fetch("http://localhost:3000/api/SubBuckets", {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      }),
      fetch("http://localhost:3000/api/bucketsroles", {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      }),
    ]);

    const buckets = await bucketsRes.json();
    const subBuckets = await subBucketsRes.json();
    const bucketRoles = await bucketsRolesRes.json();
    const myrolep = localStorage.getItem("roleid");
const myrole = parseInt(myrolep);
const allowedBucketRoles = bucketRoles.filter(
  br => br.RoleId === myrole
);
const allowedBucketIds = allowedBucketRoles.map(br => br.BucketId);
console.log(JSON.stringify(allowedBucketIds));
    // const menu = buckets.map((bucket: any) => ({
    //   key: `bucket_${bucket.Id}`,
    //   label: bucket.Name,
    //   children: subBuckets
    //     .filter((sb: any) => sb.BucketId === bucket.Id)//bucket.Id
    //     .map((sb: any) => ({
    //       key: `/${sb.Name.toLowerCase()}`,
    //       label: <Link to={`/${sb.Name.toLowerCase()}`}>{sb.Name}</Link>,
    //     })),
    // }));
const menu = buckets
  .filter(bucket => allowedBucketIds.includes(bucket.Id))   // 🔥 Only allowed buckets
  .map(bucket => ({
    key: `bucket_${bucket.Id}`,
    label: bucket.Name,

    children: subBuckets
      .filter(sb => sb.BucketId === bucket.Id)              // 🔥 Only subbuckets under allowed bucket
      .map(sb => ({
        key: `/${sb.Name.toLowerCase()}`,
        label: <Link to={`/${sb.Name.toLowerCase()}`}>{sb.Name}</Link>,
      })),
  }));
    // Add Admin & Theme Editor at top
        menu.unshift({
      key: "/SystemFlow",
      label: <Link to="/SystemFlow">System Flow</Link>,
    });

    menu.unshift({
      key: "/theme-editor",
      label: <Link to="/theme-editor">Theme Editor</Link>,
    });
    menu.unshift({
      key: "/admin-dashboard",
      label: <Link to="/admin-dashboard">Admin Dashboard</Link>,
    });

    // Add logout item
    menu.push({
      key: "logout",
      label: <a onClick={() => logoutUser()}>Logout</a>,
    });

    setMenuData(menu);
  };

  // ------------------------------
  // Load Swagger Resources
  // ------------------------------
  const loadSwagger = async () => {
    const swagger = await getSwaggerResources();
    setResources(swagger);
    setLoading(false);
  };
const handleSearchChange = (value: string) => {
  setSearchTerm(value);

  if (!value.trim()) {
    setDrawerOpen(false);
    return;
  }

  let results: any[] = [];

  // Search dynamic menu links
  menuData.forEach((bucket) => {
    if (bucket.children) {
      bucket.children.forEach((sb) => {
        if (
          sb.label?.props?.children
            ?.toString()
            ?.toLowerCase()
            ?.includes(value.toLowerCase())
        ) {
          results.push({
            name: sb.label.props.children,
            route: sb.key,
          });
        }
      });
    }
  });

  // Search custom pages
  const staticRoutes = [
    { name: "Admin Dashboard", route: "/admin-dashboard" },
    { name: "Theme Editor", route: "/theme-editor" },
    { name: "System Flow", route: "/SystemFlow" },
  ];

  staticRoutes.forEach((r) => {
    if (r.name.toLowerCase().includes(value.toLowerCase())) {
      results.push(r);
    }
  });

  setSearchResults(results);
  setDrawerOpen(true);
};

  if (loading) return <Spin tip="Loading modules..." style={{ marginTop: 100 }} />;

  // ------------------------------
  // Helpers
  // ------------------------------
  const getFieldsFor = (name: string) => {
    const match = resources.find((r) => r.name.toLowerCase() === pluralize(name).toLowerCase());
    return match?.fields ?? [];
  };

  const getReportFieldsFor = (name: string) => {
    const match = resources.find((r) => r.name.toLowerCase() === name.toLowerCase());
    return match?.fields ?? [];
  };

  const logoutUser = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("username");
    window.location.href = "/login";
  };

  const moduleRoutes = menuData
    .flatMap((b) => b.children ?? [])
    .map((r) => ({ ...r, resourceName: r.key.replace("/", "") }));

  // ------------------------------
  // Render
  // ------------------------------
  return (
    <ThemeProvider>
      <BrowserRouter>
        <Layout style={{ minHeight: "100vh" }}>
          {/* Sidebar */}
          <Sider width={250} style={{ background: "var(--sidebar-bg)" }}>
             <PrivateRoute>
            <Menu mode="inline" style={{ background: "var(--sidebar-bg)" }} items={menuData} />
            </PrivateRoute>
          </Sider>

          {/* Main content */}
          <Layout>
            <AppHeader  onSearchChange={handleSearchChange} />
            <Content
              style={{
                background: "var(--background-color)",
                color: "var(--text-color)",
                minHeight: "100vh",
                padding: 20,
              }}
            >
              <Routes>
                <Route path="/login" element={<Login />} />

                <Route
                  path="/admin-dashboard"
                  element={
                    <PrivateRoute>
                      <AdminDashboard />
                    </PrivateRoute>
                  }
                />
                <Route
                  path="/theme-editor"
                  element={
                    <PrivateRoute>
                      <ThemeEditorDashboard />
                    </PrivateRoute>
                  }
                />
<Route
  path="/SystemFlow"
  element={
    <PrivateRoute>
      <SystemFlowPage />
    </PrivateRoute>
  }
/>
                {moduleRoutes.map((route: any) => {
                  const resourceName = route.resourceName;

                  if (resourceName.toLowerCase().includes("report")) {
                    return (
                      <Route
                        key={route.key}
                        path={route.key}
                        element={
                          <PrivateRoute>
                            <GenericReportPage
                              resourceName={resourceName}
                              apiBaseUrl="http://localhost:5017/api"
                              fields={getReportFieldsFor(resourceName)}
                            />
                          </PrivateRoute>
                        }
                      />
                    );
                  }

                  return (
                    <Route
                      key={route.key}
                      path={route.key}
                      element={
                        <PrivateRoute>
                          <GenericResourcePage
                            resourceName={resourceName}
                            apiBaseUrl="http://localhost:5017/api"
                            fields={getFieldsFor(resourceName)}
                          />
                        </PrivateRoute>
                      }
                    />
                  );
                })}

                <Route
                  path="/"
                  element={
                    <PrivateRoute>
                      <h2>Select a module</h2>
                    </PrivateRoute>
                  }
                />
              </Routes>
            </Content>
                {/* ✅ PUT DRAWER HERE (Not inside Routes, Not inside Content) */}
            <Drawer
              title="Search Results"
              placement="right"
              width={350}
              open={drawerOpen}
              onClose={() => setDrawerOpen(false)}
            >
              {searchResults.length === 0 ? (
                <p>No results found.</p>
              ) : (
                searchResults.map((item, index) => (
                  <div
                    key={index}
                    onClick={() => {
                      window.location.href = item.route;
                      setDrawerOpen(false);
                    }}
                    style={{
                      padding: 12,
                      background: "#f5f5f5",
                      borderRadius: 6,
                      marginBottom: 12,
                      cursor: "pointer",
                    }}
                  >
                    {item.name}
                  </div>
                ))
              )}
            </Drawer>
          </Layout>
        </Layout>
      </BrowserRouter>
    </ThemeProvider>
  );
};

export default App;
