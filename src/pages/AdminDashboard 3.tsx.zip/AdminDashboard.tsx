// src/pages/AdminDashboard.tsx
import React, { useContext, useEffect, useMemo, useState } from "react";
import {
  Table,
  Button,
  Select,
  message,
  Card,
  Row,
  Col,
  Popconfirm,
  Drawer,
  Form,
  Space,
} from "antd";
// Add these imports
import { SaveOutlined } from "@ant-design/icons";
import axios from "axios";  // For API calls (install if needed: npm i axios)
import {
  EditOutlined,
  DeleteOutlined,
  PlusCircleOutlined,    // Recommended — clean "add" icon with circle
  AppstoreAddOutlined,    // This one DOES exist
  DragOutlined,
} from "@ant-design/icons";  // ← Correct source
import {
  DollarOutlined,
  UserOutlined,
  FileTextOutlined,
  ShoppingCartOutlined,
} from "@ant-design/icons";
import { DragDropContext, Droppable, Draggable, DropResult } from "@hello-pangea/dnd";
import { WidgetModal } from "../components/WidgetModal";
import { ThemeContext } from "../contexts/ThemeContext";
import ThemeEditorDashboard from "./ThemeEditorDashboard";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
} from "recharts";

const { Option } = Select;

const DASHBOARD_ID = 2;
const WIDGET_HEIGHT_UNIT = 120;
const NUM_COLUMNS =2;

const CHART_COLORS = ["#a78bfa", "#8b5cf6", "#60a5fa", "#4c1d95", "#7c3aed", "#3b82f6"];

const widgetMeta: Record<number, { name: string; type: string }> = {
  1: { name: "Sales Chart", type: "Chart" },
  2: { name: "User Table", type: "Table" },
  3: { name: "KPI Card", type: "Card" },
  4: { name: "Revenue Chart", type: "Chart" },
};

 interface User { UserId: number; Username: string; Permissions: string[] }
interface Widget {
  DashboardWidgetId: number;
  DashboardId: number;
  WidgetId: number;
  WidgetName?: string;
  Type?: string;
  Settings: string;
  PositionX: number;
  PositionY: number;
  Width: number;
  Height: number;
}

interface Procedure {
  ProcedureId: number;
  ProcedureName: string;
}

export const AdminDashboard: React.FC = () => {
  const [widgets, setWidgets] = useState<Widget[]>([]);
  const [loading, setLoading] = useState(true);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [editingWidget, setEditingWidget] = useState<Widget | null>(null);
  const [form] = Form.useForm();
  const [procedures, setProcedures] = useState<Procedure[]>([]);
  const [selectedProc, setSelectedProc] = useState<number | null>(null);
  const [previewData, setPreviewData] = useState<any[]>([]);
  const [procParamsDef, setProcParamsDef] = useState<any[]>([]);
const [kpiData, setKpiData] = useState([]);  // Dynamic KPI array
          
                                    const [themes, setThemes] = useState<Theme[]>([]);
                                    const [selectedTheme, setSelectedTheme] = useState<number | null>(null);
                                    const [users, setUsers] = useState<User[]>([]);
                                   
  const themeCtx = useContext(ThemeContext);
const userId = localStorage.getItem("userid");  // From your auth
const apiBaseUrl = import.meta.env.VITE_API_BASE_URL;
  // // Placeholder for your actual data loading functions
  // const loadWidgets = async () => {
  //   // Your existing fetch logic
  //   setWidgets([]); // mock
  // };

  // const loadProcedures = async () => {
  //   // Your existing fetch logic
  //   setProcedures([]); // mock
  // };

  // const callProcAndGetResultSets = async (procName: string, params: Record<string, any>) => {
  //   // Your existing logic
  //   return [];
  // };
  //  const loadProcedures = async () => {
  //                                     try {
  //                                       const res = await fetch("http://localhost:5017/api/ProcedureMetadata");
  //                                       if (!res.ok) throw new Error(`HTTP ${res.status}`);
  //                                       const data = await res.json();
  //                                       const filtered: Procedure[] = (data || [])
  //                                         .filter((p: any) => p?.Id !== undefined)
  //                                         .map((p: any) => ({ ProcedureId: Number(p.Id), ProcedureName: String(p.ProcedureName) }));
  //                                       const distinctById = Array.from(new Map(filtered.map((p) => [p.ProcedureId, p])).values());
  //                                       distinctById.sort((a, b) => a.ProcedureName.localeCompare(b.ProcedureName, undefined, { sensitivity: "base" }));
  //                                       setProcedures(distinctById);
  //                                     } catch (err) {
  //                                       console.error("Failed to load procedures", err);
  //                                       setProcedures([]);
  //                                     }
  //                                   };

 

// Fetch dynamic KPIs and load saved dashboard

  // const fetchKPIs = async () => {
  //   try {
  //     const res = await axios.get("http://localhost:5017/api/stats");  // Your API endpoint
  //     setKpiData(res.data);  // e.g., [{ title: "Total Revenue", value: "$124,580", trend: "+12.5%", icon: "DollarOutlined" }, ...]
  //   } catch {
  //     message.error("Failed to load KPIs");
  //     setKpiData([ /* fallback mock data */ ]);
  //   }
  // };
const fetchKPIs = async () => {
  const userId = localStorage.getItem("userid");  // Get current user
  try {
    const res = await fetch(`${apiBaseUrl}/procedures/usp_userdashboard_crud`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        // Optional: Add Authorization if using JWT
        // Authorization: `Bearer ${localStorage.getItem("token")}`,
      },
      body: JSON.stringify({ Action: "READ", UserId: parseInt(userId || "0"), Config:"" , Result:""}),  // Send userId in body
    });

    if (!res.ok) {
      throw new Error(`HTTP ${res.status}`);
    }

    const json = await res.json();
    setKpiData(Array.isArray(json) ? json : [json]);  // Ensure it's an array
  } catch (err) {
    message.error("Failed to load KPIs");
    console.error(err);

    // Fallback mock data (same structure as real KPIs)
    // setKpiData([
    //   {
    //     title: "Total Revenue",
    //     value: "$0",
    //     trend: "0%",
    //     trendColor: "#94a3b8",
    //     iconComponent: <DollarOutlined />,
    //   },
    //   {
    //     title: "Active Users",
    //     value: "0",
    //     trend: "0%",
    //     trendColor: "#94a3b8",
    //     iconComponent: <UserOutlined />,
    //   },
    //   {
    //     title: "Open Invoices",
    //     value: "0",
    //     trend: "0%",
    //     trendColor: "#94a3b8",
    //     iconComponent: <FileTextOutlined />,
    //   },
    //   {
    //     title: "Pending Orders",
    //     value: "0",
    //     trend: "0%",
    //     trendColor: "#94a3b8",
    //     iconComponent: <ShoppingCartOutlined />,
    //   },
    // ]);
  }
};
  // const saveDashboard = async () => {
  //   const config = {
  //     kpiData,       // Save current KPIs
  //     widgets,       // Save widgets/layout
  //     // Add more (e.g., theme)
  //   };

  //   try {
  //     // Option 1: LocalStorage (client-side JSON)
  //     localStorage.setItem(`dashboard_${userId}`, JSON.stringify(config));

  //     // Option 2: Server JSON file (via API)
  //     // await axios.post("/api/dashboard/save-json", { userId, config });

  //     // Option 3: Database (recommended, via API)
  // //    await axios.post("/api/dashboard/save-db", { userId, config });

  //   const res = await fetch(`${apiBaseUrl}/procedures/usp_userdashboard_crud`, {
  //     method: "POST",
  //     headers: {
  //       "Content-Type": "application/json",
  //       // Optional: Add Authorization if using JWT
  //       // Authorization: `Bearer ${localStorage.getItem("token")}`,
  //     },
  //     body: JSON.stringify({ Action: "CREATE", UserId: parseInt(userId || "0"), Config:config , Result:""}),  // Send userId in body
  //   });
  //     message.success("Dashboard saved!");
  //   } catch {
  //     message.error("Failed to save");
  //   }
  // };

const saveDashboard = async () => {
  const userId = localStorage.getItem("userid");
  if (!userId) {
    message.error("User not logged in");
    return;
  }

  const config = {
    kpiData,   // Your current KPI array
    widgets,   // Your current widgets array
    // Add more later: theme, filters, etc.
  };

  try {
    const res = await fetch(`${apiBaseUrl}/procedures/usp_userdashboard_crud`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        // Uncomment if using JWT
        // Authorization: `Bearer ${localStorage.getItem("token")}`,
      },
      body: JSON.stringify({
        Action: "CREATE",                    // or "UPDATE" — same effect due to MERGE
        UserId: parseInt(userId),
        Config: config,                      // Direct object (will be serialized to JSON by backend if needed)
        Result: ""                           // Not needed for input
      }),
    });

    if (!res.ok) {
      const errorText = await res.text();
      throw new Error(errorText || "HTTP " + res.status);
    }

    // Optional: get response message
    const json = await res.json();
    message.success(json.Result || "Dashboard saved successfully!");
  } catch (err) {
    console.error("Save failed:", err);
    message.error("Failed to save dashboard");
  }
};
  // const loadDashboard = async () => {
  //   try {
  //     // Try localStorage first
  //     const localConfig = localStorage.getItem(`dashboard_${userId}`);
  //     if (localConfig) {
  //       const parsed = JSON.parse(localConfig);
  //       setKpiData(parsed.kpiData);
  //       setWidgets(parsed.widgets);
  //       return;
  //     }

  //     // Or fetch from server/DB
  //     const res = await axios.get(`/api/dashboard/load?userId=${userId}`);
  //     if (res.data) {
  //       setKpiData(res.data.kpiData);
  //       setWidgets(res.data.widgets);
  //     }
  //   } catch {
  //     message.error("Failed to load saved dashboard");
  //   }
  // };
//   const loadDashboard = async () => {
//   const userId = localStorage.getItem("userid");
//   if (!userId) return;

//   try {
//     const res = await fetch(`${apiBaseUrl}/procedures/sp_userdashboard_crud`, {
//       method: "POST",
//       headers: {
//         "Content-Type": "application/json",
//       },
//       body: JSON.stringify({
//         Action: "READ",
//         UserId: parseInt(userId),
//         Config: null,
//         Result: "",
//       }),
//     });

//     if (!res.ok) throw new Error("Failed to load dashboard");

//     const json = await res.json();

//     console.log("Raw response:", JSON.stringify(json)); // Your log — already working!

//     // Extract the Config string from the response
//     const configJsonString = Array.isArray(json) 
//       ? json[0]?.Config 
//       : json.Config || json[0];

//     if (configJsonString) {
//       try {
//         const savedConfig = JSON.parse(configJsonString);

//         // Restore widgets
//         if (Array.isArray(savedConfig.widgets)) {
//           setWidgets(savedConfig.widgets);
//         }

//         // Restore KPIs (if you save them in the future)
//         if (Array.isArray(savedConfig.kpiData)) {
//           setKpiData(savedConfig.kpiData);
//         }

//         message.success("Dashboard layout loaded successfully!");
//       } catch (parseErr) {
//         console.error("Failed to parse saved config:", parseErr);
//         message.warning("Saved layout corrupted — starting fresh");
//       }
//     }
//   } catch (err) {
//     console.error("Load dashboard failed:", err);
//     // Optional: don't show error if no saved dashboard yet
//     // message.info("No saved dashboard found");
//   }
// }; 
  const loadDashboard = async () => {
  const userId = localStorage.getItem("userid");
  if (!userId) return;

  try {
    const res = await fetch(`${apiBaseUrl}/procedures/sp_userdashboard_crud`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        Action: "READ",
        UserId: parseInt(userId),
        Config: null,
        Result: "",
      }),
    });

    if (!res.ok) throw new Error("Failed to load dashboard");

    const json = await res.json();

    console.log("Raw response:", JSON.stringify(json));

    const configJsonString = Array.isArray(json) 
      ? json[0]?.Config 
      : json.Config || json[0];

    if (configJsonString) {
      try {
        const savedConfig = JSON.parse(configJsonString);

        if (Array.isArray(savedConfig.widgets)) {
          setWidgets(savedConfig.widgets);
          message.success("Custom dashboard layout loaded!");
        }

        // Future: if you save kpiData too
        // if (Array.isArray(savedConfig.kpiData)) setKpiData(savedConfig.kpiData);
      } catch (parseErr) {
        console.error("Parse error:", parseErr);
        message.warning("Saved layout invalid — starting fresh");
      }
    }
  } catch (err) {
    console.error("Load failed:", err);
    // No error message — normal if no saved dashboard yet
  }
};
  useEffect(() => {
    loadDashboard();  // Load saved config first
    fetchKPIs();      // Then fetch fresh data
  }, []);

  useEffect(() => {
  const loadSavedDashboard = async () => {
    const userId = localStorage.getItem("userid");
    if (!userId) return;

    try {
      const res = await fetch(`${apiBaseUrl}/procedures/usp_userdashboard_crud`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          Action: "READ",
          UserId: parseInt(userId),
          Config: null,
          Result: "",
        }),
      });
console.log(JSON.stringify({
          Action: "READ",
          UserId: parseInt(userId),
          Config: null,
          Result: "",
        }));
      if (!res.ok) throw new Error("Failed to load saved dashboard");

      const json = await res.json();
       console.log('JSON.stringify(json)');
       console.log(JSON.stringify(json));
      // json.Result contains the saved Config as JSON string
      if (json.Result && json.Result.trim() !== "" && json.Result !== '{"kpiData":[],"widgets":[]}') {
        const savedConfig = JSON.parse(json.Result);

        // Restore KPIs and widgets
        if (Array.isArray(savedConfig.kpiData)) {
          setKpiData(savedConfig.kpiData);
        }
        if (Array.isArray(savedConfig.widgets)) {
          setWidgets(savedConfig.widgets);
        }

        message.success("Dashboard loaded from saved configuration");
      }
      // If no saved data, just keep current empty/default state
    } catch (err) {
      console.error("Failed to load saved dashboard:", err);
      // Don't show error — it's okay if user has no saved dashboard yet
      // Optionally: message.info("No saved dashboard found");
    }
  };

  loadSavedDashboard();
}, []);  // Empty dependency array → runs once on mount (including refresh)
// const loadWidgets = async () => {
//   try {
//     const res = await fetch(`...`);
//     const data = await res.json();
//     setWidgets(data || []);  // ← Critical: fallback to empty array
//   } catch (err) {
//     message.error("Failed to load widgets");
//     setWidgets([]);  // ← Never leave it undefined
//   }
// };
                                       const loadWidgets = async () => {
                                      try {
                                        const res = await fetch(`http://localhost:5017/api/dashboardwidgets?dashboardId=${DASHBOARD_ID}`);
                                        const data = await res.json();
                                        const enriched = (data || []).map((w: any) => ({
                                          ...w,
                                          WidgetName: w.WidgetName || widgetMeta[w.WidgetId]?.name || `Widget ${w.WidgetId}`,
                                          Type: w.Type || widgetMeta[w.WidgetId]?.type || "Unknown",
                                        }));
                                        setWidgets(enriched || []);
                                      } catch {
                                        message.error("Failed to load widgets");
                                         setWidgets([]);  // ← Never leave it undefined
                                      }
                                    };

                                    const loadThemes = async () => {
                                      try {
                                        const res = await fetch(`http://localhost:5017/api/themes`);
                                        setThemes(await res.json());
                                      } catch {
                                        message.error("Failed to load themes");
                                      }
                                    };

                                    const loadUsers = async () => {
                                      try {
                                        const res = await fetch(`http://localhost:5017/api/users`);
                                        setUsers(await res.json());
                                        setLoading(false);
                                      } catch {
                                        message.error("Failed to load users");
                                        setLoading(false);
                                      }
                                    };

                                    const loadDashboardTheme = async () => {
                                      try {
                                        const res = await fetch(`http://localhost:5017/api/themes?dashboardId=${DASHBOARD_ID}`);
                                        if (!res.ok) return;
                                        const theme = await res.json();
                                        if (theme?.settings && applyThemeToDOM) {
                                          setSelectedTheme(theme.themeId);
                                          applyThemeToDOM(JSON.parse(theme.settings));
                                        }
                                      } catch (err) {
                                        console.error("Failed to load theme", err);
                                      }
                                    };

                                    const loadProcedures = async () => {
                                      try {
                                        const res = await fetch("http://localhost:5017/api/ProcedureMetadata");
                                        if (!res.ok) throw new Error(`HTTP ${res.status}`);
                                        const data = await res.json();
                                        const filtered: Procedure[] = (data || [])
                                          .filter((p: any) => p?.Id !== undefined)
                                          .map((p: any) => ({ ProcedureId: Number(p.Id), ProcedureName: String(p.ProcedureName) }));
                                        const distinctById = Array.from(new Map(filtered.map((p) => [p.ProcedureId, p])).values());
                                        distinctById.sort((a, b) => a.ProcedureName.localeCompare(b.ProcedureName, undefined, { sensitivity: "base" }));
                                        setProcedures(distinctById);
                                      } catch (err) {
                                        console.error("Failed to load procedures", err);
                                        setProcedures([]);
                                      }
                                    };

                                    // -------------------- APPLY THEME --------------------
                                    const applyTheme = async () => {
                                      if (!selectedTheme || !applyThemeToDOM) return;
                                      try {
                                        const res = await fetch(`http://localhost:5017/api/themes`, {
                                          method: "POST",
                                          headers: { "Content-Type": "application/json" },
                                          body: JSON.stringify({ dashboardId: DASHBOARD_ID, themeId: selectedTheme }),
                                        });
                                        if (!res.ok) throw new Error();
                                        const data = await res.json();
                                        applyThemeToDOM(JSON.parse(data.settings));
                                        message.success("Theme applied!");
                                      } catch {
                                        message.error("Failed to apply theme");
                                      }
                                    };

      // useEffect(() => {
      //                                 loadWidgets();
      //                                 loadThemes();
      //                                 loadUsers();
      //                                 loadDashboardTheme();
      //                                 loadProcedures();
      //                                     setLoading(false);
      //                               }, []);

                                    useEffect(() => {
  loadDashboard();
  loadWidgets();       // Load default widgets if no saved layout
  loadProcedures();
  loadUsers();
  // ... other loads
  setLoading(false);
}, []);
                                  // interface ThemeEditorDashboardProps {
                                  //   onClose: () => void;
                                  // }
                                    // -------------------- DRAG & DROP --------------------
                                    const onDragEnd = async (result: DropResult) => {
                                      if (!result.destination) return;
                                      const reordered = Array.from(widgets);
                                      const [moved] = reordered.splice(result.source.index, 1);
                                      reordered.splice(result.destination.index, 0, moved);
                                      const updated = reordered.map((w, idx) => ({
                                        ...w,
                                        PositionX: idx % NUM_COLUMNS,
                                        PositionY: Math.floor(idx / NUM_COLUMNS),
                                      }));
                                      setWidgets(updated);

                                      try {
                                        await Promise.all(
                                          updated.map((w) =>
                                            fetch(`${apiBaseUrl}/dashboardwidgets/${w.DashboardWidgetId}`, {
                                              method: "PATCH",
                                              headers: { "Content-Type": "application/json" },
                                              body: JSON.stringify({
                                                DashboardWidgetId: w.DashboardWidgetId,
                                                PositionX: w.PositionX,
                                                PositionY: w.PositionY,
                                                Width: w.Width,
                                                Height: w.Height,
                                                Settings: w.Settings,
                                              }),
                                            })
                                          )
                                        );
                                        message.success("Layout saved");
                                      } catch {
                                        message.error("Failed to persist layout");
                                      }
                                    };

                                    // -------------------- CALL PROCEDURE --------------------
                                    const callProcAndGetResultSets = async (procName: string, params: Record<string, any>): Promise<any[]> => {
                                      try {
                                        let parameters = Object.keys(params || {}).map(k => params[k]).filter(v => v !== undefined && v !== null && v !== "").map(v => `'${v}'`).join(",");
                                        const res = await fetch(`${apiBaseUrl}/procedures/genericprocedure`, {
                                          method: "POST",
                                          headers: { "Content-Type": "application/json" },
                                          body: JSON.stringify({ ProcedureName: procName, Parameters: parameters }),
                                        });
                                        if (!res.ok) throw new Error(res.statusText);
                                        const data = await res.json();
                                        return Array.isArray(data) ? data : [data];
                                      } catch (err) {
                                        console.error("callProc error", err);
                                        return [];
                                      }
                                    };

                                    // -------------------- RENDER WIDGET --------------------
                                    const WidgetRenderer = ({ widget }: { widget: Widget }) => {
                                      const [data, setData] = useState<any[] | null>(null);
                                      const settings = useMemo(() => {
                                        try { return JSON.parse(widget.Settings || "{}"); } catch { return {}; }
                                      }, [widget.Settings]);

                                      useEffect(() => {
                                        let mounted = true;
                                        const fetchData = async () => {
                                          if (!settings.proc) return setData([]);
                                          const rs = await callProcAndGetResultSets(settings.proc, settings.params || {});
                                          if (mounted) setData(rs);
                                        };
                                        fetchData();
                                        return () => { mounted = false; };
                                      }, [widget.Settings]);

                                      const chartHeight = (widget.Height || 2) * WIDGET_HEIGHT_UNIT;
                                      const chartType = settings.chartType || "bar";
                                      const labelField = settings.labelField || detectLabelField(data);
                                      const valueField = settings.valueField || detectValueField(data);

                                      if (data === null) return <div style={{ height: chartHeight }}>Loading...</div>;
                                      if (!data || data.length === 0) return <div style={{ height: chartHeight, padding: 10 }}>No data</div>;

                                      switch (chartType) {
                                        case "bar":
                                          return (
                                            <div style={{ height: chartHeight }}>
                                              <ResponsiveContainer width="100%" height="100%">
                                                <BarChart data={data}>
                                                  <XAxis dataKey={labelField} />
                                                  <YAxis />
                                                  <Tooltip />
                                                  <Bar dataKey={valueField} fill="#1890ff" />
                                                </BarChart>
                                              </ResponsiveContainer>
                                            </div>
                                          );
                                        case "line":
                                          return (
                                            <div style={{ height: chartHeight }}>
                                              <ResponsiveContainer width="100%" height="100%">
                                                <LineChart data={data}>
                                                  <XAxis dataKey={labelField} />
                                                  <YAxis />
                                                  <Tooltip />
                                                  <Line dataKey={valueField} stroke="#1890ff" />
                                                </LineChart>
                                              </ResponsiveContainer>
                                            </div>
                                          );
                                        case "pie":
                                          return (
                                            <div style={{ height: chartHeight }}>
                                              <ResponsiveContainer width="100%" height="100%">
                                                <PieChart>
                                                  <Pie data={data} dataKey={valueField} nameKey={labelField} outerRadius={50}>
                                                    {data.map((_entry, idx) => <Cell key={idx} fill={`hsl(${(idx*50)%360},70%,50%)`} />)}
                                                  </Pie>
                                                </PieChart>
                                              </ResponsiveContainer>
                                            </div>
                                          );
                                        case "table": {
                                          const rows = Array.isArray(data) ? data : [data];
                                          if (!rows.length) return <div style={{ padding: 10 }}>No data</div>;
                                          const allKeys = Array.from(new Set(rows.flatMap(r => r ? Object.keys(r) : [])));
                                          const columns = allKeys.map(k => ({ title: k, dataIndex: k, key: k }));
                                          const dataSource = rows.map((r, idx) => ({ key: r?.Id ?? r?.UserId ?? idx, ...r }));
                                          return <div style={{ overflow: "auto", maxHeight: chartHeight }}><Table columns={columns} dataSource={dataSource} pagination={false} size="small" /></div>;
                                        }
                                        case "card":
                                          return <Card style={{ height: chartHeight, display: "flex", justifyContent: "center", alignItems: "center", fontSize: 24 }}>{data[0]?.[valueField]}</Card>;
                                        default:
                                          return <div style={{ height: chartHeight }}>Unsupported widget type</div>;
                                      }
                                    };

                                    function detectLabelField(rows: any[] | null) {
                                      if (!rows || !rows.length) return "name";
                                      const keys = Object.keys(rows[0]);
                                      const preferred = ["Month", "MonthName", "name", "label", "CustomerName", "InvoiceNumber"];
                                      return preferred.find(p => keys.includes(p)) || keys[0];
                                    }

                                    function detectValueField(rows: any[] | null) {
                                      if (!rows || !rows.length) return "value";
                                      const keys = Object.keys(rows[0]).filter(k => typeof rows[0][k] === "number" || !isNaN(Number(rows[0][k])));
                                      if (!keys.length) return Object.keys(rows[0])[0];
                                      const preferred = ["TotalSales", "TotalAmount", "Value", "Revenue", "Quantity", "Total"];
                                      return preferred.find(p => keys.includes(p)) || keys[0];
                                    }

                                    if (loading) return <div>Loading admin dashboard...</div>;
                        
  if (loading) {
    return <div style={{ padding: 40, textAlign: "center", color: "#94a3b8" }}>Loading dashboard...</div>;
  }

  return (
    <div style={{ padding: "24px 0" }}>

<Row gutter={[24, 24]} style={{ marginBottom: 32 }}>
  <Col xs={24} sm={12} md={6}>
    <Card
      hoverable
      style={{
        background: "rgba(30, 41, 59, 0.6)",
        backdropFilter: "blur(12px)",
        border: "1px solid rgba(167, 139, 250, 0.2)",
        borderRadius: 16,
        boxShadow: "0 8px 32px rgba(167, 139, 250, 0.1)",
        transition: "all 0.3s ease"
        
      }}
      styles={{
    body: {
      padding: "24px",
    },
  }}
    >
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div>
          <div style={{ fontSize: 14, color: "#94a3b8", marginBottom: 8 }}>Total Revenue</div>
          <div style={{ fontSize: 32, fontWeight: 700, color: "#e2e8f0" }}>$124,580</div>
          <div style={{ fontSize: 12, color: "#60a5fa", marginTop: 8 }}>+12.5% from last month</div>
        </div>
        <DollarOutlined style={{ fontSize: 48, color: "#a78bfa", opacity: 0.8 }} />
      </div>
    </Card>
  </Col>

  <Col xs={24} sm={12} md={6}>
    <Card
      hoverable
      style={{
        background: "rgba(30, 41, 59, 0.6)",
        backdropFilter: "blur(12px)",
        border: "1px solid rgba(96, 165, 250, 0.2)",
        borderRadius: 16,
        boxShadow: "0 8px 32px rgba(96, 165, 250, 0.1)",
        transition: "all 0.3s ease",
      }}
       styles={{
    body: {
      padding: "24px",
    },}}
    >
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div>
          <div style={{ fontSize: 14, color: "#94a3b8", marginBottom: 8 }}>Active Users</div>
          <div style={{ fontSize: 32, fontWeight: 700, color: "#e2e8f0" }}>2,847</div>
          <div style={{ fontSize: 12, color: "#60a5fa", marginTop: 8 }}>+8.2% from last month</div>
        </div>
        <UserOutlined style={{ fontSize: 48, color: "#60a5fa", opacity: 0.8 }} />
      </div>
    </Card>
  </Col>

  <Col xs={24} sm={12} md={6}>
    <Card
      hoverable
      style={{
        background: "rgba(30, 41, 59, 0.6)",
        backdropFilter: "blur(12px)",
        border: "1px solid rgba(167, 139, 250, 0.2)",
        borderRadius: 16,
        boxShadow: "0 8px 32px rgba(167, 139, 250, 0.1)",
        transition: "all 0.3s ease",
      }}
        styles={{
    body: {
      padding: "24px",
    },}}
    >
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div>
          <div style={{ fontSize: 14, color: "#94a3b8", marginBottom: 8 }}>Open Invoices</div>
          <div style={{ fontSize: 32, fontWeight: 700, color: "#e2e8f0" }}>142</div>
          <div style={{ fontSize: 12, color: "#f87171", marginTop: 8 }}>-3 due this week</div>
        </div>
        <FileTextOutlined style={{ fontSize: 48, color: "#a78bfa", opacity: 0.8 }} />
      </div>
    </Card>
  </Col>

  <Col xs={24} sm={12} md={6}>
    <Card
      hoverable
      style={{
        background: "rgba(30, 41, 59, 0.6)",
        backdropFilter: "blur(12px)",
        border: "1px solid rgba(96, 165, 250, 0.2)",
        borderRadius: 16,
        boxShadow: "0 8px 32px rgba(96, 165, 250, 0.1)",
        transition: "all 0.3s ease",
      }}
       styles={{
    body: {
      padding: "24px",
    },}}
    >
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div>
          <div style={{ fontSize: 14, color: "#94a3b8", marginBottom: 8 }}>Pending Orders</div>
          <div style={{ fontSize: 32, fontWeight: 700, color: "#e2e8f0" }}>89</div>
          <div style={{ fontSize: 12, color: "#60a5fa", marginTop: 8 }}>+19 new today</div>
        </div>
        <ShoppingCartOutlined style={{ fontSize: 48, color: "#60a5fa", opacity: 0.8 }} />
      </div>
    </Card>
  </Col>
</Row>
      {/* Top Action Bar */}
      <Row gutter={16} style={{ marginBottom: 24 }}>
        <Col>
          <Button
            type="primary"
            size="large"
            icon={<PlusCircleOutlined />}
            onClick={() => {
              setEditingWidget(null);
              form.resetFields();
              setModalVisible(true);
            }}
          >
            Add Widget
          </Button>

          <Button
  type="primary"
  size="large"
  icon={<SaveOutlined />}
  onClick={saveDashboard}
  style={{ marginLeft: 12 }}
>
  Save Dashboard
</Button>
        </Col>
        <Col>
          <Select
            style={{ width: 300 }}
            size="large"
            placeholder="Quick add from procedure..."
            onChange={(v) => {
              const proc = procedures.find((p) => p.ProcedureName === v);
              setSelectedProc(proc?.ProcedureId ?? null);
              setModalVisible(true);
            }}
          >
            {procedures.map((p) => (
              <Option key={p.ProcedureId} value={p.ProcedureName}>
                {p.ProcedureName.replace(/^sp_/i, "")}
              </Option>
            ))}
          </Select>
        </Col>
      </Row>

      {/* Main Grid */}
      <Row gutter={[24, 24]}>
        <Col span={18}>
          <Card title={<span style={{ fontWeight: 600, fontSize: 18 }}>Dashboard Widgets</span>}   styles={{
    body: {
      padding: "24px",
    },}}>
            <DragDropContext onDragEnd={onDragEnd}>
              <Droppable droppableId="widgets">
                {(provided) => (
                  <div
                    {...provided.droppableProps}
                    ref={provided.innerRef}
                    style={{
                      display: "grid",
                      gridTemplateColumns: `repeat(${NUM_COLUMNS}, 1fr)`,
                      gap: 24,
                      padding: 24,
                      minHeight: 400, // Optional: prevents layout jump
                    }}
                  >
                    {/* Safe check: only map if widgets is a valid array */}
  {Array.isArray(widgets) && widgets.length > 0 ? (
                    widgets.map((widget, index) => (
                      <Draggable key={widget.DashboardWidgetId} draggableId={String(widget.DashboardWidgetId)} index={index}>
                        {(provided, snapshot) => (
                          <div
                            ref={provided.innerRef}
                            {...provided.draggableProps}
                            style={{
                              ...provided.draggableProps.style,
                              transform: snapshot.isDragging ? provided.draggableProps.style?.transform : "translate(0px, 0px)",
                            }}
                          >
                            <Card
                              hoverable
                              style={{
                                borderRadius: 16,
                                overflow: "hidden",
                                boxShadow: snapshot.isDragging ? "0 20px 40px rgba(167, 139, 250, 0.3)" : undefined,
                                transition: "all 0.3s ease",
                              }}
                             styles={{
                                    header: {
                                      background: "linear-gradient(135deg, rgba(167, 139, 250, 0.15), rgba(96, 165, 250, 0.15))",
                                      borderBottom: "1px solid rgba(255,255,255,0.1)",
                                      padding: "16px 24px",  // Optional: match default padding
                                    },
                                    body: {
                                      padding: 16,
                                    },
                                  }}
                              title={<span style={{ fontWeight: 600 }}>{widget.WidgetName}</span>}
                              extra={
                                <Space {...provided.dragHandleProps} style={{ cursor: "grab" }}>
                                  <DragOutlined style={{ color: "#94a3b8", fontSize: 16 }} />
                                  <Button
                                    type="text"
                                    icon={<EditOutlined />}
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setEditingWidget(widget);
                                      // Parse settings and populate form
                                      const s = JSON.parse(widget.Settings || "{}");
                                      form.setFieldsValue({
                                        WidgetName: widget.WidgetName,
                                        procName: s.proc ?? "",
                                        chartType: s.chartType || "bar",
                                        // ... other fields
                                      });
                                      setModalVisible(true);
                                    }}
                                  />
                                  <Popconfirm
                                    title="Delete this widget?"
                                    onConfirm={(e) => {
                                      e?.stopPropagation();
                                      setWidgets((ws) => ws.filter((x) => x.DashboardWidgetId !== widget.DashboardWidgetId));
                                      // TODO: Delete from backend
                                      message.success("Widget deleted");
                                    }}
                                  >
                                    <Button type="text" danger icon={<DeleteOutlined />} onClick={(e) => e.stopPropagation()} />
                                  </Popconfirm>
                                </Space>
                              }
                            >
                              <div style={{ minHeight: (widget.Height || 3) * WIDGET_HEIGHT_UNIT - 80 }}>
                                <WidgetRenderer widget={widget} />
                              </div>
                            </Card>
                          </div>
                        )}
                      </Draggable>
                    ))) : (
    // Empty state — shown when no widgets
    <div
      style={{
        gridColumn: "1 / -1",
        textAlign: "center",
        padding: 80,
        color: "#94a3b8",
      }}
    >
      <AppstoreAddOutlined style={{ fontSize: 64, marginBottom: 16, opacity: 0.5 }} />
      <div style={{ fontSize: 18, marginBottom: 8 }}>No widgets yet</div>
      <div style={{ fontSize: 14 }}>Click "Add Widget" to create your first one</div>
    </div>
  )}
                    {provided.placeholder}
                  </div>
                )}
              </Droppable>
            </DragDropContext>
          </Card>
        </Col>

        {/* Sidebar */}
        <Col span={6}>
          <Card title="Theme Editor" style={{ marginBottom: 24 }}>
            <Button type="primary" block size="large" onClick={() => setDrawerOpen(true)}>
              Open Theme Editor
            </Button>
          </Card>

          <Card title="Users Overview">
            <Table size="small" pagination={false} />
          </Card>
        </Col>
      </Row>

      <Drawer title="Theme Editor" open={drawerOpen} placement="right" width="90%" onClose={() => setDrawerOpen(false)}>
        <ThemeEditorDashboard onClose={() => setDrawerOpen(false)} />
      </Drawer>

      <WidgetModal
        modalVisible={modalVisible}
        setModalVisible={setModalVisible}
        editingWidget={editingWidget}
        setEditingWidget={setEditingWidget}
        form={form}
        procParamsDef={procParamsDef}
        setProcParamsDef={setProcParamsDef}
        previewData={previewData}
        setPreviewData={setPreviewData}
        selectedProc={selectedProc}
        setSelectedProc={setSelectedProc}
        procedures={procedures}
        callProcAndGetResultSets={callProcAndGetResultSets}
        onSave={(w) => {
          setWidgets((ws) => {
            const idx = ws.findIndex((x) => x.DashboardWidgetId === w.DashboardWidgetId);
            if (idx >= 0) {
              const copy = [...ws];
              copy[idx] = w;
              return copy;
            }
            return [w, ...ws];
          });
          setModalVisible(false);
          setEditingWidget(null);
          form.resetFields();
        }}
      />
    </div>
  );
};
// // src/pages/AdminDashboard.tsx
                                  // import { useContext, useEffect, useMemo, useState } from "react";
                                  // import {
                                  //   Table,
                                  //   Button,
                                  //   Select,
                                  //   message,
                                  //   Card,
                                  //   Row,
                                  //   Col,
                                  //   Popconfirm,
                                  //   Drawer,
                                  //   Form
                                  // } from "antd";
                                  // import { DragDropContext, Droppable, Draggable, DropResult } from "@hello-pangea/dnd";
                                  // import { WidgetModal } from "../components/WidgetModal";
                                  // import { ThemeContext } from "../contexts/ThemeContext";
                                  // import ThemeEditorDashboard from "./ThemeEditorDashboard";
                                  // import {
                                  //   BarChart,
                                  //   Bar,
                                  //   XAxis,
                                  //   YAxis,
                                  //   Tooltip,
                                  //   ResponsiveContainer,
                                  //   LineChart,
                                  //   Line,
                                  //   PieChart,
                                  //   Pie,
                                  //   Cell
                                  // } from "recharts";
                                  // import React from "react";
                                  // interface ThemeContextType {
                                  //   applyThemeToDOM: (theme: any) => void;
                                  //   getComputedVar: (key: string) => string;
                                  //   // ...other properties
                                  // }
                                  // const { Option } = Select;
                                  // const DASHBOARD_ID = 2;
                                  // const WIDGET_HEIGHT_UNIT = 100;
                                  // const NUM_COLUMNS = 2;

                                  // // Fallback widget metadata
                                  // const widgetMeta: Record<number, { name: string; type: string }> = {
                                  //   1: { name: "Sales Chart", type: "Chart" },
                                  //   2: { name: "User Table", type: "Table" },
                                  //   3: { name: "KPI Card", type: "Card" },
                                  //   4: { name: "Revenue Chart", type: "Chart" },
                                  // };

                                  // // -------------------- TYPES --------------------
                                  // interface Widget {
                                  //   DashboardWidgetId: number;
                                  //   DashboardId: number;
                                  //   WidgetId: number;
                                  //   WidgetName?: string;
                                  //   Type?: string;
                                  //   Settings: string;
                                  //   PositionX: number;
                                  //   PositionY: number;
                                  //   Width: number;
                                  //   Height: number;
                                  // }

                                  // interface Theme { ThemeId: number; Name: string; Settings: string }
                                  // interface User { UserId: number; Username: string; Permissions: string[] }

                                  // interface ProcParam {
                                  //   name: string;
                                  //   type: "string" | "number";
                                  //   required: boolean;
                                  // }

                                  // interface Procedure {
                                  //   ProcedureId: number;
                                  //   ProcedureName: string;
                                  // }

                                  // export const AdminDashboard = () => {
                                  //   // -------------------- STATE --------------------
                                    // const [widgets, setWidgets] = useState<Widget[]>([]);
                                    // const [themes, setThemes] = useState<Theme[]>([]);
                                    // const [selectedTheme, setSelectedTheme] = useState<number | null>(null);
                                    // const [users, setUsers] = useState<User[]>([]);
                                    // const [loading, setLoading] = useState(true);
                                    // const [drawerOpen, setDrawerOpen] = useState(false);

                                    // const [modalVisible, setModalVisible] = useState(false);
                                    // const [editingWidget, setEditingWidget] = useState<Widget | null>(null);
                                    // const [form] = Form.useForm();

                                    // const [procedures, setProcedures] = useState<Procedure[]>([]);
                                    // const [procParamsDef, setProcParamsDef] = useState<ProcParam[]>([]);
                                    // const [previewData, setPreviewData] = useState<any[]>([]);
                                    // const [selectedProc, setSelectedProc] = useState<number | null>(null);

                                  //   // -------------------- THEME CONTEXT --------------------
                                  //   const ThemeContext = React.createContext<ThemeContextType>({
                                  //   applyThemeToDOM: () => {},
                                  //   getComputedVar: (key) => getComputedStyle(document.documentElement).getPropertyValue(`--${key}`),
                                  // });
                                  //   const themeCtx = useContext(ThemeContext);
                                  //   const applyThemeToDOM = themeCtx?.applyThemeToDOM;
                                  //   const _getComputedVar = themeCtx?.getComputedVar;

                                  //   // -------------------- EFFECTS --------------------
                                  //   useEffect(() => {
                                  //     loadWidgets();
                                  //     loadThemes();
                                  //     loadUsers();
                                  //     loadDashboardTheme();
                                  //     loadProcedures();
                                  //   }, []);
                                  // interface ThemeEditorDashboardProps {
                                  //   onClose: () => void;
                                  // }

                                  // const ThemeEditorDashboard = ({ onClose }: ThemeEditorDashboardProps) => {
                                  //   return (
                                  //     <div>
                                  //       <h2>Theme Editor</h2>
                                  //       <button onClick={onClose}>Close</button>
                                  //       {/* your theme editor UI */}
                                  //     </div>
                                  //   );
                                  // };
                                  //   // -------------------- LOAD DATA --------------------
                                    // const loadWidgets = async () => {
                                    //   try {
                                    //     const res = await fetch(`http://localhost:5017/api/dashboardwidgets?dashboardId=${DASHBOARD_ID}`);
                                    //     const data = await res.json();
                                    //     const enriched = (data || []).map((w: any) => ({
                                    //       ...w,
                                    //       WidgetName: w.WidgetName || widgetMeta[w.WidgetId]?.name || `Widget ${w.WidgetId}`,
                                    //       Type: w.Type || widgetMeta[w.WidgetId]?.type || "Unknown",
                                    //     }));
                                    //     setWidgets(enriched);
                                    //   } catch {
                                    //     message.error("Failed to load widgets");
                                    //   }
                                    // };

                                    // const loadThemes = async () => {
                                    //   try {
                                    //     const res = await fetch(`http://localhost:5017/api/themes`);
                                    //     setThemes(await res.json());
                                    //   } catch {
                                    //     message.error("Failed to load themes");
                                    //   }
                                    // };

                                    // const loadUsers = async () => {
                                    //   try {
                                    //     const res = await fetch(`http://localhost:5017/api/users`);
                                    //     setUsers(await res.json());
                                    //     setLoading(false);
                                    //   } catch {
                                    //     message.error("Failed to load users");
                                    //     setLoading(false);
                                    //   }
                                    // };

                                    // const loadDashboardTheme = async () => {
                                    //   try {
                                    //     const res = await fetch(`http://localhost:5017/api/themes?dashboardId=${DASHBOARD_ID}`);
                                    //     if (!res.ok) return;
                                    //     const theme = await res.json();
                                    //     if (theme?.settings && applyThemeToDOM) {
                                    //       setSelectedTheme(theme.themeId);
                                    //       applyThemeToDOM(JSON.parse(theme.settings));
                                    //     }
                                    //   } catch (err) {
                                    //     console.error("Failed to load theme", err);
                                    //   }
                                    // };

                                    // const loadProcedures = async () => {
                                    //   try {
                                    //     const res = await fetch("http://localhost:5017/api/ProcedureMetadata");
                                    //     if (!res.ok) throw new Error(`HTTP ${res.status}`);
                                    //     const data = await res.json();
                                    //     const filtered: Procedure[] = (data || [])
                                    //       .filter((p: any) => p?.Id !== undefined)
                                    //       .map((p: any) => ({ ProcedureId: Number(p.Id), ProcedureName: String(p.ProcedureName) }));
                                    //     const distinctById = Array.from(new Map(filtered.map((p) => [p.ProcedureId, p])).values());
                                    //     distinctById.sort((a, b) => a.ProcedureName.localeCompare(b.ProcedureName, undefined, { sensitivity: "base" }));
                                    //     setProcedures(distinctById);
                                    //   } catch (err) {
                                    //     console.error("Failed to load procedures", err);
                                    //     setProcedures([]);
                                    //   }
                                    // };

                                    // // -------------------- APPLY THEME --------------------
                                    // const applyTheme = async () => {
                                    //   if (!selectedTheme || !applyThemeToDOM) return;
                                    //   try {
                                    //     const res = await fetch(`http://localhost:5017/api/themes`, {
                                    //       method: "POST",
                                    //       headers: { "Content-Type": "application/json" },
                                    //       body: JSON.stringify({ dashboardId: DASHBOARD_ID, themeId: selectedTheme }),
                                    //     });
                                    //     if (!res.ok) throw new Error();
                                    //     const data = await res.json();
                                    //     applyThemeToDOM(JSON.parse(data.settings));
                                    //     message.success("Theme applied!");
                                    //   } catch {
                                    //     message.error("Failed to apply theme");
                                    //   }
                                    // };

                                    // // -------------------- DRAG & DROP --------------------
                                    // const onDragEnd = async (result: DropResult) => {
                                    //   if (!result.destination) return;
                                    //   const reordered = Array.from(widgets);
                                    //   const [moved] = reordered.splice(result.source.index, 1);
                                    //   reordered.splice(result.destination.index, 0, moved);
                                    //   const updated = reordered.map((w, idx) => ({
                                    //     ...w,
                                    //     PositionX: idx % NUM_COLUMNS,
                                    //     PositionY: Math.floor(idx / NUM_COLUMNS),
                                    //   }));
                                    //   setWidgets(updated);

                                    //   try {
                                    //     await Promise.all(
                                    //       updated.map((w) =>
                                    //         fetch(`http://localhost:5017/api/dashboardwidgets/${w.DashboardWidgetId}`, {
                                    //           method: "PATCH",
                                    //           headers: { "Content-Type": "application/json" },
                                    //           body: JSON.stringify({
                                    //             DashboardWidgetId: w.DashboardWidgetId,
                                    //             PositionX: w.PositionX,
                                    //             PositionY: w.PositionY,
                                    //             Width: w.Width,
                                    //             Height: w.Height,
                                    //             Settings: w.Settings,
                                    //           }),
                                    //         })
                                    //       )
                                    //     );
                                    //     message.success("Layout saved");
                                    //   } catch {
                                    //     message.error("Failed to persist layout");
                                    //   }
                                    // };

                                    // // -------------------- CALL PROCEDURE --------------------
                                    // const callProcAndGetResultSets = async (procName: string, params: Record<string, any>): Promise<any[]> => {
                                    //   try {
                                    //     let parameters = Object.keys(params || {}).map(k => params[k]).filter(v => v !== undefined && v !== null && v !== "").map(v => `'${v}'`).join(",");
                                    //     const res = await fetch(`http://localhost:5017/api/procedures/genericprocedure`, {
                                    //       method: "POST",
                                    //       headers: { "Content-Type": "application/json" },
                                    //       body: JSON.stringify({ ProcedureName: procName, Parameters: parameters }),
                                    //     });
                                    //     if (!res.ok) throw new Error(res.statusText);
                                    //     const data = await res.json();
                                    //     return Array.isArray(data) ? data : [data];
                                    //   } catch (err) {
                                    //     console.error("callProc error", err);
                                    //     return [];
                                    //   }
                                    // };

                                    // // -------------------- RENDER WIDGET --------------------
                                    // const WidgetRenderer = ({ widget }: { widget: Widget }) => {
                                    //   const [data, setData] = useState<any[] | null>(null);
                                    //   const settings = useMemo(() => {
                                    //     try { return JSON.parse(widget.Settings || "{}"); } catch { return {}; }
                                    //   }, [widget.Settings]);

                                    //   useEffect(() => {
                                    //     let mounted = true;
                                    //     const fetchData = async () => {
                                    //       if (!settings.proc) return setData([]);
                                    //       const rs = await callProcAndGetResultSets(settings.proc, settings.params || {});
                                    //       if (mounted) setData(rs);
                                    //     };
                                    //     fetchData();
                                    //     return () => { mounted = false; };
                                    //   }, [widget.Settings]);

                                    //   const chartHeight = (widget.Height || 2) * WIDGET_HEIGHT_UNIT;
                                    //   const chartType = settings.chartType || "bar";
                                    //   const labelField = settings.labelField || detectLabelField(data);
                                    //   const valueField = settings.valueField || detectValueField(data);

                                    //   if (data === null) return <div style={{ height: chartHeight }}>Loading...</div>;
                                    //   if (!data || data.length === 0) return <div style={{ height: chartHeight, padding: 10 }}>No data</div>;

                                    //   switch (chartType) {
                                    //     case "bar":
                                    //       return (
                                    //         <div style={{ height: chartHeight }}>
                                    //           <ResponsiveContainer width="100%" height="100%">
                                    //             <BarChart data={data}>
                                    //               <XAxis dataKey={labelField} />
                                    //               <YAxis />
                                    //               <Tooltip />
                                    //               <Bar dataKey={valueField} fill="#1890ff" />
                                    //             </BarChart>
                                    //           </ResponsiveContainer>
                                    //         </div>
                                    //       );
                                    //     case "line":
                                    //       return (
                                    //         <div style={{ height: chartHeight }}>
                                    //           <ResponsiveContainer width="100%" height="100%">
                                    //             <LineChart data={data}>
                                    //               <XAxis dataKey={labelField} />
                                    //               <YAxis />
                                    //               <Tooltip />
                                    //               <Line dataKey={valueField} stroke="#1890ff" />
                                    //             </LineChart>
                                    //           </ResponsiveContainer>
                                    //         </div>
                                    //       );
                                    //     case "pie":
                                    //       return (
                                    //         <div style={{ height: chartHeight }}>
                                    //           <ResponsiveContainer width="100%" height="100%">
                                    //             <PieChart>
                                    //               <Pie data={data} dataKey={valueField} nameKey={labelField} outerRadius={50}>
                                    //                 {data.map((_entry, idx) => <Cell key={idx} fill={`hsl(${(idx*50)%360},70%,50%)`} />)}
                                    //               </Pie>
                                    //             </PieChart>
                                    //           </ResponsiveContainer>
                                    //         </div>
                                    //       );
                                    //     case "table": {
                                    //       const rows = Array.isArray(data) ? data : [data];
                                    //       if (!rows.length) return <div style={{ padding: 10 }}>No data</div>;
                                    //       const allKeys = Array.from(new Set(rows.flatMap(r => r ? Object.keys(r) : [])));
                                    //       const columns = allKeys.map(k => ({ title: k, dataIndex: k, key: k }));
                                    //       const dataSource = rows.map((r, idx) => ({ key: r?.Id ?? r?.UserId ?? idx, ...r }));
                                    //       return <div style={{ overflow: "auto", maxHeight: chartHeight }}><Table columns={columns} dataSource={dataSource} pagination={false} size="small" /></div>;
                                    //     }
                                    //     case "card":
                                    //       return <Card style={{ height: chartHeight, display: "flex", justifyContent: "center", alignItems: "center", fontSize: 24 }}>{data[0]?.[valueField]}</Card>;
                                    //     default:
                                    //       return <div style={{ height: chartHeight }}>Unsupported widget type</div>;
                                    //   }
                                    // };

                                    // function detectLabelField(rows: any[] | null) {
                                    //   if (!rows || !rows.length) return "name";
                                    //   const keys = Object.keys(rows[0]);
                                    //   const preferred = ["Month", "MonthName", "name", "label", "CustomerName", "InvoiceNumber"];
                                    //   return preferred.find(p => keys.includes(p)) || keys[0];
                                    // }

                                    // function detectValueField(rows: any[] | null) {
                                    //   if (!rows || !rows.length) return "value";
                                    //   const keys = Object.keys(rows[0]).filter(k => typeof rows[0][k] === "number" || !isNaN(Number(rows[0][k])));
                                    //   if (!keys.length) return Object.keys(rows[0])[0];
                                    //   const preferred = ["TotalSales", "TotalAmount", "Value", "Revenue", "Quantity", "Total"];
                                    //   return preferred.find(p => keys.includes(p)) || keys[0];
                                    // }

                                    // if (loading) return <div>Loading admin dashboard...</div>;

                                  //   return (
                                  //     <div>
                                  //       <Row gutter={8} style={{ background: "var(--background-bg)", marginBottom: 16 }}>
                                  //         <Col>
                                  //           <Button type="primary" onClick={() => { setEditingWidget(null); form.resetFields(); setPreviewData([]); setSelectedProc(null); setModalVisible(true); }}>
                                  //             Add / Configure Widget
                                  //           </Button>
                                  //         </Col>
                                  //         <Col>
                                  //           <Select style={{ width: 240 }} placeholder="Quick-add proc" onChange={(v) => { const proc = procedures.find(p => p.ProcedureName === v); setSelectedProc(proc?.ProcedureId ?? null); form.setFieldsValue({ procId: proc?.ProcedureId ?? null, procName: proc?.ProcedureName ?? "" }); setModalVisible(true); }}>
                                  //             {procedures.length > 0 ? procedures.map(p => <Option key={p.ProcedureId} value={p.ProcedureName}>{p.ProcedureName.replace(/^sp_/i,"")}</Option>) : <Option key="manual" value="">(manual entry)</Option>}
                                  //           </Select>
                                  //         </Col>
                                  //       </Row>

                                  //       <Row gutter={16}>
                                  //         <Col span={16}>
                                  //           <Card title="Dashboard Widgets">
                                  //             <DragDropContext onDragEnd={onDragEnd}>
                                  //               <Droppable droppableId="widgets">
                                  //                 {(prov) => (
                                  //                   <div ref={prov.innerRef} {...prov.droppableProps} style={{ display: "grid", gridTemplateColumns: `repeat(${NUM_COLUMNS},1fr)`, gap: 12 }}>
                                  //                     {widgets.map((w, idx) => (
                                  //                       <Draggable key={w.DashboardWidgetId} draggableId={String(w.DashboardWidgetId)} index={idx}>
                                  //                         {(p) => (
                                  //                           <div ref={p.innerRef} {...p.draggableProps} {...p.dragHandleProps} style={{ background: "#fff", border: "1px solid #ddd", padding: 10, ...p.draggableProps.style }}>
                                  //                             <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                                  //                               <strong>{w.WidgetName}</strong>
                                  //                               <div>
                                  //                                 <Button size="small" style={{ marginRight: 6 }} onClick={() => {
                                  //                                   setEditingWidget(w);
                                  //                                   const s = JSON.parse(w.Settings || "{}");
                                  //                                   const proc = procedures.find(p => p.ProcedureName === s.proc);
                                  //                                   setSelectedProc(proc?.ProcedureId ?? null);
                                  //                                   form.setFieldsValue({
                                  //                                     WidgetName: w.WidgetName,
                                  //                                     procId: proc?.ProcedureId ?? null,
                                  //                                     procName: s.proc ?? "",
                                  //                                     params: s.params || {},
                                  //                                     chartType: s.chartType || "bar",
                                  //                                     labelField: s.labelField || "",
                                  //                                     valueField: s.valueField || ""
                                  //                                   });
                                  //                                   setPreviewData([]);
                                  //                                   setModalVisible(true);
                                  //                                 }}>Edit</Button>
                                  //                                 <Popconfirm title="Delete?" onConfirm={() => setWidgets(ws => ws.filter(x => x.DashboardWidgetId !== w.DashboardWidgetId))} okText="Yes" cancelText="No">
                                  //                                   <Button size="small" danger>Delete</Button>
                                  //                                 </Popconfirm>
                                  //                               </div>
                                  //                             </div>
                                  //                             <WidgetRenderer widget={w} />
                                  //                           </div>
                                  //                         )}
                                  //                       </Draggable>
                                  //                     ))}
                                  //                     {prov.placeholder}
                                  //                   </div>
                                  //                 )}
                                  //               </Droppable>
                                  //             </DragDropContext>
                                  //           </Card>
                                  //         </Col>

                                  //         <Col span={8}>
                                  //           <Card title="Themes">
                                  //             <Button type="primary" onClick={() => setDrawerOpen(true)} block>Theme Editor</Button>
                                  //           </Card>
                                  //           <Card title="Users" style={{ marginTop: 16 }}>
                                  //             <Table
                                  //               dataSource={users}
                                  //               rowKey="UserId"
                                  //               columns={[
                                  //                 { title: "User", dataIndex: "Username" },
                                  //                 { title: "Perms", dataIndex: "Permissions", render: (p: string[]) => p?.join(", ") },
                                  //               ]}
                                  //               pagination={false}
                                  //             />
                                  //           </Card>
                                  //         </Col>
                                  //       </Row>

                                  //       <Drawer title="Theme Editor" open={drawerOpen} placement="right" width="90%" onClose={() => setDrawerOpen(false)}>
                                  //         <ThemeEditorDashboard onClose={() => setDrawerOpen(false)} />
                                  //       </Drawer>

                                  //       <WidgetModal
                                  //         modalVisible={modalVisible}
                                  //         setModalVisible={setModalVisible}
                                  //         editingWidget={editingWidget}
                                  //         setEditingWidget={setEditingWidget}
                                  //         form={form}
                                  //         procParamsDef={procParamsDef}
                                  //         setProcParamsDef={setProcParamsDef}
                                  //         previewData={previewData}
                                  //         setPreviewData={setPreviewData}
                                  //         selectedProc={selectedProc}
                                  //         setSelectedProc={setSelectedProc}
                                  //         procedures={procedures}
                                  //         callProcAndGetResultSets={callProcAndGetResultSets}
                                  //         onSave={(w) => {
                                  //           setWidgets(ws => {
                                  //             const idx = ws.findIndex(x => x.DashboardWidgetId === w.DashboardWidgetId);
                                  //             if (idx >= 0) { const copy = [...ws]; copy[idx] = w; return copy; } 
                                  //             return [w, ...ws];
                                  //           });
                                  //           setModalVisible(false);
                                  //           setEditingWidget(null);
                                  //           form.resetFields();
                                  //         }}
                                  //       />
                                  //     </div>
                                  //   );
                                  // };

// // src/pages/AdminDashboard.tsx
// import { useContext, useEffect, useMemo, useState } from "react";
// import {
//   Table,
//   Button,
//   Select,
//   message,
//   Card,
//   Row,
//   Col,
//   Popconfirm,
//   Drawer,
//   Form
// } from "antd";
// import { DragDropContext, Droppable, Draggable, DropResult } from "@hello-pangea/dnd";
// import { WidgetModal } from "../components/WidgetModal";
// import { fetchAllThemes } from "../api/themeApi";
// import { useTheme } from "../contexts/ThemeContext";
// import {
//   BarChart,
//   Bar,
//   XAxis,
//   YAxis,
//   Tooltip,
//   ResponsiveContainer,
//   LineChart,
//   Line,
//   PieChart,
//   Pie,
//   Cell
// } from "recharts";
// import { ThemeContext } from "../contexts/ThemeContext";
// import ThemeEditorDashboard from "./ThemeEditorDashboard";


// //const { applyThemeToDOM } = useContext(ThemeContext);

// const { Option } = Select;
// const DASHBOARD_ID = 2;
// const WIDGET_HEIGHT_UNIT = 100;
// const NUM_COLUMNS = 2;

// // fallback widget metadata
// const widgetMeta: Record<number, { name: string; type: string }> = {
//   1: { name: "Sales Chart", type: "Chart" },
//   2: { name: "User Table", type: "Table" },
//   3: { name: "KPI Card", type: "Card" },
//   4: { name: "Revenue Chart", type: "Chart" },
// };

// interface Widget {
//   DashboardWidgetId: number;
//   DashboardId: number;
//   WidgetId: number;
//   WidgetName?: string;
//   Type?: string;
//   Settings: string;
//   PositionX: number;
//   PositionY: number;
//   Width: number;
//   Height: number;
// }

// interface Theme { ThemeId: number; Name: string; Settings: string }
// interface User { UserId: number; Username: string; Permissions: string[] }
// interface ThemeContextType {
//   applyThemeToDOM: (theme: any) => void;
//   getComputedVar: (key: string) => string;
//   // ...other properties
// }

// interface Procedure {
//   Id: number;
//   ProcedureName: string;
// }

// export const AdminDashboard = () => {
//   const [widgets, setWidgets] = useState<Widget[]>([]);
//   const [themes, setThemes] = useState<Theme[]>([]);
//   const [selectedTheme, setSelectedTheme] = useState<number | null>(null);
//   const [users, setUsers] = useState<User[]>([]);
//   const [loading, setLoading] = useState(true);
//   const { applyThemeToDOM, getComputedVar } = useContext(ThemeContext);
// const [drawerOpen, setDrawerOpen] = useState(false);

//   const [modalVisible, setModalVisible] = useState(false);
//   const [editingWidget, setEditingWidget] = useState<Widget | null>(null);
//   const [form] = Form.useForm();

//   // NOTE: procedures is an array of Procedure objects (id + name)
//   const [procedures, setProcedures] = useState<Procedure[]>([]);
//   const [procParamsDef, setProcParamsDef] = useState<
//     Array<{ name: string; type: string; required: boolean }>
//   >([]);
//   const [previewData, setPreviewData] = useState<any[]>([]);
//   // selectedProc is the ProcedureId (number) or null
//   const [selectedProc, setSelectedProc] = useState<string | null>(null);

// /*
// const applyThemeToDOM = (settingsJson: string) => {
//   if (!settingsJson) return;

//   let settings;
//   try {
//     settings = JSON.parse(settingsJson);
//   } catch {
//     console.error("Invalid theme settings");
//     return;
//   }

//   const root = document.documentElement;

//   Object.keys(settings).forEach(key => {
//     root.style.setProperty(`--${key}`, settings[key]);
//   });
// };
// */
// const applyTheme = async () => {
//   if (!selectedTheme) return;
// console.log( JSON.stringify({
//         dashboardId: DASHBOARD_ID,
//         themeId: selectedTheme,
//       }));
//   try {
//     // Save selected theme
//     const res = await fetch(`http://localhost:5017/api/themes`, {
//       method: "POST",
//       headers: { "Content-Type": "application/json" },
//       body: JSON.stringify({
//         dashboardId: DASHBOARD_ID,
//         themeId: selectedTheme,
//       }),
//     });

//     if (!res.ok) throw new Error();

//     const data = await res.json(); // includes settings JSON
//     applyThemeToDOM(JSON.parse(data.settings));

//     message.success("Theme applied!");
//   } catch {
//     message.error("Failed to apply theme");
//   }
// };

// //   const loadDashboardTheme = async () => {
// //   try {
// //     const res = await fetch(
// //       `http://localhost:5017/api/theme?dashboardId=${DASHBOARD_ID}`
// //     );
// //     if (!res.ok) return;

// //     const theme = await res.json(); // { themeId, settings }
// //     setSelectedTheme(theme.themeId);
// //     applyThemeToDOM(theme.settings);
// //   } catch (err) {
// //     console.error("Failed to load dashboard theme", err);
// //   }
// // };



// //loadDashboardTheme(); // <-- ADD THIS

//   // -------------------- Load initial data --------------------
//   useEffect(() => {
//     loadWidgets();
//     loadThemes();
//     loadUsers();

//       loadDashboardTheme();  // <-- ADD THIS
//     loadProcedures();
//   }, []);
// const loadDashboardTheme = async () => {
//   try {
//     const res = await fetch(
//       `http://localhost:5017/api/themes?dashboardId=${DASHBOARD_ID}`
//     );

//     if (!res.ok) return;

//     const theme = await res.json();

//     if (theme?.settings) {
//       setSelectedTheme(theme.themeId);
//       applyThemeToDOM(JSON.parse(theme.settings));
//     }
//   } catch (err) {
//     console.error("Failed to load theme", err);
//   }
// };
//   const loadProcedures = async () => {
//     try {
//       const res = await fetch("http://localhost:5017/api/ProcedureMetadata");
//       if (!res.ok) throw new Error(`HTTP ${res.status}`);
//       const data = await res.json(); // expect array of { ProcedureId, ProcedureName, ... }
// //console.log(JSON.stringify(data));
//       // Ensure items have ProcedureId and ProcedureName, remove duplicates by ProcedureId
//       const filtered = (data || [])
//         .filter((p: any) => p && (p.Id !== undefined && p.Id !== null))
//       .map((p: any) => ({ ProcedureId: Number(p.Id), ProcedureName: String(p.ProcedureName) }));
//         console.log(JSON.stringify(filtered));
//       // Remove duplicates by ProcedureId (keep first)
//       const distinctById = Array.from(new Map(filtered.map((p: Procedure) => [p.ProcedureName, p])).values());

//       distinctById.sort((a, b) => a.ProcedureName.localeCompare(b.ProcedureName, undefined, { sensitivity: "base" }));

//       setProcedures(distinctById);
//     } catch (err) {
//       console.error("Failed to load procedures", err);
//       setProcedures([]);
//     }
//   };

//   const loadWidgets = async () => {
//     try {
//       const res = await fetch(
//         `http://localhost:5017/api/dashboardwidgets?dashboardId=${DASHBOARD_ID}`
//       );
//       const data = await res.json();
//       const enriched = (data || []).map((w: any) => ({
//         ...w,
//         WidgetName: w.WidgetName || widgetMeta[w.WidgetId]?.name || `Widget ${w.WidgetId}`,
//         Type: w.Type || widgetMeta[w.WidgetId]?.type || "Unknown",
//       }));
//       setWidgets(enriched);
//     } catch {
//       message.error("Failed to load widgets");
//     }
//   };

//   const loadThemes = async () => {
//     try {
//       const res = await fetch(`http://localhost:5017/api/themes`);
//       setThemes(await res.json());
//     } catch {
//       message.error("Failed to load themes");
//     }
//   };

//   const loadUsers = async () => {
//     try {
//       const res = await fetch(`http://localhost:5017/api/users`);
//       setUsers(await res.json());
//       setLoading(false);
//     } catch {
//       message.error("Failed to load users");
//       setLoading(false);
//     }
//   };

// //   const applyTheme = async () => {
// //     if (!selectedTheme) return;
// //     try {
// //       await fetch(`http://localhost:5017/api/theme`, {
// //         method: "PUT",
// //         headers: { "Content-Type": "application/json" },
// //         body: JSON.stringify({ dashboardId: DASHBOARD_ID, themeId: selectedTheme }),
// //       });
// //       message.success("Theme applied!");
// //     } catch {
// //       message.error("Failed to apply theme");
// //     }
// //   };

//   // -------------------- Drag & drop --------------------
//   const onDragEnd = async (result: DropResult) => {
//     if (!result.destination) return;
//     const reordered = Array.from(widgets);
//     const [moved] = reordered.splice(result.source.index, 1);
//     reordered.splice(result.destination.index, 0, moved);
//     const updated = reordered.map((w, idx) => ({
//       ...w,
//       PositionX: idx % NUM_COLUMNS,
//       PositionY: Math.floor(idx / NUM_COLUMNS),
//     }));
//     setWidgets(updated);

//     try {
//       await Promise.all(
//         updated.map((w) =>
//           fetch(`http://localhost:5017/api/dashboardwidgets/${w.DashboardWidgetId}`, {
//             method: "PATCH",
//             headers: { "Content-Type": "application/json" },
//             body: JSON.stringify({
//               DashboardWidgetId: w.DashboardWidgetId,
//               PositionX: w.PositionX,
//               PositionY: w.PositionY,
//               Width: w.Width,
//               Height: w.Height,
//               Settings: w.Settings,
//             }),
//           })
//         )
//       );
//       message.success("Layout saved");
//     } catch {
//       message.error("Failed to persist layout");
//     }
//   };

//   // -------------------- Helper: call proc --------------------
//   const callProcAndGetResultSets = async (procName: string, params: Record<string, any>) => {
//     try {
//       const qs = new URLSearchParams();
//       let parameters ="";
//       let m = 0;
//       Object.keys(params || {}).forEach((k) => {
//         const v = params[k];
//         if (v !== undefined && v !== null && v !== "") qs.set(k, String(v));
//         if( m == 0) { m++;  parameters = "'"+String(v)+"'";}
//         else
//         {
//             m++;  parameters = parameters +",'"+ String(v)+"'";
//         }
//        // if(k == 0) { parameters = }
//       //  parameters =  parameters +',' +v;
//       });
//     //   const url = `http://localhost:5017/api/procedures/${encodeURIComponent(procName)}${qs.toString() ? `?${qs.toString()}` : ""}`;
//     //   const res = await fetch(url);
// console.log( JSON.stringify({ ProcedureName: procName , Parameters: parameters}));
//        const res = await fetch(`http://localhost:5017/api/procedures/genericprocedure`, {
//   method: "POST",
//   headers: {
//     "Content-Type": "application/json",
//   },
//   body: JSON.stringify({ ProcedureName: procName , Parameters: parameters}), // sending procId as ProcedureName
// });
//       if (!res.ok) throw new Error(res.statusText);
//       return await res.json();
//     } catch (err) {
//       console.error("callProc error", err);
//       return [];
//     }
//   };
// // const callProcAndGetResultSets = async (procName: string, params: Record<string, any>) => {
// //   try {
// //     let parameters = "";
// //     let m = 0;

// //     Object.keys(params || {}).forEach((k) => {
// //       const v = params[k];
// //       if (v !== undefined && v !== null && v !== "") {
// //         if (m === 0) {
// //           parameters = `'${String(v)}'`;
// //         } else {
// //           parameters += `,'${String(v)}'`;
// //         }
// //         m++;
// //       }
// //     });

// //     console.log(JSON.stringify({ ProcedureName: procName, Parameters: parameters }));

// //     const res = await fetch(`http://localhost:5017/api/procedures/genericprocedure`, {
// //       method: "POST",
// //       headers: {
// //         "Content-Type": "application/json",
// //       },
// //       body: JSON.stringify({ ProcedureName: procName, Parameters: parameters }),
// //     });

// //     if (!res.ok) throw new Error(res.statusText);

// //     const data = await res.json();

// //     // normalize: ensure always an array of rows
// //     if (Array.isArray(data)) return data;
// //     if (data) return [data];
// //     return [];

// //   } catch (err) {
// //     console.error("callProc error", err);
// //     return [];
// //   }
// // };

//   // -------------------- Widget Renderer (unchanged) --------------------
//   const WidgetRenderer = ({ widget }: { widget: Widget }) => {
//     const [data, setData] = useState<any[] | null>(null);
//     const settings = useMemo(() => {
//       try {
//         return JSON.parse(widget.Settings || "{}");
//       } catch {
//         return {};
//       }
//     }, [widget.Settings]);

//     useEffect(() => {
//       let mounted = true;
//       const fetchData = async () => {
//         if (!settings.proc) return setData([]);
//         const rs = await callProcAndGetResultSets(settings.proc, settings.params || {});
//         console.log('rs');
//         console.log(JSON.stringify(rs));
//         // const sel =
//         //   Array.isArray(rs) && rs.length > (settings.resultSet ?? 0)
//         //     ? rs[settings.resultSet ?? 0]
//         //     : [];
//         //       console.log(JSON.stringify(sel));
//         const sel = Array.isArray(rs) ? rs : [];
//         if (mounted) setData(sel || []);
//       };
//       fetchData();
//       return () => {
//         mounted = false;
//       };
//     }, [widget.Settings]);

//     const chartHeight = (widget.Height || 2) * WIDGET_HEIGHT_UNIT;
//     const chartType = settings.chartType || "bar";
//     const labelField = settings.labelField || detectLabelField(data);
//     const valueField = settings.valueField || detectValueField(data);

//     if (data === null) return <div style={{ height: chartHeight }}>Loading...</div>;
//     if (!data || data.length === 0)
//       return <div style={{ height: chartHeight, padding: 10 }}>No data</div>;
// console.log('chartType::' + chartType)
//     switch (chartType) {
//       case "bar":
//         return (
//           <div style={{ height: chartHeight }}>
//             <ResponsiveContainer width="100%" height="100%">
//               <BarChart data={data}>
//                 <XAxis dataKey={labelField} />
//                 <YAxis />
//                 <Tooltip />
//                 <Bar dataKey={valueField} fill="#1890ff" />
//               </BarChart>
//             </ResponsiveContainer>
//           </div>
//         );
//       case "line":
//         return (
//           <div style={{ height: chartHeight }}>
//             <ResponsiveContainer width="100%" height="100%">
//               <LineChart data={data}>
//                 <XAxis dataKey={labelField} />
//                 <YAxis />
//                 <Tooltip />
//                 <Line dataKey={valueField} stroke="#1890ff" />
//               </LineChart>
//             </ResponsiveContainer>
//           </div>
//         );
//       case "pie":
//         return (
//           <div style={{ height: chartHeight }}>
//             <ResponsiveContainer width="100%" height="100%">
//               <PieChart>
//                 <Pie
//                   data={data}
//                   dataKey={valueField}
//                   nameKey={labelField}
//                   outerRadius={50}
//                 >
//                   {data.map((entry, idx) => (
//                     <Cell key={idx} fill={`hsl(${(idx * 50) % 360},70%,50%)`} />
//                   ))}
//                 </Pie>
//               </PieChart>
//             </ResponsiveContainer>
//           </div>
//         );
//     //   case "table":
//     //     return (
//     //       <Table
//     //         columns={Object.keys(data[0] || {}).map((k) => ({
//     //           title: k,
//     //           dataIndex: k,
//     //           key: k,
//     //         }))}
//     //         dataSource={data.map((r, i) => ({ key: i, ...r }))}
//     //         pagination={false}
//     //         size="small"
//     //       />
//     //     );
//    /* case "table": {
//         console.log("data:"+JSON.stringify(data));
//   if (!data || !data.length) {
//     return <div style={{ padding: 10 }}>No data</div>;
//   }
// const data1 = data[0];
// console.log(data1);
//   // 1️⃣ Get all unique keys across all rows
//   const allKeys = Array.from(
//     new Set(data.flatMap((row) => (row ? Object.keys(row) : [])))
//   );
// console.log("allKeys"+allKeys);
//   // 2️⃣ Build columns for Ant Design Table
//   const columns = allKeys.map((key) => ({
//     title: key,
//     dataIndex: key,
//     key: key,
//   }));

//   // 3️⃣ Ensure each row has a unique React key
//   const dataSource = data.map((row, idx) => ({
//     key: row?.Id ?? row?.UserId ?? idx, // fallback if no Id
//     ...row,
//   }));
// console.log("columns"+columns);
// console.log("dataSource"+dataSource);

//   return (
//     <div style={{ overflow: "auto", maxHeight: chartHeight }}>
//       <Table
//         columns={columns}
//         dataSource={dataSource}
//         pagination={false}
//         size="small"
//       />
//     </div>
//   );
// }
//   */
//  case "table": {
//   // ensure data is an array

//   console.log(JSON.stringify(data));
//   const rows = Array.isArray(data) ? data : [data];

//   if (!rows.length) {
//     return <div style={{ padding: 10 }}>No data</div>;
//   }

//   // get all unique keys across all rows
//   const allKeys = Array.from(
//     new Set(rows.flatMap((row) => (row ? Object.keys(row) : [])))
//   );
// //const [themeModalOpen, setThemeModalOpen] = useState(false);
//   const columns = allKeys.map((key) => ({
//     title: key,
//     dataIndex: key,
//     key: key,
//   }));

//   const dataSource = rows.map((row, idx) => ({
//     key: row?.Id ?? row?.UserId ?? idx,
//     ...row,
//   }));

//   return (
//     <div style={{ overflow: "auto", maxHeight: chartHeight }}>
//       <Table
//         columns={columns}
//         dataSource={dataSource}
//         pagination={false}
//         size="small"
//       />
//     </div>
//   );
// }
//       case "card":
//         return (
//           <Card
//             style={{
//               height: chartHeight,
//               display: "flex",
//               justifyContent: "center",
//               alignItems: "center",
//               fontSize: 24,
//             }}
//           >
//             {data[0]?.[valueField]}
//           </Card>
//         );
//       default:
//         return <div style={{ height: chartHeight }}>Unsupported widget type</div>;
//     }
//   };

//   function detectLabelField(rows: any[] | null) {
//     if (!rows || !rows.length) return "name";
//     const keys = Object.keys(rows[0]);
//     const preferred = ["Month", "MonthName", "name", "label", "CustomerName", "InvoiceNumber"];
//     for (const p of preferred) if (keys.includes(p)) return p;
//     return keys[0];
//   }
//   function detectValueField(rows: any[] | null) {
//     if (!rows || !rows.length) return "value";
//     const keys = Object.keys(rows[0]).filter(
//       (k) => typeof rows[0][k] === "number" || !isNaN(Number(rows[0][k]))
//     );
//     if (!keys.length) return Object.keys(rows[0])[0];
//     const preferred = ["TotalSales", "TotalAmount", "Value", "Revenue", "Quantity", "Total"];
//     for (const p of preferred) if (keys.includes(p)) return p;
//     return keys[0];
//   }

//   if (loading) return <div>Loading admin dashboard...</div>;

//   // function setThemeModalOpen(arg0: boolean): void {
//   //   throw new Error("Function not implemented.");
//   // }

//   return (
//     <div>
//       <Row gutter={8}  style={{ background: "var(--background-bg)" ,marginBottom: 16}}  >
//         <Col>
//           <Button
//             type="primary"
//             onClick={() => {
//               setEditingWidget(null);
//               form.resetFields();
//               setPreviewData([]);
//               setSelectedProc(null);
//               setModalVisible(true);
//             }}
//           >
//             Add / Configure Widget
//           </Button>
//         </Col>

//         <Col>
//           <Select
//             style={{ width: 240 }}
//             placeholder="Quick-add proc"
//             onChange={(v) => {
//               const id = String(v);
//               setSelectedProc(id);
//               setModalVisible(true);
//               const proc = procedures.find(p => p.ProcedureName === id);
//               form.setFieldsValue({ procId: id, procName: proc?.ProcedureName ?? "" });
//             }}
//           >
//             {procedures.length > 0 ? procedures.map(p => (
//               <Option key={p.ProcedureName} value={p.ProcedureName}>
//                 {p.ProcedureName.replace(/^sp_/i, "")}
//               </Option>
//             )) : <Option key="manual" value="">(manual entry)</Option>}
//           </Select>
//         </Col>
//       </Row>

//       <Row gutter={16}>
//         <Col span={16}>
//           <Card title="Dashboard Widgets">
//             <DragDropContext onDragEnd={onDragEnd}>
//               <Droppable droppableId="widgets">
//                 {(prov) => (
//                   <div
//                     ref={prov.innerRef}
//                     {...prov.droppableProps}
//                     style={{
//                       display: "grid",
//                       gridTemplateColumns: `repeat(${NUM_COLUMNS},1fr)`,
//                       gap: 12,
//                     }}
//                   >
//                     {widgets.map((w, idx) => (
//                       <Draggable
//                         key={w.DashboardWidgetId}
//                         draggableId={String(w.DashboardWidgetId)}
//                         index={idx}
//                       >
//                         {(p) => (
//                           <div
//                             ref={p.innerRef}
//                             {...p.draggableProps}
//                             {...p.dragHandleProps}
//                             style={{
//                               background: "#fff",
//                               border: "1px solid #ddd",
//                               padding: 10,
//                               ...p.draggableProps.style,
//                             }}
//                           >
//                             <div
//                               style={{
//                                 display: "flex",
//                                 justifyContent: "space-between",
//                                 marginBottom: 6,
//                               }}
//                             >
//                               <strong>{w.WidgetName}</strong>
//                               <div>
//                                 <Button
//                                   size="small"
//                                   style={{ marginRight: 6 }}
//                                   onClick={() => {
//                                     setEditingWidget(w);
//                                     const s = JSON.parse(w.Settings || "{}");
//                                     // Determine procId from proc name stored in settings (if any)
//                                     const procName = s.proc;
//                                     const found = procedures.find(p => p.ProcedureName === procName);
//                                     setSelectedProc(found?.Id ?? null);
//                                     // set form fields for modal
//                                     form.setFieldsValue({
//                                       WidgetName: w.WidgetName,
//                                       procId: found?.Id ?? null,
//                                       procName: procName ?? "",
//                                       params: s.params || {},
//                                       chartType: s.chartType || "bar",
//                                       labelField: s.labelField || "",
//                                       valueField: s.valueField || ""
//                                     });
//                                     setPreviewData([]);
//                                     setModalVisible(true);
//                                   }}
//                                 >
//                                   Edit
//                                 </Button>
//                                 <Popconfirm
//                                   title="Delete?"
//                                   onConfirm={() =>
//                                     setWidgets((ws) =>
//                                       ws.filter(
//                                         (x) => x.DashboardWidgetId !== w.DashboardWidgetId
//                                       )
//                                     )
//                                   }
//                                   okText="Yes"
//                                   cancelText="No"
//                                 >
//                                   <Button size="small" danger>
//                                     Delete
//                                   </Button>
//                                 </Popconfirm>
//                               </div>
//                             </div>
//                             <WidgetRenderer widget={w} />
//                           </div>
//                         )}
//                       </Draggable>
//                     ))}
//                     {prov.placeholder}
//                   </div>
//                 )}
//               </Droppable>
//             </DragDropContext>
//           </Card>
//         </Col>

//         <Col span={8}>
//           <Card title="Themes">
//             {/* <Select
//               style={{ width: "100%", marginBottom: 12 }}
//               onChange={setSelectedTheme}
//               placeholder="Choose theme"
//             >
//               {themes.map((t) => (
//                 <Option key={t.ThemeId} value={t.ThemeId}>
//                   {t.Name}
//                 </Option>
//               ))}
//             </Select>
//             <Button type="primary" onClick={applyTheme} block>
//               Apply Theme
//             </Button> */}
//             {/* <Button type="primary" onClick={() => setThemeModalOpen(true)}>
//   Theme Editor
// </Button> */}
// <Button type="primary" onClick={() => setDrawerOpen(true)} block>
//   Theme Editor
// </Button>

//           </Card>

//           <Card title="Users" style={{ marginTop: 16 }}>
//             <Table
//               dataSource={users}
//               rowKey="UserId"
//               columns={[
//                 { title: "User", dataIndex: "Username" },
//                 {
//                   title: "Perms",
//                   dataIndex: "Permissions",
//                   render: (p: string[]) => p?.join(", "),
//                 },
//               ]}
//               pagination={false}
//             />
//           </Card>
//         </Col>
//       </Row>
// <Drawer
//   title="Theme Editor"
//   open={drawerOpen}
//   placement="right"
//   width="90%"
//   onClose={() => setDrawerOpen(false)}
// >
//   <ThemeEditorDashboard 
//     onClose={() => setDrawerOpen(false)} 
//   />
// </Drawer>

//       <WidgetModal
//         modalVisible={modalVisible}
//         setModalVisible={setModalVisible}
//         editingWidget={editingWidget}
//         setEditingWidget={setEditingWidget}
//         form={form}
//         procParamsDef={procParamsDef}
//         setProcParamsDef={setProcParamsDef}
//         previewData={previewData}
//         setPreviewData={setPreviewData}
//         selectedProc={selectedProc}
//         setSelectedProc={setSelectedProc}
//         procedures={procedures}
//         callProcAndGetResultSets={callProcAndGetResultSets}
//         onSave={(w) => {
//           setWidgets(ws => {
//             const idx = ws.findIndex(x => x.DashboardWidgetId === w.DashboardWidgetId);
//             if (idx >= 0) {
//               const copy = [...ws];
//               copy[idx] = w;
//               return copy;
//             } else {
//               return [w, ...ws];
//             }
//           });
//           setModalVisible(false);
//           setEditingWidget(null);
//           form.resetFields();
//         }}
//       />
//     </div>
//   );
// };
