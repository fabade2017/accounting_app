// src/pages/AdminDashboard.tsx
import { useContext, useEffect, useMemo, useState } from "react";
import {
  Table,
  Button,
  Select,
  message,
  Card,
  Row,
  Col,
  Popconfirm,
  Form
} from "antd";
import { DragDropContext, Droppable, Draggable, DropResult } from "@hello-pangea/dnd";
import { WidgetModal } from "../components/WidgetModal";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell
} from "recharts";
import { ThemeContext } from "../contexts/ThemeContext";


//const { applyThemeToDOM } = useContext(ThemeContext);

const { Option } = Select;
const DASHBOARD_ID = 2;
const WIDGET_HEIGHT_UNIT = 100;
const NUM_COLUMNS = 2;

// fallback widget metadata
const widgetMeta: Record<number, { name: string; type: string }> = {
  1: { name: "Sales Chart", type: "Chart" },
  2: { name: "User Table", type: "Table" },
  3: { name: "KPI Card", type: "Card" },
  4: { name: "Revenue Chart", type: "Chart" },
};

interface Widget {
  DashboardWidgetId: number;
  DashboardId: number;
  WidgetId: number;
  WidgetName?: string;
  Type?: string;
  Settings: string;
  PositionX: number;
  PositionY: number;
  Width: number;
  Height: number;
}

interface Theme { ThemeId: number; Name: string; Settings: string }
interface User { UserId: number; Username: string; Permissions: string[] }

interface Procedure {
  Id: number;
  ProcedureName: string;
}

export const AdminDashboard = () => {
  const [widgets, setWidgets] = useState<Widget[]>([]);
  const [themes, setThemes] = useState<Theme[]>([]);
  const [selectedTheme, setSelectedTheme] = useState<number | null>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const { applyThemeToDOM, getComputedVar } = useContext(ThemeContext);


  const [modalVisible, setModalVisible] = useState(false);
  const [editingWidget, setEditingWidget] = useState<Widget | null>(null);
  const [form] = Form.useForm();

  // NOTE: procedures is an array of Procedure objects (id + name)
  const [procedures, setProcedures] = useState<Procedure[]>([]);
  const [procParamsDef, setProcParamsDef] = useState<
    Array<{ name: string; type: string; required: boolean }>
  >([]);
  const [previewData, setPreviewData] = useState<any[]>([]);
  // selectedProc is the ProcedureId (number) or null
  const [selectedProc, setSelectedProc] = useState<string | null>(null);

/*
const applyThemeToDOM = (settingsJson: string) => {
  if (!settingsJson) return;

  let settings;
  try {
    settings = JSON.parse(settingsJson);
  } catch {
    console.error("Invalid theme settings");
    return;
  }

  const root = document.documentElement;

  Object.keys(settings).forEach(key => {
    root.style.setProperty(`--${key}`, settings[key]);
  });
};
*/
const applyTheme = async () => {
  if (!selectedTheme) return;
console.log( JSON.stringify({
        dashboardId: DASHBOARD_ID,
        themeId: selectedTheme,
      }));
  try {
    // Save selected theme
    const res = await fetch(`http://localhost:5017/api/themes`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        dashboardId: DASHBOARD_ID,
        themeId: selectedTheme,
      }),
    });

    if (!res.ok) throw new Error();

    const data = await res.json(); // includes settings JSON
    applyThemeToDOM(JSON.parse(data.settings));

    message.success("Theme applied!");
  } catch {
    message.error("Failed to apply theme");
  }
};

//   const loadDashboardTheme = async () => {
//   try {
//     const res = await fetch(
//       `http://localhost:5017/api/theme?dashboardId=${DASHBOARD_ID}`
//     );
//     if (!res.ok) return;

//     const theme = await res.json(); // { themeId, settings }
//     setSelectedTheme(theme.themeId);
//     applyThemeToDOM(theme.settings);
//   } catch (err) {
//     console.error("Failed to load dashboard theme", err);
//   }
// };



//loadDashboardTheme(); // <-- ADD THIS

  // -------------------- Load initial data --------------------
  useEffect(() => {
    loadWidgets();
    loadThemes();
    loadUsers();

      loadDashboardTheme();  // <-- ADD THIS
    loadProcedures();
  }, []);
const loadDashboardTheme = async () => {
  try {
    const res = await fetch(
      `http://localhost:5017/api/themes?id=${DASHBOARD_ID}`
    );

    if (!res.ok) return;

    const theme = await res.json();

    if (theme?.settings) {
      setSelectedTheme(theme.themeId);
      applyThemeToDOM(JSON.parse(theme.settings));
    }
  } catch (err) {
    console.error("Failed to load theme", err);
  }
};
  const loadProcedures = async () => {
    try {
      const res = await fetch("http://localhost:5017/api/ProcedureMetadata");
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json(); // expect array of { ProcedureId, ProcedureName, ... }
//console.log(JSON.stringify(data));
      // Ensure items have ProcedureId and ProcedureName, remove duplicates by ProcedureId
      const filtered = (data || [])
        .filter((p: any) => p && (p.Id !== undefined && p.Id !== null))
      .map((p: any) => ({ ProcedureId: Number(p.Id), ProcedureName: String(p.ProcedureName) }));
        console.log(JSON.stringify(filtered));
      // Remove duplicates by ProcedureId (keep first)
      const distinctById = Array.from(new Map(filtered.map((p: Procedure) => [p.ProcedureName, p])).values());

      distinctById.sort((a, b) => a.ProcedureName.localeCompare(b.ProcedureName, undefined, { sensitivity: "base" }));

      setProcedures(distinctById);
    } catch (err) {
      console.error("Failed to load procedures", err);
      setProcedures([]);
    }
  };

  const loadWidgets = async () => {
    try {
      const res = await fetch(
        `http://localhost:5017/api/dashboardwidgets?dashboardId=${DASHBOARD_ID}`
      );
      const data = await res.json();
      const enriched = (data || []).map((w: any) => ({
        ...w,
        WidgetName: w.WidgetName || widgetMeta[w.WidgetId]?.name || `Widget ${w.WidgetId}`,
        Type: w.Type || widgetMeta[w.WidgetId]?.type || "Unknown",
      }));
      setWidgets(enriched);
    } catch {
      message.error("Failed to load widgets");
    }
  };

  const loadThemes = async () => {
    try {
      const res = await fetch(`http://localhost:5017/api/themes`);
      setThemes(await res.json());
    } catch {
      message.error("Failed to load themes");
    }
  };

  const loadUsers = async () => {
    try {
      const res = await fetch(`http://localhost:5017/api/users`);
      setUsers(await res.json());
      setLoading(false);
    } catch {
      message.error("Failed to load users");
      setLoading(false);
    }
  };

//   const applyTheme = async () => {
//     if (!selectedTheme) return;
//     try {
//       await fetch(`http://localhost:5017/api/theme`, {
//         method: "PUT",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({ dashboardId: DASHBOARD_ID, themeId: selectedTheme }),
//       });
//       message.success("Theme applied!");
//     } catch {
//       message.error("Failed to apply theme");
//     }
//   };

  // -------------------- Drag & drop --------------------
  const onDragEnd = async (result: DropResult) => {
    if (!result.destination) return;
    const reordered = Array.from(widgets);
    const [moved] = reordered.splice(result.source.index, 1);
    reordered.splice(result.destination.index, 0, moved);
    const updated = reordered.map((w, idx) => ({
      ...w,
      PositionX: idx % NUM_COLUMNS,
      PositionY: Math.floor(idx / NUM_COLUMNS),
    }));
    setWidgets(updated);

    try {
      await Promise.all(
        updated.map((w) =>
          fetch(`http://localhost:5017/api/dashboardwidgets/${w.DashboardWidgetId}`, {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              DashboardWidgetId: w.DashboardWidgetId,
              PositionX: w.PositionX,
              PositionY: w.PositionY,
              Width: w.Width,
              Height: w.Height,
              Settings: w.Settings,
            }),
          })
        )
      );
      message.success("Layout saved");
    } catch {
      message.error("Failed to persist layout");
    }
  };

  // -------------------- Helper: call proc --------------------
  const callProcAndGetResultSets = async (procName: string, params: Record<string, any>) => {
    try {
      const qs = new URLSearchParams();
      let parameters ="";
      let m = 0;
      Object.keys(params || {}).forEach((k) => {
        const v = params[k];
        if (v !== undefined && v !== null && v !== "") qs.set(k, String(v));
        if( m == 0) { m++;  parameters = "'"+String(v)+"'";}
        else
        {
            m++;  parameters = parameters +",'"+ String(v)+"'";
        }
       // if(k == 0) { parameters = }
      //  parameters =  parameters +',' +v;
      });
    //   const url = `http://localhost:5017/api/procedures/${encodeURIComponent(procName)}${qs.toString() ? `?${qs.toString()}` : ""}`;
    //   const res = await fetch(url);
console.log( JSON.stringify({ ProcedureName: procName , Parameters: parameters}));
       const res = await fetch(`http://localhost:5017/api/procedures/genericprocedure`, {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
  },
  body: JSON.stringify({ ProcedureName: procName , Parameters: parameters}), // sending procId as ProcedureName
});
      if (!res.ok) throw new Error(res.statusText);
      return await res.json();
    } catch (err) {
      console.error("callProc error", err);
      return [];
    }
  };
// const callProcAndGetResultSets = async (procName: string, params: Record<string, any>) => {
//   try {
//     let parameters = "";
//     let m = 0;

//     Object.keys(params || {}).forEach((k) => {
//       const v = params[k];
//       if (v !== undefined && v !== null && v !== "") {
//         if (m === 0) {
//           parameters = `'${String(v)}'`;
//         } else {
//           parameters += `,'${String(v)}'`;
//         }
//         m++;
//       }
//     });

//     console.log(JSON.stringify({ ProcedureName: procName, Parameters: parameters }));

//     const res = await fetch(`http://localhost:5017/api/procedures/genericprocedure`, {
//       method: "POST",
//       headers: {
//         "Content-Type": "application/json",
//       },
//       body: JSON.stringify({ ProcedureName: procName, Parameters: parameters }),
//     });

//     if (!res.ok) throw new Error(res.statusText);

//     const data = await res.json();

//     // normalize: ensure always an array of rows
//     if (Array.isArray(data)) return data;
//     if (data) return [data];
//     return [];

//   } catch (err) {
//     console.error("callProc error", err);
//     return [];
//   }
// };

  // -------------------- Widget Renderer (unchanged) --------------------
  const WidgetRenderer = ({ widget }: { widget: Widget }) => {
    const [data, setData] = useState<any[] | null>(null);
    const settings = useMemo(() => {
      try {
        return JSON.parse(widget.Settings || "{}");
      } catch {
        return {};
      }
    }, [widget.Settings]);

    useEffect(() => {
      let mounted = true;
      const fetchData = async () => {
        if (!settings.proc) return setData([]);
        const rs = await callProcAndGetResultSets(settings.proc, settings.params || {});
        console.log('rs');
        console.log(JSON.stringify(rs));
        // const sel =
        //   Array.isArray(rs) && rs.length > (settings.resultSet ?? 0)
        //     ? rs[settings.resultSet ?? 0]
        //     : [];
        //       console.log(JSON.stringify(sel));
        const sel = Array.isArray(rs) ? rs : [];
        if (mounted) setData(sel || []);
      };
      fetchData();
      return () => {
        mounted = false;
      };
    }, [widget.Settings]);

    const chartHeight = (widget.Height || 2) * WIDGET_HEIGHT_UNIT;
    const chartType = settings.chartType || "bar";
    const labelField = settings.labelField || detectLabelField(data);
    const valueField = settings.valueField || detectValueField(data);

    if (data === null) return <div style={{ height: chartHeight }}>Loading...</div>;
    if (!data || data.length === 0)
      return <div style={{ height: chartHeight, padding: 10 }}>No data</div>;
console.log('chartType::' + chartType)
    switch (chartType) {
      case "bar":
        return (
          <div style={{ height: chartHeight }}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data}>
                <XAxis dataKey={labelField} />
                <YAxis />
                <Tooltip />
                <Bar dataKey={valueField} fill="#1890ff" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        );
      case "line":
        return (
          <div style={{ height: chartHeight }}>
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data}>
                <XAxis dataKey={labelField} />
                <YAxis />
                <Tooltip />
                <Line dataKey={valueField} stroke="#1890ff" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        );
      case "pie":
        return (
          <div style={{ height: chartHeight }}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={data}
                  dataKey={valueField}
                  nameKey={labelField}
                  outerRadius={50}
                >
                  {data.map((entry, idx) => (
                    <Cell key={idx} fill={`hsl(${(idx * 50) % 360},70%,50%)`} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </div>
        );
    //   case "table":
    //     return (
    //       <Table
    //         columns={Object.keys(data[0] || {}).map((k) => ({
    //           title: k,
    //           dataIndex: k,
    //           key: k,
    //         }))}
    //         dataSource={data.map((r, i) => ({ key: i, ...r }))}
    //         pagination={false}
    //         size="small"
    //       />
    //     );
   /* case "table": {
        console.log("data:"+JSON.stringify(data));
  if (!data || !data.length) {
    return <div style={{ padding: 10 }}>No data</div>;
  }
const data1 = data[0];
console.log(data1);
  // 1️⃣ Get all unique keys across all rows
  const allKeys = Array.from(
    new Set(data.flatMap((row) => (row ? Object.keys(row) : [])))
  );
console.log("allKeys"+allKeys);
  // 2️⃣ Build columns for Ant Design Table
  const columns = allKeys.map((key) => ({
    title: key,
    dataIndex: key,
    key: key,
  }));

  // 3️⃣ Ensure each row has a unique React key
  const dataSource = data.map((row, idx) => ({
    key: row?.Id ?? row?.UserId ?? idx, // fallback if no Id
    ...row,
  }));
console.log("columns"+columns);
console.log("dataSource"+dataSource);

  return (
    <div style={{ overflow: "auto", maxHeight: chartHeight }}>
      <Table
        columns={columns}
        dataSource={dataSource}
        pagination={false}
        size="small"
      />
    </div>
  );
}
  */
 case "table": {
  // ensure data is an array

  console.log(JSON.stringify(data));
  const rows = Array.isArray(data) ? data : [data];

  if (!rows.length) {
    return <div style={{ padding: 10 }}>No data</div>;
  }

  // get all unique keys across all rows
  const allKeys = Array.from(
    new Set(rows.flatMap((row) => (row ? Object.keys(row) : [])))
  );

  const columns = allKeys.map((key) => ({
    title: key,
    dataIndex: key,
    key: key,
  }));

  const dataSource = rows.map((row, idx) => ({
    key: row?.Id ?? row?.UserId ?? idx,
    ...row,
  }));

  return (
    <div style={{ overflow: "auto", maxHeight: chartHeight }}>
      <Table
        columns={columns}
        dataSource={dataSource}
        pagination={false}
        size="small"
      />
    </div>
  );
}
      case "card":
        return (
          <Card
            style={{
              height: chartHeight,
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              fontSize: 24,
            }}
          >
            {data[0]?.[valueField]}
          </Card>
        );
      default:
        return <div style={{ height: chartHeight }}>Unsupported widget type</div>;
    }
  };

  function detectLabelField(rows: any[] | null) {
    if (!rows || !rows.length) return "name";
    const keys = Object.keys(rows[0]);
    const preferred = ["Month", "MonthName", "name", "label", "CustomerName", "InvoiceNumber"];
    for (const p of preferred) if (keys.includes(p)) return p;
    return keys[0];
  }
  function detectValueField(rows: any[] | null) {
    if (!rows || !rows.length) return "value";
    const keys = Object.keys(rows[0]).filter(
      (k) => typeof rows[0][k] === "number" || !isNaN(Number(rows[0][k]))
    );
    if (!keys.length) return Object.keys(rows[0])[0];
    const preferred = ["TotalSales", "TotalAmount", "Value", "Revenue", "Quantity", "Total"];
    for (const p of preferred) if (keys.includes(p)) return p;
    return keys[0];
  }

  if (loading) return <div>Loading admin dashboard...</div>;

  return (
    <div>
      <Row gutter={8} style={{ marginBottom: 16 }}>
        <Col>
          <Button
            type="primary"
            onClick={() => {
              setEditingWidget(null);
              form.resetFields();
              setPreviewData([]);
              setSelectedProc(null);
              setModalVisible(true);
            }}
          >
            Add / Configure Widget
          </Button>
        </Col>

        <Col>
          <Select
            style={{ width: 240 }}
            placeholder="Quick-add proc"
            onChange={(v) => {
              const id = String(v);
              setSelectedProc(id);
              setModalVisible(true);
              const proc = procedures.find(p => p.ProcedureName === id);
              form.setFieldsValue({ procId: id, procName: proc?.ProcedureName ?? "" });
            }}
          >
            {procedures.length > 0 ? procedures.map(p => (
              <Option key={p.ProcedureName} value={p.ProcedureName}>
                {p.ProcedureName.replace(/^sp_/i, "")}
              </Option>
            )) : <Option key="manual" value="">(manual entry)</Option>}
          </Select>
        </Col>
      </Row>

      <Row gutter={16}>
        <Col span={16}>
          <Card title="Dashboard Widgets">
            <DragDropContext onDragEnd={onDragEnd}>
              <Droppable droppableId="widgets">
                {(prov) => (
                  <div
                    ref={prov.innerRef}
                    {...prov.droppableProps}
                    style={{
                      display: "grid",
                      gridTemplateColumns: `repeat(${NUM_COLUMNS},1fr)`,
                      gap: 12,
                    }}
                  >
                    {widgets.map((w, idx) => (
                      <Draggable
                        key={w.DashboardWidgetId}
                        draggableId={String(w.DashboardWidgetId)}
                        index={idx}
                      >
                        {(p) => (
                          <div
                            ref={p.innerRef}
                            {...p.draggableProps}
                            {...p.dragHandleProps}
                            style={{
                              background: "#fff",
                              border: "1px solid #ddd",
                              padding: 10,
                              ...p.draggableProps.style,
                            }}
                          >
                            <div
                              style={{
                                display: "flex",
                                justifyContent: "space-between",
                                marginBottom: 6,
                              }}
                            >
                              <strong>{w.WidgetName}</strong>
                              <div>
                                <Button
                                  size="small"
                                  style={{ marginRight: 6 }}
                                  onClick={() => {
                                    setEditingWidget(w);
                                    const s = JSON.parse(w.Settings || "{}");
                                    // Determine procId from proc name stored in settings (if any)
                                    const procName = s.proc;
                                    const found = procedures.find(p => p.ProcedureName === procName);
                                    setSelectedProc(found?.Id ?? null);
                                    // set form fields for modal
                                    form.setFieldsValue({
                                      WidgetName: w.WidgetName,
                                      procId: found?.Id ?? null,
                                      procName: procName ?? "",
                                      params: s.params || {},
                                      chartType: s.chartType || "bar",
                                      labelField: s.labelField || "",
                                      valueField: s.valueField || ""
                                    });
                                    setPreviewData([]);
                                    setModalVisible(true);
                                  }}
                                >
                                  Edit
                                </Button>
                                <Popconfirm
                                  title="Delete?"
                                  onConfirm={() =>
                                    setWidgets((ws) =>
                                      ws.filter(
                                        (x) => x.DashboardWidgetId !== w.DashboardWidgetId
                                      )
                                    )
                                  }
                                  okText="Yes"
                                  cancelText="No"
                                >
                                  <Button size="small" danger>
                                    Delete
                                  </Button>
                                </Popconfirm>
                              </div>
                            </div>
                            <WidgetRenderer widget={w} />
                          </div>
                        )}
                      </Draggable>
                    ))}
                    {prov.placeholder}
                  </div>
                )}
              </Droppable>
            </DragDropContext>
          </Card>
        </Col>

        <Col span={8}>
          <Card title="Themes">
            <Select
              style={{ width: "100%", marginBottom: 12 }}
              onChange={setSelectedTheme}
              placeholder="Choose theme"
            >
              {themes.map((t) => (
                <Option key={t.ThemeId} value={t.ThemeId}>
                  {t.Name}
                </Option>
              ))}
            </Select>
            <Button type="primary" onClick={applyTheme} block>
              Apply Theme
            </Button>
          </Card>

          <Card title="Users" style={{ marginTop: 16 }}>
            <Table
              dataSource={users}
              rowKey="UserId"
              columns={[
                { title: "User", dataIndex: "Username" },
                {
                  title: "Perms",
                  dataIndex: "Permissions",
                  render: (p: string[]) => p?.join(", "),
                },
              ]}
              pagination={false}
            />
          </Card>
        </Col>
      </Row>

      <WidgetModal
        modalVisible={modalVisible}
        setModalVisible={setModalVisible}
        editingWidget={editingWidget}
        setEditingWidget={setEditingWidget}
        form={form}
        procParamsDef={procParamsDef}
        setProcParamsDef={setProcParamsDef}
        previewData={previewData}
        setPreviewData={setPreviewData}
        selectedProc={selectedProc}
        setSelectedProc={setSelectedProc}
        procedures={procedures}
        callProcAndGetResultSets={callProcAndGetResultSets}
        onSave={(w) => {
          setWidgets(ws => {
            const idx = ws.findIndex(x => x.DashboardWidgetId === w.DashboardWidgetId);
            if (idx >= 0) {
              const copy = [...ws];
              copy[idx] = w;
              return copy;
            } else {
              return [w, ...ws];
            }
          });
          setModalVisible(false);
          setEditingWidget(null);
          form.resetFields();
        }}
      />
    </div>
  );
};
