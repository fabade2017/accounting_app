import React, { useEffect, useState } from "react";
import {
  Card, Row, Col, Button, Input, Drawer, Form, Popconfirm, message, Spin
} from "antd";
import { callProcedure } from "../utils/procedureClient";
import { useTheme } from "../contexts/ThemeContext";

export const ThemeEditorDashboard = ({ open, onClose }) => {
  const { applyThemeToDOM } = useTheme();
  const [themes, setThemes] = useState([]);
  const [editingTheme, setEditingTheme] = useState(null);
  const [loading, setLoading] = useState(false);
  const [form] = Form.useForm();

  useEffect(() => { 
    if (open) loadThemes(); 
  }, [open]);


  // ---------------------------------------------------
  // LOAD THEMES (FULLY FIXED)
  // ---------------------------------------------------
//   const loadThemes = async () => {
//     setLoading(true);
//     try {
//       const data = await callProcedure("sp_thememanager", "'GetAll'");
//       setThemes(Array.isArray(data) ? data : []);
//     } catch (err) {
//       console.error("Theme load error:", err);
//       message.error("Failed to load themes");
//       setThemes([]);
//     }
//     setLoading(false);
//   };

const loadThemes = async () => {
  setLoading(true);

  try {
    const res = await fetch("http://localhost:5017/api/procedures/sp_thememanager", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        Parameters: "'GetAll'"   // EXACTLY how your API accepts params
      }),
    });

    const text = await res.text();
    console.log("RAW API:", text);

    if (!text.trim()) {
      setThemes([]);
      return;
    }

    const data = JSON.parse(text);
    console.log("THEMES:", data);

    setThemes(Array.isArray(data) ? data : []);
  } catch (err) {
    console.error("Theme load failed:", err);
    message.error("Could not load themes");
  }

  setLoading(false);
};

  // ---------------------------------------------------
  // OPEN THEME EDITOR
  // ---------------------------------------------------
  const openEditor = (t = null) => {
    setEditingTheme(t);
    form.resetFields();
    if (t) form.setFieldsValue(t);
  };


  // ---------------------------------------------------
  // SAVE THEME (Create / Update)
  // ---------------------------------------------------
  const saveTheme = async (values) => {
    try {
      const action = editingTheme ? "Update" : "Create";

      const params = [
        `'${action}'`,
        editingTheme?.ThemeId ?? "NULL",
        `'${values.ThemeName}'`,
        `'${values.PrimaryColor}'`,
        `'${values.BackgroundColor}'`,
        `'${values.TextColor}'`,
        `'${values.CardColor}'`,
        `'${values.SidebarBg}'`,
        `'${values.ChartColor}'`,
        editingTheme?.IsDefault ?? 0
      ].join(",");

      await callProcedure("sp_thememanager", params);
      message.success("Theme saved!");

      loadThemes();
    } catch (err) {
      console.error(err);
      message.error("Failed to save theme");
    }
  };


  // ---------------------------------------------------
  // DELETE THEME
  // ---------------------------------------------------
  const deleteTheme = async (id) => {
    try {
      await callProcedure("sp_thememanager", `'Delete',${id}`);
      message.success("Theme deleted");
      loadThemes();
    } catch {
      message.error("Failed to delete");
    }
  };


  // ---------------------------------------------------
  // APPLY THEME FOR USER
  // ---------------------------------------------------
  const applyForUser = async (id) => {
    try {
      const userId = 1;

      await callProcedure("sp_thememanager", `'SetTheme',${userId},${id}`);

      const theme = await callProcedure("sp_thememanager", `'GetById',${id}`);
      if (theme && theme.length) applyThemeToDOM(theme[0]);

      message.success("Theme applied!");
    } catch (err) {
      console.error(err);
      message.error("Failed to apply theme");
    }
  };


  return (
    <Drawer
      title="Theme Editor"
      open={open}
      onClose={onClose}
      width="80%"
      destroyOnClose
    >
      <Spin spinning={loading}>
        <Row gutter={[16,16]}>
          {themes.map((theme) => (
            <Col span={6} key={theme?.ThemeId}>
              <Card title={theme?.ThemeName}>

                <div style={{
                  background: theme.BackgroundColor,
                  color: theme.TextColor,
                  padding: 10,
                  borderRadius: 6,
                  border: `1px solid ${theme.PrimaryColor}`,
                  marginBottom: 8
                }}>
                  <strong>{theme.ThemeName}</strong>
                  <div>Primary: {theme.PrimaryColor}</div>
                </div>

                <Button block onClick={() => applyThemeToDOM(theme)}>Preview</Button>
                <Button block type="primary" onClick={() => applyForUser(theme.ThemeId)}>
                  Apply
                </Button>
                <Button block onClick={() => openEditor(theme)}>Edit</Button>

                <Popconfirm title="Delete?" onConfirm={() => deleteTheme(theme.ThemeId)}>
                  <Button danger block>Delete</Button>
                </Popconfirm>
              </Card>
            </Col>
          ))}

          {/* ADD NEW */}
          <Col span={6}>
            <Card
              onClick={() => openEditor(null)}
              style={{
                cursor: "pointer",
                height: 220,
                display: "flex",
                border: "2px dashed #ccc",
                alignItems: "center",
                justifyContent: "center"
              }}
            >
              + Add New Theme
            </Card>
          </Col>
        </Row>

        {/* EDITOR FORM */}
        <div style={{ marginTop: 20 }}>
          <Form form={form} layout="vertical" onFinish={saveTheme}>
            <Form.Item name="ThemeName" label="Theme Name" rules={[{ required: true }]}>
              <Input />
            </Form.Item>

            <Row gutter={12}>
              <Col span={12}><Form.Item name="PrimaryColor" label="Primary"><Input type="color" /></Form.Item></Col>
              <Col span={12}><Form.Item name="BackgroundColor" label="Background"><Input type="color" /></Form.Item></Col>
            </Row>

            <Row gutter={12}>
              <Col span={12}><Form.Item name="TextColor" label="Text Color"><Input type="color" /></Form.Item></Col>
              <Col span={12}><Form.Item name="CardColor" label="Card Color"><Input type="color" /></Form.Item></Col>
            </Row>

            <Row gutter={12}>
              <Col span={12}><Form.Item name="SidebarBg" label="Sidebar"><Input type="color" /></Form.Item></Col>
              <Col span={12}><Form.Item name="ChartColor" label="Chart Color"><Input type="color" /></Form.Item></Col>
            </Row>

            <Button type="primary" htmlType="submit">Save Theme</Button>
            <Button style={{ marginLeft: 10 }} onClick={() => form.resetFields()}>Reset</Button>
          </Form>
        </div>
      </Spin>
    </Drawer>
  );
};

export default ThemeEditorDashboard;



import React, { useState, useEffect, useContext } from "react";
import {
  Card,
  Row,
  Col,
  Button,
  Input,
  Modal,
  Form,
  Popconfirm,
  message,
} from "antd";
import { ThemeContext } from "../contexts/ThemeContext";

export const ThemeEditorDashboard = () => {
  const { applyThemeToDOM } = useContext(ThemeContext);

  const [themes, setThemes] = useState([]);
  const [editingTheme, setEditingTheme] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const [form] = Form.useForm();

  // -------------------------------
  // Load all themes on mount
  // -------------------------------
  useEffect(() => {
    loadThemes();
  }, []);

//   const loadThemes = async () => {
//     const res = await fetch("http://localhost:5017/api/procedure/sp_thememanager?action=GetAll");
//     const data = await res.json();
//     setThemes(data);
//   };
const loadThemes = async () => {
  try {
    const res = await fetch("http://localhost:5017/api/procedures/genericprocedure", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ProcedureName: "sp_thememanager",
        Parameters: "'GetAll'" // single string parameter for action
      }),
    });

    if (!res.ok) throw new Error(`HTTP ${res.status}`);

    const data = await res.json();
    setThemes(data || []);
  } catch (err) {
    console.error("Failed to load themes", err);
    setThemes([]);
  }
};

  // -------------------------------------------------
  // Open modal to edit / create theme
  // -------------------------------------------------
  const openEditor = (theme) => {
    setEditingTheme(theme);
    setIsModalOpen(true);

    if (theme) {
      form.setFieldsValue(theme);
    } else {
      form.resetFields();
    }
  };

  // -------------------------------------------------
  // SAVE THEME (Create or Update)
  // -------------------------------------------------
  const saveTheme = async (values) => {
    const method =  "POST";
console.log(JSON.stringify( {Action: editingTheme ? "Update" : "Create",
        ThemeId: editingTheme?.ThemeId,
    ...values}));
    await fetch(`http://localhost:5017/api/procedures/sp_thememanager`, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        Action: editingTheme ? "Update" : "Create",
        ThemeId: editingTheme?.ThemeId,
        ...values,
      }),
    });

    message.success(editingTheme ? "Theme updated!" : "Theme created!");
    setIsModalOpen(false);
    loadThemes();
  };

  // -------------------------------------------------
  // DELETE THEME
  // -------------------------------------------------
  const deleteTheme = async (themeId) => {
    await fetch(`http://localhost:5017/api/procedures/sp_thememanager`, {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        Action: "Delete",
        ThemeId: themeId,
      }),
    });

    message.success("Theme deleted");
    loadThemes();
  };

  // -------------------------------------------------
  // APPLY THEME LIVE (Preview)
  // -------------------------------------------------
  const previewTheme = (theme) => {
    applyThemeToDOM(theme);
    message.info(`Previewing theme "${theme.ThemeName}"`);
  };

  // -------------------------------------------------
  // SAVE USER'S THEME
  // -------------------------------------------------
  const applyTheme = async (themeId) => {
    await fetch(`http://localhost:5017/api/procedures/sp_thememanager?action=SetTheme`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        UserId: 1, // TODO: use real logged in user
        ThemeId: themeId,
      }),
    });

    message.success("Default theme saved!");
  };

  return (
    <div>
      <h2 style={{ marginBottom: 20 }}>🎨 Theme Editor</h2>

      <Row gutter={[16, 16]}>
        {themes.map((theme) => (
          <Col span={6} key={theme.ThemeId}>
            <Card
              title={theme.ThemeName}
              bordered
              style={{ borderRadius: 10 }}
            >
              {/* Theme preview card */}
              <div
                style={{
                  background: theme.BackgroundColor,
                  color: theme.TextColor,
                  padding: 10,
                  borderRadius: 6,
                  border: `1px solid ${theme.PrimaryColor}`,
                  marginBottom: 10,
                }}
              >
                <h4 style={{ margin: 0 }}>Preview</h4>
                <p style={{ margin: 0 }}>Primary: {theme.PrimaryColor}</p>
              </div>

              <Button
                block
                style={{ marginBottom: 6 }}
                onClick={() => previewTheme(theme)}
              >
                Preview
              </Button>

              <Button
                type="primary"
                block
                style={{ marginBottom: 6 }}
                onClick={() => applyTheme(theme.ThemeId)}
              >
                Apply Theme
              </Button>

              <Button
                block
                style={{ marginBottom: 6 }}
                onClick={() => openEditor(theme)}
              >
                Edit
              </Button>

              <Popconfirm
                title="Delete theme?"
                onConfirm={() => deleteTheme(theme.ThemeId)}
              >
                <Button danger block>
                  Delete
                </Button>
              </Popconfirm>
            </Card>
          </Col>
        ))}

        {/* Add new theme */}
        <Col span={6}>
          <Card
            style={{
              height: 250,
              border: "2px dashed #ccc",
              cursor: "pointer",
              textAlign: "center",
              paddingTop: 90,
            }}
            onClick={() => openEditor(null)}
          >
            + Add New Theme
          </Card>
        </Col>
      </Row>

      {/* -----------------------------------------
          THEME EDITOR MODAL
      ------------------------------------------ */}
      <Modal
        title={editingTheme ? "Edit Theme" : "Create Theme"}
        open={isModalOpen}
        onCancel={() => setIsModalOpen(false)}
        footer={null}
      >
        <Form form={form} layout="vertical" onFinish={saveTheme}>
          <Form.Item
            name="ThemeName"
            label="Theme Name"
            rules={[{ required: true }]}
          >
            <Input placeholder="Dark Mode" />
          </Form.Item>

          <Row gutter={12}>
            <Col span={12}>
              <Form.Item name="PrimaryColor" label="Primary Color">
                <Input type="color" />
              </Form.Item>
            </Col>

            <Col span={12}>
              <Form.Item name="BackgroundColor" label="Background">
                <Input type="color" />
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={12}>
            <Col span={12}>
              <Form.Item name="TextColor" label="Text Color">
                <Input type="color" />
              </Form.Item>
            </Col>

            <Col span={12}>
              <Form.Item name="CardColor" label="Card Background">
                <Input type="color" />
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={12}>
            <Col span={12}>
              <Form.Item name="SidebarBg" label="Sidebar Color">
                <Input type="color" />
              </Form.Item>
            </Col>

            <Col span={12}>
              <Form.Item name="ChartColor" label="Chart Color">
                <Input type="color" />
              </Form.Item>
            </Col>
          </Row>

          <Button type="primary" block htmlType="submit">
            Save Theme
          </Button>
        </Form>
      </Modal>
    </div>
  );
};

export default ThemeEditorDashboard;
