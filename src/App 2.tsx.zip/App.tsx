// src/App.tsx
import { useEffect, useState } from "react";
import { Layout, Menu } from "antd";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import { GenericResourcePage } from "./components/GenericResourcePage";

const { Sider, Content } = Layout;

interface Bucket {
  Id: number;
  Name: string;
}
interface SubBucket {
  Id: number;
  Name: string;
  BucketId: number;
}
interface Module {
  Id: number;
  UpperModule: string;
  UrlPath: string;
}

export const App = () => {
  const [menuData, setMenuData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  // =============================
  // Load Buckets + SubBuckets + Modules
  // =============================
  const loadData = async () => {
    const [bucketsRes, subBucketsRes, modulesRes] = await Promise.all([
      fetch("http://localhost:3000/api/Buckets"),
      fetch("http://localhost:3000/api/SubBuckets"),
      fetch("http://localhost:3000/api/modules"),
    ]);

    const buckets: Bucket[] = await bucketsRes.json();
    const subBuckets: SubBucket[] = await subBucketsRes.json();
    const modules: Module[] = await modulesRes.json();

    // Group modules by UpperModule
    const groupedModules: Record<string, Module[]> = {};
    modules.forEach((m) => {
      if (!groupedModules[m.UpperModule]) {
        groupedModules[m.UpperModule] = [];
      }
      groupedModules[m.UpperModule].push(m);
    });

    // Build SubBucket → Modules
    const subBucketTree = subBuckets.map((sb) => ({
      key: `sub_${sb.Id}`,
      label: sb.Name,
      bucketId: sb.BucketId,
      children: groupedModules[sb.Name]
        ? groupedModules[sb.Name].map((mod) => ({
            key: `/module/${mod.UpperModule.toLowerCase()}`,
            label: (
              <Link to={`/module/${mod.UpperModule.toLowerCase()}`}>
                {mod.UpperModule}
              </Link>
            ),
          }))
        : [],
    }));

    // Build Bucket → SubBuckets
    const finalMenu = buckets.map((bucket) => ({
      key: `bucket_${bucket.Id}`,
      label: bucket.Name,
      children: subBucketTree
        .filter((sb) => sb.bucketId === bucket.Id)
        .map((sb) => ({
          key: sb.key,
          label: sb.label,
          children: sb.children,
        })),
    }));

    setMenuData(finalMenu);
    setLoading(false);
  };

  if (loading) return <div>Loading menu...</div>;

  // Convert menuData into AntD items
  const getMenuItems = () =>
    menuData.map((bucket) => ({
      key: bucket.key,
      label: bucket.label,
      children: bucket.children,
    }));

  // All module routes (for GenericResourcePage)
  const moduleRoutes = menuData
    .flatMap((bucket) => bucket.children)
    .flatMap((sb) => sb.children);

  return (
    <BrowserRouter>
      <Layout style={{ minHeight: "100vh" }}>
        {/* ==============================
            SIDEBAR
        =============================== */}
        <Sider width={250}>
          <Menu mode="inline" items={getMenuItems()} />
        </Sider>

        {/* ==============================
            MAIN CONTENT ROUTER
        =============================== */}
        <Layout>
          <Content style={{ padding: 20 }}>
            <Routes>
              {moduleRoutes.map((route: any) => (
                <Route
                  key={route.key}
                  path={route.key}
                  element={
                    <GenericResourcePage
                      resourceName={route.label.props.children}
                      apiBaseUrl="http://localhost:5017/api"
                      fields={[]} // you can map Swagger fields later
                    />
                  }
                />
              ))}

              <Route path="/" element={<h2>Select a Module</h2>} />
            </Routes>
          </Content>
        </Layout>
      </Layout>
    </BrowserRouter>
  );
};

export default App;

/*
// src/App.tsx
import { useEffect, useState } from "react";
import { Layout, Menu } from "antd";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import { getSwaggerResources, SwaggerResource } from "./utils/swaggerResources";
import { GenericResourcePage } from "./components/GenericResourcePage";

const { Sider, Content } = Layout;
export const App = () => {
    const [resources, setResources] = useState<SwaggerResource[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        getSwaggerResources().then((res) => {
            setResources(res);
            setLoading(false);
        });
    }, []);

    if (loading) return <div>Loading modules...</div>;

    return (
        <BrowserRouter>
            <Layout style={{ minHeight: "100vh" }}>
                <Sider>
                    <Menu mode="inline">
                        {resources.map((res) => (
                            <Menu.Item key={res.name}>
                                <Link to={`/${res.name}`}>{res.name}</Link>
                            </Menu.Item>
                        ))}
                    </Menu>
                </Sider>

                <Layout>
                    <Content>
                        <Routes>
                            {resources.map((res) => (
                                <Route
                                    key={res.name}
                                    path={`/${res.name}`}
                                    element={
                                        <GenericResourcePage
                                            resourceName={res.name}
                                            apiBaseUrl="http://localhost:5017/api"
                                            fields={res.fields}   // <-- NEW
                                        />
                                    }
                                />
                            ))}

                            {/* Default Page * /}
                            <Route path="/" element={<h2>Select a Module</h2>} />
                        </Routes>
                    </Content>
                </Layout>
            </Layout>
        </BrowserRouter>
    );
};

export default App;
*/