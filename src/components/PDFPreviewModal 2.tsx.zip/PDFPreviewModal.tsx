// components/PDFPreviewModal.tsx
import React, { useState, useEffect } from 'react';
import { Modal, Spin, message, Input, Button } from 'antd';
import { PDFViewer, Document, Page, Text, View, StyleSheet } from '@react-pdf/renderer';

const styles = StyleSheet.create({
  page: { padding: 30, fontSize: 12 },
  title: { fontSize: 24, marginBottom: 20, textAlign: 'center' },
  section: { marginBottom: 15 },
  table: {
    width: '100%',
    border: '1px solid #000',
    marginTop: 20,
    flexDirection: 'column',
  },
  tableRow: { flexDirection: 'row', borderBottom: '1px solid #000' },
  tableHeader: { backgroundColor: '#f0f0f0', fontWeight: 'bold' },
  cellItem: { width: '40%', padding: 8, borderRight: '1px solid #000' },
  cellQty: { width: '15%', padding: 8, borderRight: '1px solid #000', textAlign: 'center' },
  cellPrice: { width: '20%', padding: 8, borderRight: '1px solid #000', textAlign: 'right' },
  cellTotal: { width: '25%', padding: 8, textAlign: 'right' },
  totalRow: { marginTop: 20, textAlign: 'right', fontSize: 14 },
});

interface LineItem {
  ProductName: string;
  Quantity: number;
  UnitPrice: number;
  LineTotal: number;
  TaxRate?: number; // Optional: if your items have individual tax rates
}

interface CalculatedQuotationData {
  QuotationNumber: string;
  CustomerName?: string;
  QuotationDate: string;
  ValidUntilDate: string;
  Notes?: string;
  lineItems: LineItem[];
  subTotal: number;
  taxAmount: number;
  totalAmount: number;
}

const QuotationPDFDocument = ({ data }: { data: CalculatedQuotationData }) => (
  <Document>
    <Page size="A4" style={styles.page} wrap>
      <Text style={styles.title}>Sales Quotation #{data.QuotationNumber}</Text>

      <View style={styles.section}>
        <Text>Customer: {data.CustomerName || 'N/A'}</Text>
        <Text>Date: {new Date(data.QuotationDate).toLocaleDateString()}</Text>
        <Text>Valid until: {new Date(data.ValidUntilDate).toLocaleDateString()}</Text>
      </View>

      <View style={styles.table}>
        <View style={[styles.tableRow, styles.tableHeader]}>
          <Text style={styles.cellItem}>Item</Text>
          <Text style={styles.cellQty}>Qty</Text>
          <Text style={styles.cellPrice}>Unit Price</Text>
          <Text style={styles.cellTotal}>Line Total</Text>
        </View>

        {data.lineItems.length > 0 ? (
          data.lineItems.map((item, index) => (
            <View style={styles.tableRow} key={index}>
              <Text style={styles.cellItem}>{item.ProductName}</Text>
              <Text style={styles.cellQty}>{item.Quantity}</Text>
              <Text style={styles.cellPrice}>${Number(item.UnitPrice).toFixed(2)}</Text>
              <Text style={styles.cellTotal}>${Number(item.LineTotal).toFixed(2)}</Text>
            </View>
          ))
        ) : (
          <View style={styles.tableRow}>
            <Text style={{ padding: 8 }}>No items added</Text>
          </View>
        )}
      </View>

      <View style={styles.totalRow}>
        <Text>Subtotal: ${data.subTotal.toFixed(2)}</Text>
        <Text>Tax: ${data.taxAmount.toFixed(2)}</Text>
        <Text style={{ fontSize: 18, marginTop: 10 }}>
          <strong>Total: ${data.totalAmount.toFixed(2)}</strong>
        </Text>
      </View>

      {data.Notes && (
        <View style={{ marginTop: 20 }}>
          <Text><strong>Notes:</strong> {data.Notes}</Text>
        </View>
      )}
    </Page>
  </Document>
);

interface PDFPreviewModalProps {
  open: boolean;
  onClose: () => void;
  quotationData: any;
  onSendEmail: (pdfBlob: Blob, customerEmail: string) => void;
  sending?: boolean;
}

export const PDFPreviewModal: React.FC<PDFPreviewModalProps> = ({
  open,
  onClose,
  quotationData,
  onSendEmail,
  sending = false,
}) => {
  const [calculatedData, setCalculatedData] = useState<CalculatedQuotationData | null>(null);
  const [loadingItems, setLoadingItems] = useState(false);
  const [loadingCompany, setLoadingCompany] = useState(false);
  const [customerEmail, setCustomerEmail] = useState<string>('');

  // Pre-fill email
  useEffect(() => {
    if (open && quotationData) {
      setCustomerEmail(quotationData.customerEmail || quotationData.CustomerEmail || '');
    }
  }, [open, quotationData]);

  useEffect(() => {
    if (!open || !quotationData?.QuotationId) {
      setCalculatedData(null);
      return;
    }

    const fetchAndCalculate = async () => {
      setLoadingItems(true);
      try {
        const res = await fetch(
          `${import.meta.env.VITE_API_BASE_URL}/sp_QuotationLineItems/${quotationData.QuotationId}/For`
        );

        if (!res.ok) throw new Error(`HTTP ${res.status}`);

        const raw = await res.json();
        let items: LineItem[] = [];

        if (Array.isArray(raw)) {
          items = raw;
        } else if (raw && typeof raw === 'object') {
          items = raw.data || raw.items || raw.lineItems || raw.results || [];
          if (items.length === 0 && 'ProductName' in raw) {
            items = [raw as LineItem];
          }
        }

        // Calculate totals from line items
        const subTotal = items.reduce((sum, item) => sum + Number(item.LineTotal || 0), 0);
        const taxAmount = items.reduce((sum, item) => {
          // If each item has its own tax, calculate per item
          const lineTotal = Number(item.LineTotal || 0);
          const taxRate = Number(item.TaxRate || 10) / 100; // default 10% if missing
          const lineSub = lineTotal / (1 + taxRate); // reverse calculate pretax
          return sum + (lineSub * taxRate);
        }, 0);

        const totalAmount = subTotal; // Usually total = subtotal + tax, but if LineTotal includes tax, use subTotal

        setCalculatedData({
          QuotationNumber: quotationData.QuotationNumber,
          CustomerName: quotationData.CustomerName,
          QuotationDate: quotationData.QuotationDate,
          ValidUntilDate: quotationData.ValidUntilDate,
          Notes: quotationData.Notes,
          lineItems: items,
          subTotal,
          taxAmount,
          totalAmount: subTotal + taxAmount, // Adjust if your LineTotal excludes tax
        });

      } catch (err: any) {
        message.error('Failed to load line items: ' + err.message);
        setCalculatedData(null);
      } finally {
        setLoadingItems(false);
      }
    };

    fetchAndCalculate();
  }, [open, quotationData]);
useEffect(() => {
    if (!open || !quotationData?.CompanyId) {
      setCustomerEmail('');
      return;
    }

    const fetchCompanyEmail = async () => {
      setLoadingCompany(true);
      try {
        const res = await fetch(
          `${import.meta.env.VITE_API_BASE_URL}/companies/${quotationData.CompanyId}`
        );

        if (!res.ok) {
          console.warn(`Company not found or error: HTTP ${res.status}`);
          return;
        }

        const companyData = await res.json();

        // Adjust field name based on your API response
        const companyEmail = companyData.Email || companyData.CompanyEmail || companyData.email || '';

        if (companyEmail) {
          setCustomerEmail(companyEmail);
        }
      } catch (err) {
        console.warn('Failed to fetch company email', err);
        // Don't show error to user — just leave field empty or fallback
      } finally {
        setLoadingCompany(false);
      }
    };

    fetchCompanyEmail();
  }, [open, quotationData?.CompanyId]);
  const handleSend = async () => {
    if (!calculatedData) {
      message.warning('No data to send');
      return;
    }

    if (!customerEmail.trim()) {
      message.error('Please enter an email address');
      return;
    }

    try {
      const { pdf } = await import('@react-pdf/renderer');
      const blob = await pdf(<QuotationPDFDocument data={calculatedData} />).toBlob();
      onSendEmail(blob, customerEmail.trim());
    } catch (err) {
      message.error('Failed to generate PDF');
      console.error(err);
    }
  };

  if (!quotationData) return null;

  return (
    <Modal
      title={`Preview Quotation - ${quotationData.QuotationNumber || 'Loading...'}`}
      open={open}
      onCancel={onClose}
      width={1100}
      footer={null}
    >
      {/* <div style={{ marginBottom: 16, display: 'flex', alignItems: 'center', gap: 12 }}>
        <span style={{ fontWeight: 'bold', minWidth: 120 }}>Send to:</span>
        <Input
          placeholder="Enter customer email"
          value={customerEmail}
          onChange={(e) => setCustomerEmail(e.target.value)}
          style={{ flex: 1 }}
          type="email"
        />
      </div> */}
        {/* Email Input with Loading Indicator */}
      <div style={{ marginBottom: 16, display: 'flex', alignItems: 'center', gap: 12 }}>
        <span style={{ fontWeight: 'bold', minWidth: 120 }}>Send to:</span>
        <Input
          placeholder="Enter customer email"
          value={customerEmail}
          onChange={(e) => setCustomerEmail(e.target.value)}
          style={{ flex: 1 }}
          type="email"
          addonAfter={loadingCompany ? <Spin size="small" /> : null}
        />
      </div>
      <div style={{ height: '65vh', position: 'relative', marginBottom: 16 }}>
        {loadingItems ? (
          <div style={{ display: 'flex', height: '100%', alignItems: 'center', justifyContent: 'center' }}>
            <Spin tip="Loading line items..." size="large" />
          </div>
        ) : calculatedData ? (
          <PDFViewer width="100%" height="100%">
            <QuotationPDFDocument data={calculatedData} />
          </PDFViewer>
        ) : (
          <div style={{ textAlign: 'center', padding: 50, color: '#999' }}>
            Unable to load quotation data
          </div>
        )}
      </div>

      <div style={{ textAlign: 'right' }}>
        <Button onClick={onClose} style={{ marginRight: 8 }}>
          Cancel
        </Button>
        <Button
          type="primary"
          onClick={handleSend}
          loading={sending}
          disabled={loadingItems || !customerEmail.trim()}
        >
          Send via Email
        </Button>
      </div>
    </Modal>
  );
};