// components/PDFPreviewModal.tsx
import React, { useState, useEffect } from 'react';
import { Input, Modal, Spin, message } from 'antd';
import { PDFViewer, Document, Page, Text, View, StyleSheet } from '@react-pdf/renderer';

const styles = StyleSheet.create({
  page: { padding: 30, fontSize: 12 },
  title: { fontSize: 24, marginBottom: 20, textAlign: 'center' },
  section: { marginBottom: 15 },
  table: {
    width: '100%',
    border: '1px solid #000',
    marginTop: 20,
    flexDirection: 'column', // ← Ensures rows stack vertically
  },
  tableRow: { flexDirection: 'row', borderBottom: '1px solid #000' },
  tableHeader: { backgroundColor: '#f0f0f0', fontWeight: 'bold' },
  cellItem: { width: '40%', padding: 8, borderRight: '1px solid #000' },
  cellQty: { width: '15%', padding: 8, borderRight: '1px solid #000', textAlign: 'center' },
  cellPrice: { width: '20%', padding: 8, borderRight: '1px solid #000', textAlign: 'right' },
  cellTotal: { width: '25%', padding: 8, textAlign: 'right' },
  totalRow: { marginTop: 20, textAlign: 'right', fontSize: 14 },
});

interface LineItem {
  ProductName: string;
  Quantity: number;
  UnitPrice: number;
  LineTotal: number;
}

interface EnrichedQuotationData {
  QuotationNumber: string;
  CustomerName?: string;
  QuotationDate: string;
  ValidUntilDate: string;
  SubTotal: number;
  TaxAmount: number;
  TotalAmount: number;
  Notes?: string;
  lineItems: LineItem[];
}

const QuotationPDFDocument = ({ data }: { data: EnrichedQuotationData }) => (
  <Document>
    <Page size="A4" style={styles.page} wrap>
      <Text style={styles.title}>Sales Quotation #{data.QuotationNumber}</Text>

      <View style={styles.section}>
        <Text>Customer: {data.CustomerName || 'N/A'}</Text>
        <Text>Date: {new Date(data.QuotationDate).toLocaleDateString()}</Text>
        <Text>Valid until: {new Date(data.ValidUntilDate).toLocaleDateString()}</Text>
      </View>

      <View style={styles.table}>
        <View style={[styles.tableRow, styles.tableHeader]}>
          <Text style={styles.cellItem}>Item</Text>
          <Text style={styles.cellQty}>Qty</Text>
          <Text style={styles.cellPrice}>Unit Price</Text>
          <Text style={styles.cellTotal}>Line Total</Text>
        </View>

        {data.lineItems.length > 0 ? (
          data.lineItems.map((item, index) => (
            <View style={styles.tableRow} key={index}>
              <Text style={styles.cellItem}>{item.ProductName}</Text>
              <Text style={styles.cellQty}>{item.Quantity}</Text>
              <Text style={styles.cellPrice}>${item.UnitPrice.toFixed(2)}</Text>
              <Text style={styles.cellTotal}>${item.LineTotal.toFixed(2)}</Text>
            </View>
          ))
        ) : (
          <View style={styles.tableRow}>
            <Text style={{ padding: 8 }}>No items added</Text>
          </View>
        )}
      </View>

      {/* ALL text must be inside <Text> components */}
      <View style={styles.totalRow}>
        <Text>Subtotal: ${data.SubTotal.toFixed(2)}</Text>
        <Text>Tax: ${data.TaxAmount.toFixed(2)}</Text>
        <Text style={{ fontSize: 18, marginTop: 10 }}>
          Total: ${data.TotalAmount.toFixed(2)}
        </Text>
      </View>

      {data.Notes && (
        <View style={{ marginTop: 20 }}>
          <Text>Notes: {data.Notes}</Text>
        </View>
      )}
    </Page>
  </Document>
);

interface PDFPreviewModalProps {
  open: boolean;
  onClose: () => void;
  quotationData: any;
  onSendEmail: (pdfBlob: Blob) => void;
  sending?: boolean;
}

export const PDFPreviewModal: React.FC<PDFPreviewModalProps> = ({
  open,
  onClose,
  quotationData,
  onSendEmail,
  sending = false,
}) => {
  const [fullData, setFullData] = useState<EnrichedQuotationData | null>(null);
  const [loadingItems, setLoadingItems] = useState(false);
const [customerEmail, setCustomerEmail] = useState<string>('');
  useEffect(() => {
    if (!open || !quotationData) {
      //  console.log("Nada");
      setFullData(null);
      return;
    }
 
    console.log(`quotationData.QuotationId: ` +JSON.stringify(quotationData));
    const fetchLineItems = async () => {
      setLoadingItems(true);

      try {
        const res = await fetch(
          `${import.meta.env.VITE_API_BASE_URL}/sp_QuotationLineItems/${quotationData.QuotationId}/For`
        );

        if (!res.ok) throw new Error(`HTTP ${res.status}`);

        const raw = await res.json();
             //   console.log(JSON.stringify(raw));
        let items: LineItem[] = [];

        if (Array.isArray(raw)) {
          items = raw;
        } else if (raw && typeof raw === 'object') {
          items = raw.data || raw.items || raw.lineItems || raw.results || [];
          if (items.length === 0 && 'ProductName' in raw) {
            items = [raw as LineItem];
          }
        }
 // console.log(JSON.stringify(items));
        setFullData({
          ...quotationData,
          lineItems: items,
        });
      } catch (err: any) {
        message.error('Failed to load line items: ' + err.message);
        setFullData({
          ...quotationData,
          lineItems: [],
        });
      } finally {
        setLoadingItems(false);
      }
    };

    fetchLineItems();
  }, [open, quotationData]);
//   useEffect(() => {
//     if (open && quotationData) {
//       setCustomerEmail(quotationData.customerEmail || quotationData.CustomerEmail || '');
//     }
//   }, [open, quotationData]);
  const handleSend = async () => {

    if (!fullData) return;

    try {
      const { pdf } = await import('@react-pdf/renderer');
      const blob = await pdf(<QuotationPDFDocument data={fullData} />).toBlob();
      onSendEmail(blob);
    } catch (err) {
      message.error('Failed to generate PDF');
    }
  };
// console.log(JSON.stringify('quotationData'));
  if (!quotationData) return null;
  console.log('FullData:' +JSON.stringify(fullData?.lineItems));
  return (
    <Modal
      title={`Preview Quotation - ${quotationData.QuotaionId || 'Loading...'}`}
      open={open}
      onCancel={onClose}
      width={1000}
      footer={[
        <button key="close" type="button" className="ant-btn" onClick={onClose}>
          Close
        </button>,
        <button
          key="send"
          type="button"
          className="ant-btn ant-btn-primary"
          onClick={handleSend}
          disabled={loadingItems || sending}
        >
          {sending ? 'Sending...' : 'Send via Email'}
        </button>,
      ]}
    >
        {/* Email Input Row */}
      <div style={{ marginBottom: 16, display: 'flex', alignItems: 'center', gap: 12 }}>
        <span style={{ fontWeight: 'bold', minWidth: 120 }}>Send to:</span>
        <Input
          placeholder="Enter customer email"
          value={customerEmail}
          onChange={(e) => setCustomerEmail(e.target.value)}
          style={{ flex: 1 }}
          type="email"
        />
      </div>
      <div style={{ height: '75vh', position: 'relative' }}>
        {loadingItems ? (
          <div style={{ display: 'flex', height: '100%', alignItems: 'center', justifyContent: 'center' }}>
            <Spin tip="Loading line items..." size="large" />
          </div>
        ) : fullData ? (
          <PDFViewer width="100%" height="100%">
            <QuotationPDFDocument data={fullData} />
          </PDFViewer>
        ) : (
          <div style={{ textAlign: 'center', padding: 50 }}>
            <Text>Unable to load quotation data</Text>
          </div>
        )}
      </div>
    </Modal>
  );
};