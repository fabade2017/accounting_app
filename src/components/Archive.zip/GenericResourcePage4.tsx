import React, { useEffect, useRef, useState, useCallback, useMemo } from "react";
import {
  Table,
  Button,
  Modal,
  Form,
  Input,
  Select,
  Space,
  message,
  Checkbox,
  Row,
  Col,
  DatePicker,
  InputNumber,
  InputRef,
  Typography,
  Divider,
  Alert,
} from "antd";
import dayjs from "dayjs";
import {
  SearchOutlined,
  PlusOutlined,
  PlusCircleOutlined,
  EditOutlined,
  DeleteOutlined,
  ReloadOutlined,
} from "@ant-design/icons";
import type { FilterConfirmProps } from "antd/es/table/interface";
import { ColumnsType } from "antd/es/table";
import moment from "moment";
import Highlighter from "react-highlight-words";
import { generateQuotationPDF } from "./QuotationPDF";
import { useParams } from "react-router-dom";
import { PDFPreviewModal } from "./PDFPreviewModal";
import { formatProcedureName } from "../utils/formatName";
// import { normalize } from "path";

///////////////


//import { QuotationView } from './QuotationView';
import { normalizeFormValues } from "../utils/normalizeFormValues";


const { Text } = Typography;

interface LookupItem {
  id: string | number;
  label: string;
  [k: string]: any;
}

interface DetailConfig {
  resourceName: string;
  foreignKey: string;
  fields: string[];
  quantityField?: string;
  priceField?: string;
  lineTotalField?: string;
  taxField?: string;
}

interface Props {
  resourceName: string;
  apiBaseUrl?: string;
  fields: string[];
  detailConfig?: DetailConfig;
}

export const GenericResourcePage: React.FC<Props> = ({
  resourceName,
  apiBaseUrl = "",
  fields,
  detailConfig,
}) => {
  apiBaseUrl = import.meta.env.VITE_API_BASE_URL;

  const [data, setData] = useState<Record<string, any>[]>([]);
  const [loading, setLoading] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [editingItem, setEditingItem] = useState<Record<string, any> | null>(null);
  const [lookupData, setLookupData] = useState<Record<string, LookupItem[]>>({});
  const [fieldsForLookup, setFieldsForLookup] = useState<Record<string, string[]>>({});
  const [form] = Form.useForm();
  const [showAllFields, setShowAllFields] = useState(false);
  const [rowColor, setRowColor] = useState("#ffffff");
  const [globalSearch, setGlobalSearch] = useState("");
  const [searchText, setSearchText] = useState("");
  const [searchedColumn, setSearchedColumn] = useState("");
  const [sortedInfo, setSortedInfo] = useState<{ columnKey?: string; order?: "ascend" | "descend" }>({});
  const searchInput = useRef<InputRef>(null);
  const loggedInUserId = Number(localStorage.getItem("userid") || 0);
  const [lookupModalVisible, setLookupModalVisible] = useState(false);
  const [lookupModalField, setLookupModalField] = useState<string | null>(null);
  const [lookupForm] = Form.useForm();
  const isReport = resourceName.toLowerCase().includes("report");
  const { id } = useParams<{ id: string }>();
  const [lineItemRows, setLineItemRows] = useState<any[]>([]);
  const [isHaveChild, setHasChild] = useState(false);

  const [detailConfigState, setDetailConfigState] = useState<DetailConfig | undefined>(detailConfig);
  const effectiveDetailConfig = detailConfig || detailConfigState;
// const normalize = (s: string) =>
//   s.toLowerCase().replace(/[^a-z0-9]/g, "");

// const singularize = (name: string) => {
//   if (name.endsWith("ies")) return name.slice(0, -3) + "y";
//   if (name.endsWith("ses")) return name.slice(0, -2);
//   if (name.endsWith("s")) return name.slice(0, -1);
//   return name;
// };

  const isMaster = useMemo(() => !!effectiveDetailConfig, [effectiveDetailConfig]);

  const isLikelyChildTable = (name: string): boolean => {
    const lower = name.toLowerCase();
    return (
      lower.includes("lineitem") ||
      lower.includes("lines") ||
      lower.includes("detail") ||
      lower.endsWith("lines") ||
      lower.endsWith("lineitems") ||
      lower.endsWith("details")
    );
  };

  const qtyField = effectiveDetailConfig?.quantityField || "quantity";
  const priceField = effectiveDetailConfig?.priceField || "price";
  const lineTotalField = effectiveDetailConfig?.lineTotalField || "lineTotal";
  const taxField = effectiveDetailConfig?.taxField;

  const [excludedLookupFields, setExcludedLookupFields] = useState<string[]>([]);
  const [expandedRowKeys, setExpandedRowKeys] = useState<string[]>([]);
  const [expandedLines, setExpandedLines] = useState<Record<string, any[]>>({});
  const [warning, setWarning] = useState("");
  const [lineWarning, setLineWarning] = useState("");
  const [lineModalVisible, setLineModalVisible] = useState(false);
  const [currentMaster, setCurrentMaster] = useState<Record<string, any> | null>(null);
  const [lineForm] = Form.useForm();

  // States for editing a single line item
  const [lineEditModalVisible, setLineEditModalVisible] = useState(false);
  const [editingLineIndex, setEditingLineIndex] = useState<number | null>(null);
  const [lineEditForm] = Form.useForm();

  const [quotationData, setQuotationData] = useState<any>(null);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [pdfBlob, setPdfBlob] = useState<Blob | null>(null);
  const [sending, setSending] = useState(false);
  const [selectedQuotation, setSelectedQuotation] = useState<any>(null);

  const isQuotation = resourceName.includes("quotations") || resourceName.includes("quotes");
  const { quoteId } = useParams<{ quoteId: string }>();

  /* ==================== Check if resource has child records ==================== */
  useEffect(() => {
    const checkHasChild = async () => {
      setHasChild(false);
      try {
        const res = await fetch(`${import.meta.env.VITE_API_BASE_URL}/procedures/ishavechild`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ tableName: resourceName || "" }),
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();
        if (data?.[0]?.counters === 1) setHasChild(true);
      } catch (error) {
        console.error("Error checking child records:", error);
        setHasChild(false);
      }
    };
    if (resourceName) checkHasChild();
  }, [resourceName]);

  /* ==================== Auto-detect detail config ==================== */
  useEffect(() => {
    setDetailConfigState(undefined);
    if (detailConfig) {
      setDetailConfigState(detailConfig);
    } else if (!isReport) {
      (async () => {
        const detected = await resolveDetailConfig(resourceName);
        setDetailConfigState(detected || undefined);
      })();
    }
  }, [resourceName, detailConfig, isReport]);

  /* ==================== Helpers ==================== */
  const shadeColor = (color: string, percent: number) => {
    let R = parseInt(color.substring(1, 3), 16);
    let G = parseInt(color.substring(3, 5), 16);
    let B = parseInt(color.substring(5, 7), 16);
    R = Math.min(255, Math.max(0, Math.round(R + R * percent)));
    G = Math.min(255, Math.max(0, Math.round(G + G * percent)));
    B = Math.min(255, Math.max(0, Math.round(B + B * percent)));
    return `#${R.toString(16).padStart(2, "0")}${G.toString(16).padStart(2, "0")}${B.toString(16).padStart(2, "0")}`;
  };

  const getRowKey = (record: Record<string, any>) => {
    const idField = fields.find((f) => f.toLowerCase().endsWith("id"));
    return idField && record[idField] !== undefined ? String(record[idField]) : JSON.stringify(record);
  };

  /* ==================== Data Fetching ==================== */
  const fetchData = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${import.meta.env.VITE_API_BASE_URL}/${resourceName}`);
      const json = await res.json();
      const newData = Array.isArray(json)
        ? json
        : Array.isArray(json?.data)
        ? json.data
        : Array.isArray(json?.items)
        ? json.items
        : [];
      setData(newData);
    } catch (err) {
      message.error("Failed to load data");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isReport) {
      // runReport logic if needed
    } else {
      fetchData();
    }
    // fetchLookups(); // if you have this function, call it here
  }, [resourceName]);

  /* ==================== Line Item Management ==================== */
  const handleManageLines = async (record: Record<string, any>) => {
    setCurrentMaster(record);
    setLoading(true);
    try {
      const did = Number(record[fields[0]]);
      const lines = await fetchLineItems(did, effectiveDetailConfig!);
      const normalizedLines = lines.map((line: any) => {
        const obj: any = {};
        effectiveDetailConfig!.fields.forEach((f) => {
          const val = line[f];
          if (val == null) return;
          if (/id$/i.test(f)) obj[f] = Number(val);
          else if (/date|month|edat|at/i.test(f)) {
            const d = dayjs(val);
            obj[f] = d.isValid() ? d : undefined;
          } else obj[f] = val;
        });
        return obj;
      });
      lineForm.setFieldsValue({ lineItems: normalizedLines.length ? normalizedLines : [] });
    } catch (err) {
      console.error("Failed to load line items", err);
      lineForm.setFieldsValue({ lineItems: [] });
    } finally {
      setLoading(false);
      setLineModalVisible(true);
    }
  };

  const fetchLineItems = async (parentId: number, config: DetailConfig) => {
    if (!config) return [];
    const resname = config.resourceName.replace("lineitems", "LineItems");
    const url = `${import.meta.env.VITE_API_BASE_URL}/sp_${resname}/${parentId}/For`;
    try {
      const res = await fetch(url);
      const text = await res.text();
      if (!text) return [];
      const json = JSON.parse(text);
      if (Array.isArray(json)) return json;
      if (Array.isArray(json?.data)) return json.data;
      if (Array.isArray(json?.items)) return json.items;
      if (Array.isArray(json?.results)) return json.results;
    } catch (e) {
      console.error("fetchLineItems error", e);
    }
    return [];
  };

  const handleInlineDelete = async (index: number) => {
    const values = lineForm.getFieldValue("lineItems") || [];
    const line = values[index];
    const pkField = effectiveDetailConfig!.fields[0];
    const lineId = line?.[pkField];

    if (lineId) {
      try {
        await fetch(`${import.meta.env.VITE_API_BASE_URL}/${effectiveDetailConfig!.resourceName}/${lineId}`, {
          method: "DELETE",
        });
      } catch (err) {
        message.error("Failed to delete line item");
        return;
      }
    }

    const updated = [...values];
    updated.splice(index, 1);
    lineForm.setFieldsValue({ lineItems: updated });
  };

  const handleEditLine = (index: number) => {
    const lines = lineForm.getFieldValue("lineItems") || [];
    const lineToEdit = lines[index];
    lineEditForm.setFieldsValue(lineToEdit);
    setEditingLineIndex(index);
    setLineEditModalVisible(true);
  };

  const handleSaveEditedLine = async () => {
    try {
      const values = await lineEditForm.validateFields();
      const lines = lineForm.getFieldValue("lineItems") || [];
      const updatedLines = [...lines];
      updatedLines[editingLineIndex!] = values;
      lineForm.setFieldsValue({ lineItems: updatedLines });
      message.success("Line item updated");
      setLineEditModalVisible(false);
      setEditingLineIndex(null);
      lineEditForm.resetFields();
    } catch (err) {
      console.error("Validation failed:", err);
    }
  };

  const handleSaveLines = async () => {
    try {
      const values = await lineForm.validateFields();
      const lines = values.lineItems || [];
      const parentId = currentMaster![fields[0]];
      const lineResource = effectiveDetailConfig!.resourceName;

      // Delete old lines
      const currentLines = await fetchLineItems(parentId, effectiveDetailConfig!);
      for (const oldLine of currentLines) {
        const pkField = effectiveDetailConfig!.fields[0];
        const oldId = oldLine[pkField];
        if (oldId) {
          await fetch(`${import.meta.env.VITE_API_BASE_URL}/${lineResource}/${oldId}`, { method: "DELETE" }).catch(() => {});
        }
      }

      // Create new lines
      for (const line of lines) {
        const normalizedLine: any = {};
        Object.keys(line).forEach((key) => {
          normalizedLine[key] = line[key];
        });
        normalizedLine[effectiveDetailConfig!.foreignKey] = parentId;
        const res = await fetch(`${import.meta.env.VITE_API_BASE_URL}/${lineResource}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(normalizedLine),
        });
        if (!res.ok) {
          const errText = await res.text();
          throw new Error(errText || "Save failed");
        }
      }

      message.success("Line items saved successfully");
      setLineModalVisible(false);
      lineForm.resetFields();
      setCurrentMaster(null);
      fetchData(); // Refresh main table
    } catch (err: any) {
      message.error(err.message || "Failed to save line items");
    }
  };

  /* ==================== Render Form Items ==================== */
  const renderFormItemComponent = (f: string, _isLineItem = false) => {
    const lower = f.toLowerCase();
    const isLookup =
      (lower.endsWith("id") || lower.endsWith("status") || lower.endsWith("by")) &&
      !excludedLookupFields.some((ex) => lower.endsWith(ex));
    const isNumber = /amount|price|total|qty|quantity|rate|balance|cost/i.test(lower);
    const isDate = lower.includes("date") || lower.endsWith("at") || lower.includes("month");

    if (isLookup && lookupData[f]) {
      const options = lookupData[f].map((i) => ({ label: i.label, value: i.id }));
      return <Select options={options} showSearch allowClear />;
    }
    if (isNumber) {
      return (
        <InputNumber
          style={{ width: "100%" }}
          formatter={(v) => `${v}`.replace(/\B(?=(\d{3})+(?!\d))/g, ",")}
          parser={(v) => v?.replace(/,/g, "") || ""}
        />
      );
    }
    if (isDate) {
      return <DatePicker style={{ width: "100%" }} format="YYYY-MM-DD" />;
    }
    return <Input placeholder={`Enter ${f}`} />;
  };

  /* ==================== Line Items Table Columns ==================== */
  const lineItemColumns: ColumnsType<any> = [
    {
      title: "Actions",
      width: 130,
      fixed: "left",
      render: (_: any, __: any, index: number) => (
        <Space>
          <Button type="link" icon={<EditOutlined />} size="small" onClick={() => handleEditLine(index)} />
          <Button danger type="link" icon={<DeleteOutlined />} size="small" onClick={() => handleInlineDelete(index)} />
        </Space>
      ),
    },
    ...effectiveDetailConfig!.fields.map((f) => ({
      title: f,
      width: 200,
      render: (_: any, __: any, index: number) => (
        <Form.Item name={[index, f]} noStyle>
          {renderFormItemComponent(f, true)}
        </Form.Item>
      ),
    })),
  ];

  /* ==================== Main Table Columns ==================== */
  const dynamicFields = data.length > 0 ? Object.keys(data[0]).filter((k) => typeof data[0][k] !== "object") : fields;
  const sortedDynamicFields = [...dynamicFields].sort((a, b) => {
    const lowerA = a.toLowerCase();
    const lowerB = b.toLowerCase();
    if (lowerA.endsWith("id")) return -1;
    if (lowerB.endsWith("id")) return 1;
    return a.localeCompare(b);
  });

  const columns: ColumnsType<Record<string, any>> = [
    {
      title: "Actions",
      key: "actions",
      fixed: "left",
      width: 160,
      render: (_: any, record: any) => (
        <Space>
          <Button type="link" onClick={() => handleEdit(record)}>
            Edit
          </Button>
          {isMaster && isHaveChild && (
            <Button type="link" onClick={() => handleManageLines(record)}>
              Lines
            </Button>
          )}
          {isQuotation && <Button type="link" onClick={() => openPreview(record)}>Preview / Send</Button>}
          <Button type="link" danger onClick={() => handleDelete(record)}>
            Delete
          </Button>
        </Space>
      ),
    },
    ...sortedDynamicFields.slice(0, showAllFields ? undefined : 6).map((f) => ({
      title: f,
      dataIndex: f,
      key: f,
      render: (value: any) => (value ?? "-").toString(),
    })),
  ];

  const handleEdit = (record: Record<string, any>) => {
    form.setFieldsValue(record);
    setEditingItem(record);
    setModalVisible(true);
  };

  const handleDelete = async (record: Record<string, any>) => {
    try {
      await fetch(`${import.meta.env.VITE_API_BASE_URL}/${resourceName}/${getRowKey(record)}`, { method: "DELETE" });
      message.success("Deleted successfully");
      fetchData();
    } catch {
      message.error("Delete failed");
    }
  };

  const closeModal = () => {
    setModalVisible(false);
    setEditingItem(null);
    form.resetFields();
  };

  const openPreview = (record: any) => {
    setSelectedQuotation(record);
    setPreviewOpen(true);
  };

  /* ==================== JSX ==================== */
  return (
    <div style={{ padding: 20 }}>
      <Row style={{ marginBottom: 16 }} justify="space-between" align="middle">
        <Col>
          <Space>
            <Button
              type="primary"
              icon={<PlusOutlined />}
              onClick={() => {
                form.resetFields();
                setEditingItem(null);
                setModalVisible(true);
              }}
            >
              Add {formatProcedureName(resourceName)}
            </Button>
            <Button icon={<ReloadOutlined />} onClick={fetchData} loading={loading}>
              Refresh
            </Button>
          </Space>
        </Col>
        <Col>
          <Input
            placeholder="Search..."
            prefix={<SearchOutlined />}
            allowClear
            value={globalSearch}
            onChange={(e) => setGlobalSearch(e.target.value)}
            style={{ width: 300 }}
          />
        </Col>
      </Row>

      <Table
        dataSource={globalSearch ? data.filter((i) => JSON.stringify(i).toLowerCase().includes(globalSearch.toLowerCase())) : data}
        columns={columns}
        rowKey={getRowKey}
        loading={loading}
        scroll={{ x: "max-content" }}
        expandable={
          isMaster && !isLikelyChildTable(resourceName) && isHaveChild ? {} : undefined
        }
      />

      {/* Main Edit Modal */}
      <Modal title={editingItem ? "Edit" : "Add"} open={modalVisible} width={1200} onCancel={closeModal} onOk={() => form.submit()}>
        <Form form={form} layout="vertical">
          <Row gutter={16}>
            {fields.map((f, idx) => (
              <Col span={8} key={f}>
                <Form.Item label={f} name={f}>
                  {renderFormItemComponent(f)}
                </Form.Item>
              </Col>
            ))}
          </Row>
        </Form>
      </Modal>

      {/* Manage Line Items Modal */}
      <Modal
        title={`Manage Line Items - ${currentMaster?.[fields[0]] || ""}`}
        open={lineModalVisible}
        width={1400}
        onCancel={() => {
          setLineModalVisible(false);
          lineForm.resetFields();
          setCurrentMaster(null);
        }}
        onOk={() => lineForm.submit()}
        destroyOnClose
      >
        <Form form={lineForm} onFinish={handleSaveLines} layout="vertical">
          <Form.List name="lineItems">
            {(fields, { add }) => (
              <>
                <Table
                  dataSource={fields}
                  columns={lineItemColumns}
                  pagination={false}
                  rowKey={(f) => f.key}
                  scroll={{ y: 500 }}
                />
                <Button type="dashed" onClick={() => add()} block icon={<PlusCircleOutlined />} style={{ marginTop: 16 }}>
                  Add Line Item
                </Button>
              </>
            )}
          </Form.List>
        </Form>
      </Modal>

      {/* Edit Single Line Item Modal */}
      <Modal
        title="Edit Line Item"
        open={lineEditModalVisible}
        width={1000}
        onCancel={() => {
          setLineEditModalVisible(false);
          setEditingLineIndex(null);
          lineEditForm.resetFields();
        }}
        onOk={() => lineEditForm.submit()}
        destroyOnClose
      >
        <Form form={lineEditForm} onFinish={handleSaveEditedLine} layout="vertical">
          <Row gutter={16}>
            {effectiveDetailConfig?.fields.map((f) => (
              <Col span={8} key={f}>
                <Form.Item label={f} name={f}>
                  {renderFormItemComponent(f, true)}
                </Form.Item>
              </Col>
            ))}
          </Row>
        </Form>
      </Modal>

      {/* PDF Preview Modal */}
      {isQuotation && selectedQuotation && (
        <PDFPreviewModal
          open={previewOpen}
          onClose={() => setPreviewOpen(false)}
          quotationData={selectedQuotation}
          onSendEmail={handleSendEmail}
          sending={sending}
        />
      )}
    </div>
  );
};
const normalize = (s: string) =>
  s.toLowerCase().replace(/[^a-z0-9]/g, "");

const singularize = (name: string) => {
  if (name.endsWith("ies")) return name.slice(0, -3) + "y";
  if (name.endsWith("ses")) return name.slice(0, -2);
  if (name.endsWith("s")) return name.slice(0, -1);
  return name;
};

const resolveDetailConfig = async (  
  resourceName: string
): Promise<DetailConfig | null> => {
  const normalizedMaster = normalize(resourceName); // e.g., "quotations" → "quotations"
  const singularMaster = singularize(normalizedMaster); // "quotations" → "quotation"

  console.log(`[Auto-Detect] Resolving detail config for master: ${resourceName} (singular: ${singularMaster})`);
  //console.log(` Fields::`,JSON.stringify(fields));
  // Helper to test a candidate endpoint
  const testCandidate = async (candidate: string): Promise<DetailConfig | null> => {
    const urlsToTry = [
      `${import.meta.env.VITE_API_BASE_URL}/schema/table/${candidate}`//,
      //   `${import.meta.env.VITE_API_BASE_URL}/schema/table/${candidate}`
   //   `${import.meta.env.VITE_API_BASE_URL}/${candidate}`,
   //   `${import.meta.env.VITE_API_BASE_URL}/sp_${candidate.charAt(0).toUpperCase() + candidate.slice(1)}`,
  //    `${import.meta.env.VITE_API_BASE_URL}/sp_${candidate.toUpperCase()}`,
    ];
  console.log(`Fields::RRRRR||`,JSON.stringify(fields));
    for (const url of urlsToTry) {
      try {
        console.log(`[Auto-Detect] Trying: ${url}`);
        const res = await fetch(url);

        if (!res.ok) {
          console.log(`[Auto-Detect] ${url} → ${res.status}`);
          continue;
        }

        const text = await res.text();
        if (!text.trim()) {
          console.log(`[Auto-Detect] ${url} → empty response`);
          continue;
        }

        let data;
        try {
          data = JSON.parse(text);
        } catch {
          console.log(`[Auto-Detect] ${url} → invalid JSON`);
          continue;
        }

        if (!Array.isArray(data)) {
          console.log(`[Auto-Detect] ${url} → not an array`);
          continue;
        }

        // console.log(`[Auto-Detect] SUCCESS: ${url} → ${data.length} rows`);

        // Determine fields: use first row if exists, otherwise assume common ones later
       const fields = data.length > 0 ? Object.keys(data[0]) : [];
   // const fields = await res.json();
    console.log(`[Auto-Detect] SUCCESS: ${url} → ${data.length} rows`);
        // Find foreign key: look for column containing singular master name + "Id"
        let foreignKey = fields.find(f =>
          normalize(f).includes(singularMaster) && normalize(f).endsWith("id")
        );

        // Fallback patterns
        if (!foreignKey) {
          foreignKey = fields.find(f => normalize(f).endsWith("id")) ||
                       `${singularMaster}Id`;
        }
        console.log(`Fields::PPPPP-`,JSON.stringify(fields));
        // Auto-detect common fields
        const quantityField = fields.find(f => /quantity|qty|ordered|received/i.test(f)) || "Quantity";
        const priceField = fields.find(f => /price|rate|cost|unitprice/i.test(f)) || "UnitPrice";
        const lineTotalField = fields.find(f => /total|amount|linetotal/i.test(f)) || "LineTotal";
        const taxField = fields.find(f => /tax|vat/i.test(f));

        return {
          resourceName: candidate,
          foreignKey,
          fields: fields.length > 0 ? fields : [
            foreignKey,
            'ProductId',
            quantityField,
            priceField,
            lineTotalField,
            taxField ?? 'TaxRate'
          ].filter(Boolean),
          quantityField,
          priceField,
          lineTotalField,
          taxField,
        };
      } catch (err) {
        console.log(`[Auto-Detect] Error fetching ${url}:`, err);
      }
    }

    return null;
  };

  // Priority order of candidates (most likely first)
  const candidates = [
    `${singularMaster}lineitems`,        // quotationlineitems     ← most common in your code
    `${singularMaster}lines`,            // quotationlines
    `${singularMaster}details`,          // quotationdetails
    `${normalizedMaster}lineitems`,      // quotationslineitems
    `${normalizedMaster}lines`,
    `${singularMaster}LineItems`,        // QuotationLineItems (capitalized)
    `${normalizedMaster}LineItems`,
  ];

  for (const candidate of candidates) {
    const result = await testCandidate(candidate);
    if (result) {
      console.log(`[Auto-Detect] Detected detail config:`, result);
      return result;
    }
  }

  console.warn(`[Auto-Detect] No detail table found for ${resourceName}`);
  return null;
};

export default GenericResourcePage;