// src/components/WidgetModal.tsx
import { Modal, Form, Input, InputNumber, Button, Select, message, Row, Col } from "antd";
import { useEffect, useState } from "react";

const { Option } = Select;

interface Widget {
  DashboardWidgetId: number;
  DashboardId: number;
  WidgetId: number;
  WidgetName?: string;
  Type?: string;
  Settings: string;
  PositionX: number;
  PositionY: number;
  Width: number;
  Height: number;
}

interface ProcParam {
  name: string;
  type: "string" | "number";
  required: boolean;
}

interface Procedure {
  ProcedureId: number;
  ProcedureName: string;
}

interface WidgetModalProps {
  modalVisible: boolean;
  setModalVisible: (v: boolean) => void;
  editingWidget: Widget | null;
  setEditingWidget: (w: Widget | null) => void;
  form: any;
  procParamsDef: ProcParam[];
  setProcParamsDef: (v: ProcParam[]) => void;
  previewData: any[];
  setPreviewData: (v: any[]) => void;
  selectedProc: number | null;
  setSelectedProc: (v: number | null) => void;
  procedures: Procedure[];
  callProcAndGetResultSets: (procName: string, params: Record<string, any>) => Promise<any[]>;
  onSave: (widget: Widget) => void;
}

export const WidgetModal = ({
  modalVisible,
  setModalVisible,
  editingWidget,
  setEditingWidget,
  form,
  procParamsDef,
  setProcParamsDef,
  previewData,
  setPreviewData,
  selectedProc,
  setSelectedProc,
  procedures,
  callProcAndGetResultSets,
  onSave
}: WidgetModalProps) => {
  const [loadingPreview, setLoadingPreview] = useState(false);

  useEffect(() => {
       console.log("Simpler1111" +":"+ modalVisible +":"+ selectedProc);
    if (modalVisible && selectedProc) {
      fetchProcParams(selectedProc);
    }
  }, [modalVisible, selectedProc]);

  // -------------------- Fetch procedure parameters --------------------
  const fetchProcParams = async (procId: number | string) => {

      
    try {
      if (!procId) return;

      const res = await fetch(`http://localhost:5017/api/proceduremetadata/${procId}`);
      if (!res.ok) throw new Error(`Failed to fetch params: ${res.status}`);

      const data: {
        ProcedureId: number;
        ProcedureName: string;
        Parameters: Array<{ ParameterName: string; ParameterType: string; IsRequired: boolean }>;
      } = await res.json();
  
    console.log(JSON.stringify(data));
      const paramsDef: ProcParam[] = data.Parameters.map(p => ({
        name: p.ParameterName.replace(/^@/, ""), // remove @ prefix if any
        type: ["int", "decimal"].includes(p.ParameterType.toLowerCase()) ? "number" : "string",
        required: p.IsRequired
      }));

      setProcParamsDef(paramsDef);

      // Initialize form fields
      const initialValues: Record<string, any> = {};
      paramsDef.forEach(p => initialValues[p.name] = '');
      form.setFieldsValue({ proc: data.ProcedureName, params: initialValues });

      if (paramsDef.length === 0) console.warn("No params found for:", data.ProcedureName);
    } catch (err) {
      console.error("Failed to fetch procedure params", err);
      message.error("Failed to fetch procedure parameters");
      setProcParamsDef([]);
    }
  };

  // -------------------- Preview data --------------------
  const handlePreview = async () => {
    try {
      const values = form.getFieldsValue();
      const params = values.params || {};
      setLoadingPreview(true);
      const data = await callProcAndGetResultSets(values.proc, params);
      setPreviewData(data);
    } catch (err) {
      console.error(err);
      message.error("Failed to fetch preview data");
    } finally {
      setLoadingPreview(false);
    }
  };

  // -------------------- Save widget --------------------
  const handleOk = async () => {
    try {
      const values = form.getFieldsValue();
      const widgetSettings = { proc: values.proc, params: values.params || {}, chartType: values.chartType };

      let newWidget: Widget;
      if (editingWidget) {
        newWidget = { ...editingWidget, Settings: JSON.stringify(widgetSettings) };
        onSave(newWidget); // update parent state
      } else {
        newWidget = {
          DashboardWidgetId: 0,
          DashboardId: 2, // or pass dynamically
          WidgetId: 0,
          WidgetName: values.WidgetName || "New Widget",
          Type: "Chart",
          Settings: JSON.stringify(widgetSettings),
          PositionX: 0,
          PositionY: 0,
          Width: 2,
          Height: 2
        };

        // Persist to backend
        const res = await fetch(`http://localhost:5017/api/dashboardwidgets`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(newWidget)
        });
        const saved = await res.json();
        onSave(saved);
      }

      message.success("Widget saved!");
      setModalVisible(false);
      setEditingWidget(null);
      form.resetFields();
    } catch (err) {
      console.error(err);
      message.error("Failed to save widget");
    }
  };

  return (
    <Modal
      title={editingWidget ? "Edit Widget" : "Add Widget"}
      open={modalVisible}
      onCancel={() => { setModalVisible(false); form.resetFields(); setEditingWidget(null); }}
      onOk={handleOk}
      width={600}
      okText="Save"
    >
      <Form form={form} layout="vertical">
        <Form.Item label="Widget Name" name="WidgetName" rules={[{ required: true, message: "Enter widget name" }]}>
          <Input />
        </Form.Item>

        <Form.Item label="Procedure" name="proc" rules={[{ required: true, message: "Select procedure" }]}>
          <Select
            placeholder="Select a procedure"
            onChange={(v: number) => { setSelectedProc(v); fetchProcParams(v); }}
          >
            {procedures.map(p => (
              <Option key={p.ProcedureId} value={p.ProcedureId}>
                {p.ProcedureName.replace(/^sp_/i, "")}
              </Option>
            ))}
          </Select>
        </Form.Item>
{/* // -------------------- Procedure quick-add dropdown --------------------
<Col>
  <Select
    style={{ width: 240 }}
    placeholder="Quick-add proc"
    onChange={(v) => {
      setSelectedProc(Number(v));
      setModalVisible(true);
      form.setFieldsValue({ proc: procedures.find(p => p.ProcedureId === Number(v))?.ProcedureName });
    }}
  >
    {procedures.length > 0 ? procedures.map(p => (
      <Option key={p.ProcedureId} value={p.ProcedureId}>
        {p.ProcedureName.replace(/^sp_/i, "")}
      </Option>
    )) : <Option key="manual" value="">(manual entry)</Option>}
  </Select>
</Col> */}
        {procParamsDef.length > 0 && (
          <div>
            <h4>Parameters:</h4>
            {procParamsDef.map(p => (
              <Form.Item
                key={p.name}
                label={p.name}
                name={['params', p.name]}
                rules={[{ required: p.required, message: `${p.name} is required` }]}
              >
                {p.type === "number" ? <InputNumber style={{ width: "100%" }} /> : <Input />}
              </Form.Item>
            ))}
          </div>
        )}

        <Form.Item label="Chart Type" name="chartType">
          <Select>
            <Option value="bar">Bar</Option>
            <Option value="line">Line</Option>
            <Option value="pie">Pie</Option>
            <Option value="table">Table</Option>
            <Option value="card">Card</Option>
          </Select>
        </Form.Item>

        <Row justify="end" gutter={8}>
          <Col>
            <Button onClick={handlePreview} loading={loadingPreview}>Preview</Button>
          </Col>
        </Row>

        {previewData.length > 0 && (
          <div style={{ marginTop: 16, maxHeight: 200, overflow: "auto" }}>
            <pre>{JSON.stringify(previewData, null, 2)}</pre>
          </div>
        )}
      </Form>
    </Modal>
  );
};
