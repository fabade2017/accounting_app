import { Table, Button, Modal, Form, Input, Select, Space, message, Checkbox, Row, Col, DatePicker, InputNumber } from "antd";
import { ColumnsType } from "antd/es/table";
import { useEffect, useState } from "react";
import moment from "moment";

interface Props {
    resourceName: string;
    apiBaseUrl?: string;
    fields: string[];
}

interface LookupItem {
    id: string | number;
    label: string;
}

export const GenericResourcePage = ({ resourceName, apiBaseUrl = "", fields }: Props) => {
    const [data, setData] = useState<Record<string, any>[]>([]);
    const [loading, setLoading] = useState(false);
    const [modalVisible, setModalVisible] = useState(false);
    const [editingItem, setEditingItem] = useState<Record<string, any> | null>(null);
    const [lookupData, setLookupData] = useState<Record<string, LookupItem[]>>({});
    const [fieldsForLookup, setFieldsForLookup] = useState<Record<string, string[]>>({});
    const [form] = Form.useForm();

    const isReport = resourceName.toLowerCase().includes("report");
    const [reportParams, setReportParams] = useState<Record<string, any>>({});
    const [reportData, setReportData] = useState<any[]>([]);
    const loggedInUserId = Number(localStorage.getItem("userId") || 0); // current user id

    const fetchData = async () => {
        setLoading(true);
        try {
            const res = await fetch(`${apiBaseUrl}/${resourceName}`);
            const json: Record<string, any>[] = await res.json();
            setData(json);
        } catch (err) {
            console.error(err);
            message.error("Failed to load data");
        } finally {
            setLoading(false);
        }
    };

    const runReport = async () => {
        setLoading(true);
        try {
            const res = await fetch(`${apiBaseUrl}/procedures/${resourceName}`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(reportParams)
            });
            const json = await res.json();
            setReportData(json);
        } catch (err) {
            message.error("Failed to run report");
        } finally {
            setLoading(false);
        }
    };

    const fetchLookups = async () => {
        const newLookup: Record<string, LookupItem[]> = {};
        for (const f of fields.filter(f => f.toLowerCase().endsWith("id") || f.toLowerCase().endsWith("by"))) {
            let endpoint = f.replace(/\s/g, '');
            if (endpoint.toLowerCase().endsWith('by')) endpoint = "users";
            if (endpoint.toLowerCase().endsWith('accountid')) endpoint = "bankaccounts";
            if (endpoint.toLowerCase().endsWith("yid")) endpoint = endpoint.replace("yId", "ies");
            if (endpoint.toLowerCase().endsWith("y")) endpoint = endpoint.replace(/y$/i, "ies");
            if (endpoint.toLowerCase().endsWith("ssid")) endpoint = endpoint.replace(/ssId$/i, "sses");
            if (endpoint.toLowerCase().endsWith("id")) endpoint = endpoint.replace(/Id$/i, "s");

            try {
                const res = await fetch(`${apiBaseUrl}/${endpoint}`);
                const items: Record<string, any>[] = await res.json();
                newLookup[f] = items.map(i => {
                    const keys = Object.keys(i);
                    const labelParts = keys.slice(1, 4).map(k => i[k]).filter(Boolean);
                    if (labelParts.length === 0 && keys[0]) labelParts.push(String(i[keys[0]]));
                    return { id: i.id ?? Number(i[keys[0]]), label: labelParts.join(" - ") };
                });
                if (items.length > 0) setFieldsForLookup(prev => ({ ...prev, [f]: Object.keys(items[0]) }));
            } catch (err) {
                console.error(`Failed to fetch lookup for ${f}:`, err);
            }
        }
        setLookupData(newLookup);
    };

    useEffect(() => {
        if (isReport) { runReport() } else { fetchData(); }
        fetchLookups();
    }, [resourceName]);

    useEffect(() => {
        if (editingItem && Object.keys(lookupData).length > 0) {
            const values = { ...editingItem };
            fields.forEach(f => {
                if (f.toLowerCase().endsWith("id") && values[f] != null) values[f] = Number(values[f]);
                if (f.toLowerCase().includes("date") && values[f]) values[f] = moment(values[f]);
                if (f.toLowerCase().includes("year") && values[f]) values[f] = moment(values[f], "YYYY");
                if (f.toLowerCase().includes("month") && values[f]) values[f] = moment(values[f], "YYYY-MM");
            });
            form.setFieldsValue(values);
        }
    }, [editingItem, lookupData]);

    const getRowKey = (record: Record<string, any>) => {
        const idField = fields.find(f => f.toLowerCase().endsWith("id"));
        return idField && record[idField] !== undefined ? String(record[idField]) : JSON.stringify(record);
    };

    const handleSave = async (values: Record<string, any>) => {
        // Format date fields and assign "by" field for add
        fields.forEach(f => {
            if (values[f] && moment.isMoment(values[f])) values[f] = values[f].format("YYYY-MM-DD");
            if (!editingItem && f.toLowerCase().includes("by")) {
                values[f] = loggedInUserId;
            }
        });

        let method = "POST";
        let url = `${apiBaseUrl}/${resourceName}`;

        if (editingItem) {
            method = "PUT";
            const pkField = fields[0]; // assume first field is PK
            const pkValue = editingItem[pkField];
            delete values[pkField];
            url = `${apiBaseUrl}/${resourceName}/${pkValue}`;
        }

        try {
            const res = await fetch(url, {
                method,
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(values)
            });
            if (!res.ok) throw new Error("Save failed");
            message.success("Saved successfully");
        } catch (err) {
            console.error(err);
            message.error("Save failed");
        } finally {
            setModalVisible(false);
            setEditingItem(null);
            form.resetFields();
            fetchData();
        }
    };

    const handleEdit = (record: Record<string, any>) => {
        const values = { ...record };
        fields.filter(f => f.toLowerCase().endsWith("id")).forEach(f => {
            if (record[f] !== undefined) values[f] = Number(record[f]);
        });
        setEditingItem(values);
        setModalVisible(true);
    };

    const handleDelete = async (record: Record<string, any>) => {
        const rowKey = getRowKey(record);
        try {
            await fetch(`${apiBaseUrl}/${resourceName}/${rowKey}`, { method: "DELETE" });
            message.success("Deleted successfully");
        } catch (err) {
            console.error(err);
            message.error("Delete failed");
        } finally {
            fetchData();
        }
    };

    const columns: ColumnsType<Record<string, any>> = [
        ...fields.map(f => ({
            title: f,
            dataIndex: f,
            key: f,
            align: "left",
            render: value => {
                if (f.toLowerCase().endsWith("id") && lookupData[f]?.length) {
                    const item = lookupData[f].find(i => Number(i.id) === Number(value));
                    return item ? item.label : value;
                }
                if (typeof value === "number" || (!isNaN(Number(value)) && value !== "")) {
                    return <div style={{ textAlign: "right" }}>{Number(value).toLocaleString("en-US")}</div>;
                }
                return value?.toString() || "-";
            },
        })),
        {
            title: "Actions",
            key: "actions",
            align: "center",
            render: (_value, record) => (
                <Space>
                    <Button type="link" onClick={() => handleEdit(record)}>Edit</Button>
                    <Button type="link" danger onClick={() => handleDelete(record)}>Delete</Button>
                </Space>
            ),
        },
    ];

    const renderFormItem = (f: string, idx: number) => {
        if (!editingItem && idx === 0) return null;
        if (editingItem && idx === 0) return <Form.Item key={f} label={f} name={f}><Input disabled /></Form.Item>;

        // Lookup dropdown
        if (f.toLowerCase().endsWith("id") || f.toLowerCase().endsWith("account") || f.toLowerCase().endsWith("currency") || f.toLowerCase().endsWith("company")|| f.toLowerCase().endsWith("by")) {
            const options = lookupData[f]?.map(i => ({ label: i.label, value: i.id })) || [];
            const disabled = f.toLowerCase().includes("by") && !editingItem ? true : false; // disable "by" for add/edit
            return (
                <Form.Item key={f} label={f} name={f} rules={[{ required: true, message: `Please select ${f}` }]}>
                    <Select
                        options={options}
                        placeholder={`Select ${f}`}
                        showSearch
                        optionFilterProp="label"
                        disabled={f.toLowerCase().includes("by")}
                    />
                </Form.Item>
            );
        }

        // Boolean
        if (f.toLowerCase().includes("is") || f.toLowerCase().includes("active") || f.toLowerCase().includes("enabled")) {
            return <Form.Item key={f} label={f} name={f} valuePropName="checked"><Checkbox /></Form.Item>;
        }

        // Date/Year/Month
        if (f.toLowerCase().includes("date")) return <Form.Item key={f} label={f} name={f}><DatePicker style={{ width: "100%" }} /></Form.Item>;
        if (f.toLowerCase().includes("year")) return <Form.Item key={f} label={f} name={f}><DatePicker picker="year" style={{ width: "100%" }} /></Form.Item>;
        if (f.toLowerCase().includes("month")) return <Form.Item key={f} label={f} name={f}><DatePicker picker="month" style={{ width: "100%" }} /></Form.Item>;

        // Numeric auto-generate
        if (f.toLowerCase().includes("number") && !editingItem) {
            const generateNumber = () => {
                const prefix = f.match(/[A-Z]/g)?.join("") || "NUM";
                const datePart = moment().format("YYMMDD");
                const randomPart = Math.floor(Math.random() * 1e10).toString().padStart(10, "0");
                return `${prefix}${datePart}${randomPart}`;
            };
            if (!form.getFieldValue(f)) form.setFieldValue(f, generateNumber());
            return (
                <Form.Item key={f} label={f} name={f}>
                    <InputNumber
                        style={{ width: "calc(100% - 110px)", marginRight: 8 }}
                        formatter={value => `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ",")}
                        parser={value => value.replace(/,/g, "")}
                    />
                    <Button type="default" onClick={() => form.setFieldValue(f, generateNumber())}>Regenerate</Button>
                </Form.Item>
            );
        }

        // Numeric fields
        if (
            f.toLowerCase().includes("amount") ||
            f.toLowerCase().includes("price") ||
            f.toLowerCase().includes("total") ||
            f.toLowerCase().includes("qty") ||
            f.toLowerCase().includes("quantity") ||
            f.toLowerCase().includes("rate") ||
            f.toLowerCase().includes("balance")
        ) {
            return (
                <Form.Item key={f} label={f} name={f}>
                    <InputNumber
                        style={{ width: "100%" }}
                        formatter={value => `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ",")}
                        parser={value => value.replace(/,/g, "")}
                    />
                </Form.Item>
            );
        }

        return <Form.Item key={f} label={f} name={f}><Input /></Form.Item>;
    };

    return (
        <div style={{ padding: 20 }}>
            <div style={{ marginBottom: 16, display: "flex", alignItems: "center" }}>
                <Button type="primary" onClick={() => setModalVisible(true)}>Add {resourceName}</Button>
            </div>

            {isReport ? (
                <>
                    <Button type="primary" onClick={runReport} style={{ marginBottom: 16 }}>Run Report</Button>
                    <Table
                        dataSource={reportData}
                        columns={
                            reportData.length
                                ? Object.keys(reportData[0]).map(k => ({
                                      title: k,
                                      dataIndex: k,
                                      key: k,
                                      render: value => {
                                          if (typeof value === "number" || (!isNaN(Number(value)) && value !== "")) {
                                              return Number(value).toLocaleString("en-US");
                                          }
                                          return value;
                                      },
                                  }))
                                : []
                        }
                        rowKey={(r, i) => i.toString()}
                        loading={loading}
                    />
                </>
            ) : (
                <Table
                    dataSource={data}
                    columns={columns}
                    rowKey={getRowKey}
                    loading={loading}
                    locale={{ emptyText: `No ${resourceName} found` }}
                />
            )}

            <Modal
                title={editingItem ? `Edit ${resourceName}` : `Add ${resourceName}`}
                open={modalVisible}
                onCancel={() => { setModalVisible(false); setEditingItem(null); form.resetFields(); }}
                onOk={() => form.submit()}
                width={800}
            >
                <Form form={form} onFinish={handleSave} layout="vertical">
                    <Row gutter={16}>
                        {fields.map((f, idx) => <Col span={8} key={f}>{renderFormItem(f, idx)}</Col>)}
                    </Row>
                </Form>
            </Modal>
        </div>
    );
};
