import { Table, Button, Modal, Form, Input, Select, Space, message, Row, Col } from "antd";
import { ColumnsType } from "antd/es/table";
import { useEffect, useState } from "react";

interface Props {
    resourceName: string;
    apiBaseUrl?: string;
    fields: string[];
}

interface LookupItem {
    id: string | number;
    label: string;
}

export const GenericResourcePage = ({ resourceName, apiBaseUrl = "", fields }: Props) => {
    const [data, setData] = useState<Record<string, unknown>[]>([]);
    const [loading, setLoading] = useState(false);
    const [modalVisible, setModalVisible] = useState(false);
    const [editingItem, setEditingItem] = useState<Record<string, unknown> | null>(null);
    const [lookupData, setLookupData] = useState<Record<string, LookupItem[]>>({});
    const [lookupModal, setLookupModal] = useState<{ field: string } | null>(null);
    const [fieldsForLookup, setFieldsForLookup] = useState<Record<string, string[]>>({});
    const [form] = Form.useForm();
    const [lookupForm] = Form.useForm();

    /** Fetch main resource data */
    const fetchData = async () => {
        setLoading(true);
        try {
            const res = await fetch(`${apiBaseUrl}/${resourceName}`);
            const json: Record<string, unknown>[] = await res.json();
            setData(json);
        } catch (err) {
            console.error(err);
            message.error("Failed to load data");
        } finally {
            setLoading(false);
        }
    };

    /** Fetch lookup table data */
    const fetchLookups = async () => {
        const newLookup: Record<string, LookupItem[]> = {};
        for (const f of fields.filter(f => f.toLowerCase().endsWith("id"))) {
            let endpoint = f.replace(/Id$/i, "s");
            if (f.toLowerCase().endsWith("yid")) endpoint = f.replace(/yId$/i, "ies");
            if (f.toLowerCase().endsWith("ssid")) endpoint = f.replace(/ssId$/i, "sses");

            try {
                const res = await fetch(`${apiBaseUrl}/${endpoint}`);
                const items: Record<string, any>[] = await res.json();

                newLookup[f] = items.map((i) => {
                    const keys = Object.keys(i);
                    const labelParts = keys.slice(1, 4).map(k => i[k]).filter(Boolean);
                    if (labelParts.length === 0 && keys[0]) labelParts.push(String(i[keys[0]]));
                    return {
                        id: i.id ?? Number(i[keys[0]]),
                        label: labelParts.join(" - "),
                    };
                });

                if (items.length > 0) setFieldsForLookup(prev => ({ ...prev, [f]: Object.keys(items[0]) }));
            } catch (err) {
                console.error(`Failed to fetch lookup for ${f}:`, err);
            }
        }
        setLookupData(newLookup);
    };

    useEffect(() => {
        fetchData();
        fetchLookups();
    }, [resourceName]);

    useEffect(() => {
        if (editingItem) {
            form.setFieldsValue(editingItem);
        }
    }, [editingItem, lookupData]);

    const getRowKey = (record: Record<string, unknown>) => {
        const idField = fields.find(f => f.toLowerCase().endsWith("id"));
        return idField && record[idField] !== undefined ? String(record[idField]) : JSON.stringify(record);
    };

    /** Save form */
    const handleSave = async (values: Record<string, unknown>) => {
        const method = editingItem ? "PUT" : "POST";
        const rowKey = editingItem ? getRowKey(editingItem) : "";
        const url = editingItem ? `${apiBaseUrl}/${resourceName}/${rowKey}` : `${apiBaseUrl}/${resourceName}`;

        try {
            await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(values) });
            message.success("Saved successfully");
        } catch (err) {
            console.error(err);
            message.error("Save failed");
        } finally {
            setModalVisible(false);
            setEditingItem(null);
            form.resetFields();
            fetchData();
        }
    };

    /** Edit record */
    const handleEdit = (record: Record<string, unknown>) => {
        const values: Record<string, unknown> = { ...record };
        fields.filter(f => f.toLowerCase().endsWith("id")).forEach(f => {
            if (record[f] !== undefined) values[f] = Number(record[f]);
        });
        setEditingItem(values);
        form.setFieldsValue(values);
        setModalVisible(true);
    };

    /** Delete record */
    const handleDelete = async (record: Record<string, unknown>) => {
        const rowKey = getRowKey(record);
        try {
            await fetch(`${apiBaseUrl}/${resourceName}/${rowKey}`, { method: "DELETE" });
            message.success("Deleted successfully");
        } catch (err) {
            console.error(err);
            message.error("Delete failed");
        } finally {
            fetchData();
        }
    };

    /** Add new lookup item */
    const handleAddLookup = async (values: Record<string, unknown>) => {
        const field = lookupModal?.field;
        if (!field) return;
        const endpoint = field.replace(/Id$/i, "s");

        try {
            const res = await fetch(`${apiBaseUrl}/${endpoint.toLowerCase()}`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(values),
            });
            const newItem = await res.json();
            await fetchLookups();
            setLookupModal(null);
            lookupForm.resetFields();
            message.success(`${endpoint} added`);
            form.setFieldsValue({ [field]: Number(newItem.id ?? newItem[Object.keys(newItem)[0]]) });
        } catch (err) {
            console.error(err);
            message.error("Failed to add");
        }
    };

    /** Table columns */
    const columns: ColumnsType<Record<string, unknown>> = [
        ...fields.map(f => ({
            title: f,
            dataIndex: f,
            key: f,
            render: value => {
                if (f.toLowerCase().endsWith("id") && lookupData[f]?.length) {
                    const item = lookupData[f].find(i => Number(i.id) === Number(value));
                    return item ? item.label : value;
                }
                return value?.toString() || "-";
            },
        })),
        {
            title: "Actions",
            key: "actions",
            render: (_value, record) => (
                <Space>
                    <Button type="link" onClick={() => handleEdit(record)}>Edit</Button>
                    <Button type="link" danger onClick={() => handleDelete(record)}>Delete</Button>
                </Space>
            ),
        },
    ];

    /** Download table data as JSON */
    const handleDownload = () => {
        if (!data || data.length === 0) {
            message.info("No data to download");
            return;
        }
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `${resourceName}.json`;
        a.click();
        URL.revokeObjectURL(url);
    };

    return (
        <div style={{ padding: 20 }}>
            <div style={{ marginBottom: 16 }}>
                <Button type="primary" onClick={() => setModalVisible(true)}>Add {resourceName}</Button>
                <Button type="default" style={{ marginLeft: 8 }} onClick={handleDownload}>Download</Button>
            </div>

            <Table dataSource={data} columns={columns} rowKey={getRowKey} loading={loading} locale={{ emptyText: `No ${resourceName} found` }} />

            {/* Main Add/Edit Modal */}
            <Modal
                title={editingItem ? `Edit ${resourceName}` : `Add ${resourceName}`}
                open={modalVisible}
                onCancel={() => { setModalVisible(false); setEditingItem(null); form.resetFields(); }}
                onOk={() => form.submit()}
                width={800}
            >
                <Form form={form} onFinish={handleSave} layout="vertical">
                    <Row gutter={16}>
                        {fields.map((f, idx) => {
                            if (!editingItem && idx === 0) return null;
                            if (editingItem && idx === 0) return (
                                <Col span={8} key={f}>
                                    <Form.Item label={f} name={f}>
                                        <Input disabled />
                                    </Form.Item>
                                </Col>
                            );

                            if (f.toLowerCase().endsWith("id")) {
                                const options = lookupData[f]?.map(i => ({ label: i.label, value: Number(i.id) })) || [];
                                return (
                                    <Col span={8} key={f}>
                                        <Form.Item label={f} name={f} rules={[{ required: true }]}>
                                            <Space.Compact style={{ display: "flex" }}>
                                                {lookupData[f] ? (
                                                    <Select
                                                        options={options}
                                                        placeholder={`Select ${f}`}
                                                        style={{ flex: 1 }}
                                                        showSearch
                                                        optionFilterProp="label"
                                                        value={form.getFieldValue(f)}
                                                        onChange={(val) => form.setFieldsValue({ [f]: val })}
                                                    />
                                                ) : (
                                                    <Select disabled placeholder="Loading..." style={{ flex: 1 }} />
                                                )}
                                                <Button type="dashed" onClick={() => setLookupModal({ field: f })}>+</Button>
                                            </Space.Compact>
                                        </Form.Item>
                                    </Col>
                                );
                            }

                            return (
                                <Col span={8} key={f}>
                                    <Form.Item label={f} name={f}>
                                        <Input />
                                    </Form.Item>
                                </Col>
                            );
                        })}
                    </Row>
                </Form>
            </Modal>

            {/* Inline Add Lookup Modal */}
          <Modal
    title={`Add New ${lookupModal?.field?.replace(/Id$/, "")}`}
    open={!!lookupModal}
    onCancel={() => { setLookupModal(null); lookupForm.resetFields(); }}
    onOk={() => lookupForm.submit()}
    getContainer={() => document.body} // ensure modal appears on top
    destroyOnClose
    width={700} // optional, adjust for 3-column layout
>
    <Form form={lookupForm} onFinish={handleAddLookup} layout="vertical">
        <div style={{ display: "flex", flexWrap: "wrap", gap: "16px" }}>
            {lookupModal?.field &&
                fieldsForLookup[lookupModal.field]?.map(f => {
                    if (f.toLowerCase().endsWith("id")) return null;
                    return (
                        <Form.Item
                            key={f}
                            label={f}
                            name={f}
                            rules={[{ required: true }]}
                            style={{ flex: "1 1 calc(33.33% - 16px)" }} // 3 columns
                        >
                            <Input />
                        </Form.Item>
                    );
                })}
        </div>
    </Form>
</Modal>

            
        </div>
    );
};
