import { Table, Button, Modal, Form, Input, Select, Space, message } from "antd";
import { ColumnsType } from "antd/es/table";
import { useEffect, useState } from "react";

interface Props {
    resourceName: string;
    apiBaseUrl?: string;
    fields: string[];
}

interface LookupItem {
    id: string | number;
    label: string;
}

export const GenericResourcePage = ({ resourceName, apiBaseUrl = "", fields }: Props) => {
    const [data, setData] = useState<Record<string, unknown>[]>([]);
    const [loading, setLoading] = useState(false);
    const [modalVisible, setModalVisible] = useState(false);
    const [editingItem, setEditingItem] = useState<Record<string, unknown> | null>(null);
    const [lookupData, setLookupData] = useState<Record<string, LookupItem[]>>({});
    const [lookupModal, setLookupModal] = useState<{ field: string; visible: boolean } | null>(null);
    const [form] = Form.useForm();
    const [lookupForm] = Form.useForm();

    // Fetch main resource data
    const fetchData = async () => {
        setLoading(true);
        try {
            const res = await fetch(`${apiBaseUrl}/${resourceName}`);
            const json: Record<string, unknown>[] = await res.json();
            setData(json);
        } catch (err) {
            console.error("Failed to fetch data:", err);
            message.error("Failed to load data");
        } finally {
            setLoading(false);
        }
    };

const fetchLookups = async () => {
    const newLookup: Record<string, { id: string; label: string }[]> = {};

    for (const f of fields) {
        if (f.toLowerCase().endsWith("id")) {
                               let endpoint =f.replace(/Id$/i, "s");
              if(f.toLowerCase().endsWith("yid")){ endpoint = f.replace(/yId$/i, "ies"); }  //
               if(f.toLowerCase().endsWith("ssid")){ endpoint = f.replace(/ssId$/i, "sses"); }  //
            const lookupName = endpoint; //f.slice(0, -2); // remove "Id" suffix
            try {
                const res = await fetch(`${apiBaseUrl}/${lookupName}`);
                const data: Record<string, any>[] = await res.json();

                newLookup[f] = data.map((i) => {
                    const keys = Object.keys(i);
                    const labelParts = [];
                    if (keys[1] && i[keys[1]] !== undefined) labelParts.push(i[keys[1]]);
                    if (keys[2] && i[keys[2]] !== undefined) labelParts.push(i[keys[2]]);
                      if (keys[3] && i[keys[3]] !== undefined) labelParts.push(i[keys[3]]);
                    if (labelParts.length === 0 && keys[0]) labelParts.push(String(i[keys[0]]));
                    return {
                        id: i.id ?? i[keys[0]],
                        label: labelParts.join(" - "),
                    };
                });
            } catch (err) {
                console.error(`Failed to fetch lookup for ${f}:`, err);
            }
        }
    }

    setLookupData(newLookup);
};

    useEffect(() => {
        fetchData();
        fetchLookups();
    }, [resourceName]);

    // Auto detect rowKey
    const getRowKey = (record: Record<string, unknown>) => {
        const idField = fields.find(f => f.toLowerCase().endsWith("id"));
        if (idField && record[idField] !== undefined) return String(record[idField]);
        return JSON.stringify(record);
    };

    const handleSave = async (values: Record<string, unknown>) => {
        const method = editingItem ? "PUT" : "POST";
        const rowKey = editingItem ? getRowKey(editingItem) : "";
        const url = editingItem
            ? `${apiBaseUrl}/${resourceName}/${rowKey}`
            : `${apiBaseUrl}/${resourceName}`;

        try {
            await fetch(url, {
                method,
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(values),
            });
            message.success("Saved successfully");
        } catch (err) {
            console.error("Failed to save:", err);
            message.error("Save failed");
        } finally {
            setModalVisible(false);
            setEditingItem(null);
            form.resetFields();
            fetchData();
        }
    };

    // const handleEdit = (record: Record<string, unknown>) => {
    //     setEditingItem(record);
    //     form.setFieldsValue(record);
    //     setModalVisible(true);
    // };
const handleEdit = (record: Record<string, unknown>) => {
    const initialValues: Record<string, unknown> = { ...record };

    // Map ID fields to the correct value for Select
    fields.forEach(f => {
        if (f.toLowerCase().endsWith("id") && lookupData[f]?.length) {
            // Make sure the value exists in the lookup options
            const val = record[f];
            const exists = lookupData[f].some(i => String(i.id) === String(val));
            if (!exists) {
                initialValues[f] = undefined; // fallback if value not in lookup
            }
        }
    });

    setEditingItem(record);
    form.setFieldsValue(initialValues);
    setModalVisible(true);
};
    const handleDelete = async (record: Record<string, unknown>) => {
        const rowKey = getRowKey(record);
        try {
            await fetch(`${apiBaseUrl}/${resourceName}/${rowKey}`, { method: "DELETE" });
            message.success("Deleted successfully");
        } catch (err) {
            console.error("Delete failed:", err);
            message.error("Delete failed");
        } finally {
            fetchData();
        }
    };

    // Add new lookup item
    const handleAddLookup = async (values: Record<string, unknown>) => {
        const field = lookupModal?.field;
        if (!field) return;
        const endpoint = field.replace(/Id$/i, "s");
        try {
            const res = await fetch(`${apiBaseUrl}/${endpoint.toLowerCase()}`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(values),
            });
            const newItem = await res.json();
            fetchLookups(); // refresh lookup
            setLookupModal(null);
            lookupForm.resetFields();
            message.success(`${endpoint} added`);
        } catch (err) {
            console.error(err);
            message.error("Failed to add");
        }
    };

    // Table columns
    const columns: ColumnsType<Record<string, unknown>> = [
        ...fields.map(f => ({
            title: f,
            dataIndex: f,
            key: f,
            render: (value: any) => {
                if (f.toLowerCase().endsWith("id") && lookupData[f]?.length) {
                    const item = lookupData[f].find(i => String(i.id) === String(value));
                    return item ? item.label : value;
                }
                return value?.toString() || "-";
            },
        })),
        {
            title: "Actions",
            key: "actions",
            render: (_value, record) => (
                <Space>
                    <Button type="link" onClick={() => handleEdit(record)}>Edit</Button>
                    <Button type="link" danger onClick={() => handleDelete(record)}>Delete</Button>
                </Space>
            ),
        },
    ];

    return (
        <div style={{ padding: 20 }}>
            <Button type="primary" onClick={() => setModalVisible(true)} style={{ marginBottom: 16 }}>
                Add {resourceName}
            </Button>

            <Table
                dataSource={data}
                columns={columns}
                rowKey={getRowKey}
                loading={loading}
                locale={{ emptyText: `No ${resourceName} found` }}
            />

            {/* Add/Edit Main Form */}
            <Modal
                title={editingItem ? `Edit ${resourceName}` : `Add ${resourceName}`}
                open={modalVisible}
                onCancel={() => {
                    setModalVisible(false);
                    setEditingItem(null);
                    form.resetFields();
                }}
                onOk={() => form.submit()}
            >
                <Form form={form} onFinish={handleSave} layout="vertical">
                  {fields.map((f, index) => {//  {fields.map(f => {
                          if (!editingItem && index === 0) return null;

                        if (f.toLowerCase().endsWith("id")) {
                            const options = lookupData[f]?.map(i => ({ label: i.label, value: i.id })) || [];
                            return (
                                <Form.Item key={f} label={f} name={f} rules={[{ required: true }]}>
                                    <Space.Compact style={{ display: "flex" }}>
                                        <Select
                                            options={options}
                                            placeholder={`Select ${f}`}
                                            style={{ flex: 1 }}
                                            showSearch
                                            optionFilterProp="label"
                                            loading={!options.length}
                                        />
                                        <Button
                                            type="dashed"
                                            onClick={() => setLookupModal({ field: f, visible: true })}
                                        >
                                            +
                                        </Button>
                                    </Space.Compact>
                                </Form.Item>
                            );
                        }

                        return (
                            <Form.Item key={f} label={f} name={f}>
                                <Input />
                            </Form.Item>
                        );
                    })}
                </Form>
            </Modal>

            {/* Inline Add Lookup Modal */}
            <Modal
                title={`Add New ${lookupModal?.field?.replace(/Id$/, "")}`}
                open={!!lookupModal}
                onCancel={() => setLookupModal(null)}
                onOk={() => lookupForm.submit()}
            >
                <Form form={lookupForm} onFinish={handleAddLookup} layout="vertical">
                    <Form.Item name="name" label="Name" rules={[{ required: true }]}>
                        <Input />
                    </Form.Item>
                </Form>
            </Modal>
        </div>
    );
};
