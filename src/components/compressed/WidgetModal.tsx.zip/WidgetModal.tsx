// src/components/WidgetModal.tsx
import { Modal, Form, Input, InputNumber, Button, Select, message, Row, Col } from "antd";
import { useEffect, useState } from "react";

const { Option } = Select;

interface Widget {
  DashboardWidgetId: number;
  DashboardId: number;
  WidgetId: number;
  WidgetName?: string;
  Type?: string;
  Settings: string;
  PositionX: number;
  PositionY: number;
  Width: number;
  Height: number;
}

interface WidgetModalProps {
  modalVisible: boolean;
  setModalVisible: (v: boolean) => void;
  editingWidget: Widget | null;
  setEditingWidget: (w: Widget | null) => void;
  form: any;
  procParamsDef: Array<{ name: string; type: string; required: boolean }>;
  setProcParamsDef: (v: Array<{ name: string; type: string; required: boolean }>) => void;
  previewData: any[];
  setPreviewData: (v: any[]) => void;
  selectedProc: string | null;
  setSelectedProc: (v: string | null) => void;
  callProcAndGetResultSets: (procName: string, params: Record<string, any>) => Promise<any[]>;
  onSave: (widget: Widget) => void;
}

export const WidgetModal = ({
  modalVisible,
  setModalVisible,
  editingWidget,
  setEditingWidget,
  form,
  procParamsDef,
  setProcParamsDef,
  previewData,
  setPreviewData,
  selectedProc,
  setSelectedProc,
  callProcAndGetResultSets,
  onSave
}: WidgetModalProps) => {

  const [loadingPreview, setLoadingPreview] = useState(false);
  const [procedures, setProcedures] = useState<string[]>([]);

  // -------------------- Load Swagger procedures --------------------
  useEffect(() => {
    if (modalVisible) {
      fetchProceduresFromSwagger();
    }
  }, [modalVisible]);

  const fetchProceduresFromSwagger = async () => {
    try {
      const res = await fetch("http://localhost:5017/swagger/v1/swagger.json"); // adjust URL to your Swagger JSON
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const doc = await res.json();

      const procs: Set<string> = new Set();

      if (doc.paths) {
        Object.keys(doc.paths).forEach(path => {
               
          if (path.toLowerCase().includes("/api/procedures")) {
               console.log(path.toLowerCase());
           // Object.values(path).forEach((op: any) => {
                
              if (path && path.toLowerCase().includes("sp_") && path.toLowerCase().includes("dashboard")) {
                
                procs.add(path);
              }
            //});
          }
        });
      }
      setProcedures(Array.from(procs).sort());
    } catch (err) {
      console.warn("Failed to load Swagger:", err);
      setProcedures([]);
    }
  };

  // -------------------- Fetch procedure parameters --------------------
  useEffect(() => {
    if (modalVisible && selectedProc) {
      fetchProcParams(selectedProc);
    }
  }, [modalVisible, selectedProc]);

//   const fetchProcParams = async (procName: string) => {
//     try {
//       // TODO: replace this with real API call if backend provides param metadata
//       console.log("This is good");
//       const paramsDef = [
//         { name: "StartDate", type: "string", required: true },
//         { name: "EndDate", type: "string", required: false }
//       ];
//       setProcParamsDef(paramsDef);

//       // Initialize form fields
//       const initialValues: Record<string, any> = {};
//       paramsDef.forEach(p => initialValues[p.name] = '');
//       form.setFieldsValue({ proc: procName, params: initialValues });
//     } catch (err) {
//       message.error("Failed to fetch procedure params");
//     }
//   };
const fetchProcParams = async (procName: string) => {
  try {
    // Load swagger again (or store it globally in state)
    const res = await fetch("http://localhost:5017/swagger/v1/swagger.json");
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const doc = await res.json();

    let foundParams: Array<{ name: string; type: string; required: boolean }> = [];

    // Iterate through paths to find the proc by operationId
    Object.keys(doc.paths).forEach(path => {
      const methods = doc.paths[path];
      Object.keys(methods).forEach(m => {
        const op = methods[m];

        if (op.operationId === procName) {
          if (Array.isArray(op.parameters)) {
            foundParams = op.parameters.map(p => ({
              name: p.name,
              type: p.schema?.type || "string",
              required: p.required || false
            }));
          }
        }
      });
    });

    // If Swagger had no parameters for this proc → fallback empty
    if (foundParams.length === 0) {
      console.warn("No params found for:", procName);
      foundParams = [];
    }

    setProcParamsDef(foundParams);

    // Initialize form default values
    const initialValues: Record<string, any> = {};
    foundParams.forEach(p => initialValues[p.name] = '');

    form.setFieldsValue({ proc: procName, params: initialValues });
  } catch (err) {
    console.error(err);
    message.error("Failed to fetch procedure params.");
  }
};

  // -------------------- Preview --------------------
  const handlePreview = async () => {
    try {
      const values = form.getFieldsValue();
      const params = values.params || {};
      setLoadingPreview(true);
      const data = await callProcAndGetResultSets(values.proc, params);
      setPreviewData(data);
    } catch (err) {
      console.error(err);
      message.error("Failed to fetch preview data");
    } finally {
      setLoadingPreview(false);
    }
  };

  // -------------------- Save --------------------
  const handleOk = async () => {
    try {
      const values = form.getFieldsValue();
      const widgetSettings = { proc: values.proc, params: values.params || {}, chartType: values.chartType };
      
      let newWidget: Widget;
      if (editingWidget) {
        newWidget = { ...editingWidget, Settings: JSON.stringify(widgetSettings) };
        onSave(newWidget);
      } else {
        newWidget = {
          DashboardWidgetId: 0,
          DashboardId: 2, // adjust if needed
          WidgetId: 0,
          WidgetName: values.WidgetName || "New Widget",
          Type: "Chart",
          Settings: JSON.stringify(widgetSettings),
          PositionX: 0,
          PositionY: 0,
          Width: 2,
          Height: 2
        };
        // Persist to backend
        const res = await fetch(`http://localhost5017/api/dashboardwidgets`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(newWidget)
        });
        const saved = await res.json();
        onSave(saved);
      }

      message.success("Widget saved!");
      setModalVisible(false);
      setEditingWidget(null);
      form.resetFields();
    } catch (err) {
      console.error(err);
      message.error("Failed to save widget");
    }
  };

  return (
    <Modal
      title={editingWidget ? "Edit Widget" : "Add Widget"}
      open={modalVisible}
      onCancel={() => { setModalVisible(false); form.resetFields(); setEditingWidget(null); }}
      onOk={handleOk}
      width={600}
      okText="Save"
    >
      <Form form={form} layout="vertical">
        <Form.Item label="Widget Name" name="WidgetName" rules={[{ required: true, message: "Enter widget name" }]}>
          <Input />
        </Form.Item>

        <Form.Item label="Procedure" name="proc" rules={[{ required: true, message: "Select procedure" }]}>
          <Select
            placeholder="Select a procedure"
            onChange={(v) => { setSelectedProc(v); fetchProcParams(v); }}
          >
            {procedures.length > 0
              ? procedures.map(p => <Option key={p} value={p}>{p}</Option>)
              : <Option key="manual" value="">(manual entry)</Option>
            }
          </Select>
        </Form.Item>

        {procParamsDef.length > 0 && (
          <div>
            <h4>Parameters:</h4>
            {procParamsDef.map(p => (
              <Form.Item
                key={p.name}
                label={p.name}
                name={['params', p.name]}
                rules={[{ required: p.required, message: `${p.name} is required` }]}
              >
                {p.type === "number" ? <InputNumber style={{ width: "100%" }} /> : <Input />}
              </Form.Item>
            ))}
          </div>
        )}

        <Form.Item label="Chart Type" name="chartType">
          <Select>
            <Option value="bar">Bar</Option>
            <Option value="line">Line</Option>
            <Option value="pie">Pie</Option>
            <Option value="table">Table</Option>
            <Option value="card">Card</Option>
          </Select>
        </Form.Item>

        <Row justify="end" gutter={8}>
          <Col>
            <Button onClick={handlePreview} loading={loadingPreview}>Preview</Button>
          </Col>
        </Row>

        {previewData.length > 0 && (
          <div style={{ marginTop: 16, maxHeight: 200, overflow: "auto" }}>
            <pre>{JSON.stringify(previewData, null, 2)}</pre>
          </div>
        )}
      </Form>
    </Modal>
  );
};
