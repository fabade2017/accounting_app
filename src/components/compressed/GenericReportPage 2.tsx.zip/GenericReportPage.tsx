// src/components/GenericReportPage.tsx
import { useEffect, useState } from "react";
import {
  Table,
  DatePicker,
  Input,
  Button,
  Form,
  message,
  Select,
  Card,
} from "antd";
import dayjs from "dayjs";
import { Pie, Bar } from "@ant-design/plots";

export const GenericReportPage = ({ resourceName, apiBaseUrl, fields }) => {
  const [form] = Form.useForm();
  const [data, setData] = useState([]);
  const [grouped, setGrouped] = useState([]);
  const [loading, setLoading] = useState(false);

  const [groupBy, setGroupBy] = useState(null);
  const [aggCol, setAggCol] = useState(null);
  const [aggType, setAggType] = useState("SUM");
  const [chartType, setChartType] = useState("none");

  const endpoint = `${apiBaseUrl}/procedures/${resourceName}`;
  const parameterFields = fields || [];

  // -----------------------------
  // Default form values
  // -----------------------------
  useEffect(() => {
    const defaults = {};
    parameterFields.forEach((p) => {
      const key = p.toLowerCase();
      if (key.includes("date")) defaults[p] = dayjs();
      if (key.includes("company")) defaults[p] = 1;
    });
    form.setFieldsValue(defaults);
  }, [parameterFields]);

  // -----------------------------
  // Build request body
  // -----------------------------
  const buildRequestBody = () => {
    const values = form.getFieldsValue();
    const body = {};
    Object.keys(values).forEach((key) => {
      const value = values[key];
      body[key] = dayjs.isDayjs(value) ? value.format("YYYY-MM-DD") : value;
    });
    return body;
  };

  // -----------------------------
  // Load report
  // -----------------------------
  const loadReport = async () => {
    setLoading(true);
    try {
      const body = buildRequestBody();
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      if (!res.ok) throw new Error("Failed to load report");

      const json = await res.json();
      setData(json);
      setGrouped([]); // reset grouping
    } catch (err: any) {
      message.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  // -----------------------------
  // Run grouping & aggregation
  // -----------------------------
  const runGrouping = () => {
    if (!groupBy || !aggCol) {
      setGrouped([]);
      return;
    }

    const map: Record<string, any> = {};
    data.forEach((row) => {
      const key = row[groupBy] ?? "Unknown";
      if (!map[key]) map[key] = { children: [], total: 0, count: 0 };
      map[key].children.push(row);

      const val = Number(row[aggCol]) || 0;
      if (aggType === "SUM") map[key].total += val;
      if (aggType === "AVG") {
        map[key].total += val;
        map[key].count++;
      }
      if (aggType === "COUNT") map[key].count++;
    });

    const groupedResult = Object.keys(map).map((key, idx) => {
      const entry = map[key];
      const finalTotal =
        aggType === "SUM"
          ? entry.total
          : aggType === "COUNT"
          ? entry.count
          : entry.total / (entry.count || 1);

      // Add unique keys for parent + children
      const childrenWithKey = entry.children.map((child, i) => ({
        ...child,
        key: `${key}-child-${i}`,
      }));

      return {
        key: `parent-${idx}`,
        Group: key,
        Total: finalTotal,
        children: childrenWithKey,
      };
    });

    setGrouped(groupedResult);
  };

  useEffect(() => {
    if (data.length > 0) runGrouping();
  }, [data, groupBy, aggCol, aggType]);

  const columns =
    data.length > 0
      ? Object.keys(data[0]).map((key) => ({ title: key, dataIndex: key }))
      : [];

  // -----------------------------
  // Chart configs
  // -----------------------------
  const chartData = grouped.map((g) => ({
    type: g.Group,
    value: g.Total,
  }));

  const pieConfig = { data: chartData, angleField: "value", colorField: "type", radius: 0.9 };
  const barConfig = { data: chartData, xField: "value", yField: "type" };

  return (
    <div>
      <h2>{resourceName.toUpperCase()}</h2>

      {/* Filter Form */}
      <Form form={form} layout="inline" onFinish={loadReport} style={{ marginBottom: 20 }}>
        {parameterFields.map((p) =>
          p.toLowerCase().includes("date") ? (
            <Form.Item key={p} name={p} label={p}>
              <DatePicker />
            </Form.Item>
          ) : (
            <Form.Item key={p} name={p} label={p}>
              <Input />
            </Form.Item>
          )
        )}
        <Form.Item>
          <Button type="primary" htmlType="submit" loading={loading}>
            Run Report
          </Button>
        </Form.Item>
      </Form>

      {/* Grouping / Chart Controls */}
      {data.length > 0 && (
        <Card style={{ marginBottom: 20 }}>
          <div style={{ display: "flex", gap: 20 }}>
            <div>
              <label>Group By</label>
              <Select style={{ width: 200 }} value={groupBy} onChange={setGroupBy} allowClear>
                {columns.map((c) => (
                  <Select.Option key={c.dataIndex} value={c.dataIndex}>
                    {c.title}
                  </Select.Option>
                ))}
              </Select>
            </div>

            <div>
              <label>Aggregate Column</label>
              <Select style={{ width: 200 }} value={aggCol} onChange={setAggCol}>
                {columns.map((c) => (
                  <Select.Option key={c.dataIndex} value={c.dataIndex}>
                    {c.title}
                  </Select.Option>
                ))}
              </Select>
            </div>

            <div>
              <label>Aggregation Type</label>
              <Select style={{ width: 150 }} value={aggType} onChange={setAggType}>
                <Select.Option value="SUM">SUM</Select.Option>
                <Select.Option value="AVG">AVG</Select.Option>
                <Select.Option value="COUNT">COUNT</Select.Option>
              </Select>
            </div>

            <div>
              <label>Chart</label>
              <Select style={{ width: 150 }} value={chartType} onChange={setChartType}>
                <Select.Option value="none">None</Select.Option>
                <Select.Option value="pie">Pie Chart</Select.Option>
                <Select.Option value="bar">Bar Chart</Select.Option>
              </Select>
            </div>
          </div>
        </Card>
      )}

      {/* Chart */}
      {chartType !== "none" && grouped.length > 0 && (
        <Card style={{ marginBottom: 20 }}>
          {chartType === "pie" && <Pie {...pieConfig} />}
          {chartType === "bar" && <Bar {...barConfig} />}
        </Card>
      )}

      {/* Table */}
      <Table
        dataSource={grouped.length > 0 ? grouped : data}
        columns={grouped.length > 0 ? [{ title: "Group", dataIndex: "Group" }, { title: "Total", dataIndex: "Total" }] : columns}
        expandable={grouped.length > 0 ? { expandedRowRender: (record) => <Table dataSource={record.children} columns={columns} pagination={false} rowKey="key" /> } : undefined}
        rowKey="key"
        loading={loading}
      />
    </div>
  );
};
