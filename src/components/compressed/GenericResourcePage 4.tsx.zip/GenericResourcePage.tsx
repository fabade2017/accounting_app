    import { Table, Button, Modal, Form, Input, Select, Space, message } from "antd";
import { ColumnsType } from "antd/es/table";
import { useEffect, useState } from "react";

interface Props {
    resourceName: string;
    apiBaseUrl?: string;
    fields: string[];
}

interface LookupItem {
    id: string | number;
    label: string;
}

export const GenericResourcePage = ({ resourceName, apiBaseUrl = "", fields }: Props) => {
    const [data, setData] = useState<Record<string, unknown>[]>([]);
    const [loading, setLoading] = useState(false);
    const [modalVisible, setModalVisible] = useState(false);
    const [editingItem, setEditingItem] = useState<Record<string, unknown> | null>(null);
    const [lookupData, setLookupData] = useState<Record<string, LookupItem[]>>({});
    const [lookupModal, setLookupModal] = useState<{ field: string } | null>(null);
    const [fieldsForLookup, setFieldsForLookup] = useState<Record<string, string[]>>({});
    const [form] = Form.useForm();
    const [lookupForm] = Form.useForm();

    /** Fetch main resource data */
    const fetchData = async () => {
        setLoading(true);
        try {
            const res = await fetch(`${apiBaseUrl}/${resourceName}`);
            const json: Record<string, unknown>[] = await res.json();
            setData(json);
        } catch (err) {
            console.error(err);
            message.error("Failed to load data");
        } finally {
            setLoading(false);
        }
    };

    /** Fetch lookup table data */
    const fetchLookups = async () => {
        const newLookup: Record<string, LookupItem[]> = {};

        for (const f of fields.filter(f => f.toLowerCase().endsWith("id"))) {
            let endpoint = f.replace(/Id$/i, "s");
            if (f.toLowerCase().endsWith("yid")) endpoint = f.replace(/yId$/i, "ies");
            if (f.toLowerCase().endsWith("ssid")) endpoint = f.replace(/ssId$/i, "sses");

            try {
                const res = await fetch(`${apiBaseUrl}/${endpoint}`);
                const items: Record<string, any>[] = await res.json();

                newLookup[f] = items.map((i) => {
                    const keys = Object.keys(i);
                    const labelParts = keys.slice(1, 4).map(k => i[k]).filter(Boolean);
                    if (labelParts.length === 0 && keys[0]) labelParts.push(String(i[keys[0]]));
                    return {
                        id: i.id ??  Number(i[keys[0]]),
                        label: labelParts.join(" - "),
                    };
                });
// newLookup[f] = items.map(i => ({
//     id: Number(i.id ?? i[keys[0]]),
//     label: labelParts.join(" - "),
// }));
                if (items.length > 0) setFieldsForLookup(prev => ({ ...prev, [f]: Object.keys(items[0]) }));
            } catch (err) {
                console.error(`Failed to fetch lookup for ${f}:`, err);
            }
        }

        setLookupData(newLookup);
    };

    useEffect(() => {
        fetchData();
        fetchLookups();
    }, [resourceName]);
useEffect(() => {
    if (editingItem) {
        form.setFieldsValue(editingItem);
    }
}, [editingItem, lookupData]);

    const getRowKey = (record: Record<string, unknown>) => {
        const idField = fields.find(f => f.toLowerCase().endsWith("id"));
        return idField && record[idField] !== undefined ? String(record[idField]) : JSON.stringify(record);
    };

    /** Save form */
    const handleSave = async (values: Record<string, unknown>) => {
        const method = editingItem ? "PUT" : "POST";
        const rowKey = editingItem ? getRowKey(editingItem) : "";
        const url = editingItem ? `${apiBaseUrl}/${resourceName}/${rowKey}` : `${apiBaseUrl}/${resourceName}`;

        try {
            await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(values) });
            message.success("Saved successfully");
        } catch (err) {
            console.error(err);
            message.error("Save failed");
        } finally {
            setModalVisible(false);
            setEditingItem(null);
            form.resetFields();
            fetchData();
        }
    };

    /** Edit record */
    const handleEdit = (record: Record<string, unknown>) => {
        const values: Record<string, unknown> = { ...record };
        // convert IDs to numbers for Select
        fields.filter(f => f.toLowerCase().endsWith("id")).forEach(f => {
            if (record[f] !== undefined) values[f] = Number(record[f]);
            
        });

        setEditingItem(values);
      //  form.setFieldsValue(values);
         form.setFieldsValue(values); // now values match Select's value types
        setModalVisible(true);
    };

    /** Delete record */
    const handleDelete = async (record: Record<string, unknown>) => {
        const rowKey = getRowKey(record);
        try {
            await fetch(`${apiBaseUrl}/${resourceName}/${rowKey}`, { method: "DELETE" });
            message.success("Deleted successfully");
        } catch (err) {
            console.error(err);
            message.error("Delete failed");
        } finally {
            fetchData();
        }
    };

    /** Add new lookup item */
    const handleAddLookup = async (values: Record<string, unknown>) => {
        const field = lookupModal?.field;
        if (!field) return;
        const endpoint = field.replace(/Id$/i, "s");

        try {
            const res = await fetch(`${apiBaseUrl}/${endpoint.toLowerCase()}`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(values),
            });
            const newItem = await res.json();
            await fetchLookups();
            setLookupModal(null);
            lookupForm.resetFields();
            message.success(`${endpoint} added`);

            // auto-select newly added item
            form.setFieldsValue({ [field]: Number(newItem.id ?? newItem[Object.keys(newItem)[0]]) });
        } catch (err) {
            console.error(err);
            message.error("Failed to add");
        }
    };

    /** Table columns */
    const columns: ColumnsType<Record<string, unknown>> = [
        ...fields.map(f => ({
            title: f,
            dataIndex: f,
            key: f,
            render: value => {
                if (f.toLowerCase().endsWith("id") && lookupData[f]?.length) {
                    const item = lookupData[f].find(i => Number(i.id) === Number(value));
                    return item ? item.label : value;
                }
                return value?.toString() || "-";
            },
        })),
        {
            title: "Actions",
            key: "actions",
            render: (_value, record) => (
                <Space>
                    <Button type="link" onClick={() => handleEdit(record)}>Edit</Button>
                    <Button type="link" danger onClick={() => handleDelete(record)}>Delete</Button>
                </Space>
            ),
        },
    ];

    return (
        <div style={{ padding: 20 }}>
            <Button type="primary" onClick={() => setModalVisible(true)} style={{ marginBottom: 16 }}>
                Add {resourceName}
            </Button>

            <Table dataSource={data} columns={columns} rowKey={getRowKey} loading={loading} locale={{ emptyText: `No ${resourceName} found` }} />

            {/* Main Add/Edit Modal */}
            <Modal
                title={editingItem ? `Edit ${resourceName}` : `Add ${resourceName}`}
                open={modalVisible}
                onCancel={() => { setModalVisible(false); setEditingItem(null); form.resetFields(); }}
                onOk={() => form.submit()}
            >
                <Form form={form} onFinish={handleSave} layout="vertical">
                    {fields.map((f, idx) => {
                        // ID handling
                        if (!editingItem && idx === 0) return null; // skip ID on add
                        if (editingItem && idx === 0) return (
                            <Form.Item key={f} label={f} name={f}>
                                <Input disabled />
                            </Form.Item>
                        );

                        // Dropdowns
                        if (f.toLowerCase().endsWith("id")) {
                            const options = lookupData[f]?.map(i => ({ label: i.label, value: Number(i.id) })) || [];
                                        console.log("---- DEBUG FIELD ----");
            console.log("Field:", f);
            console.log("Form value:", form.getFieldValue(f), "type:", typeof form.getFieldValue(f));
            console.log("Lookup data:", lookupData[f]);
            console.log("Options:", options);
            console.log(
                "Option value types:", 
                options.map(o => ({ value: o.value, type: typeof o.value }))
            );
            console.log("----------------------");
            console.log("Current form value:", form.getFieldValue(f), "type:", typeof form.getFieldValue(f));
console.log("Options values:", options.map(o => ({ value: o.value, type: typeof o.value })));

                            return (
                                <Form.Item key={f} label={f} name={f} rules={[{ required: true }]}>
                                    <Space.Compact style={{ display: "flex" }}>
                                      {lookupData[f] ? (
    <Select
        options={options}
        placeholder={`Select ${f}`}
        style={{ flex: 1 }}
        showSearch
        optionFilterProp="label"
        value={form.getFieldValue(f)}
        onChange={(val) => form.setFieldsValue({ [f]: val })}
    />
) : (
    <Select disabled placeholder="Loading..." style={{ flex: 1 }} />
)}
                                        <Button type="dashed" onClick={() => setLookupModal({ field: f })}>+</Button>
                                    </Space.Compact>
                                </Form.Item>
                            );
                        }

                        // Normal input
                        return (
                            <Form.Item key={f} label={f} name={f}>
                                <Input />
                            </Form.Item>
                        );
                    })}
                </Form>
            </Modal>

            {/* Inline Add Lookup Modal */}
            <Modal
                title={`Add New ${lookupModal?.field?.replace(/Id$/, "")}`}
                open={!!lookupModal}
                onCancel={() => { setLookupModal(null); lookupForm.resetFields(); }}
                onOk={() => lookupForm.submit()}
            >
                <Form form={lookupForm} onFinish={handleAddLookup} layout="vertical">
                    {lookupModal?.field &&
                        fieldsForLookup[lookupModal.field]?.map(f => {
                            if (f.toLowerCase().endsWith("id")) return null;
                            return (
                                <Form.Item key={f} label={f} name={f} rules={[{ required: true }]}>
                                    <Input />
                                </Form.Item>
                            );
                        })}
                </Form>
            </Modal>
        </div>
    );
};



// import { Table, Button, Modal, Form, Input, Select, Space, message } from "antd";
        // import { ColumnsType } from "antd/es/table";
        // import { useEffect, useState } from "react";

        // interface Props {
        //     resourceName: string;
        //     apiBaseUrl?: string;
        //     fields: string[];
        // }

        // interface LookupItem {
        //     id: string | number;
        //     label: string;
        // }

        // export const GenericResourcePage = ({ resourceName, apiBaseUrl = "", fields }: Props) => {
        //     const [data, setData] = useState<Record<string, unknown>[]>([]);
        //     const [loading, setLoading] = useState(false);
        //     const [modalVisible, setModalVisible] = useState(false);
        //     const [editingItem, setEditingItem] = useState<Record<string, unknown> | null>(null);
        //     const [lookupData, setLookupData] = useState<Record<string, LookupItem[]>>({});
        //     const [lookupModal, setLookupModal] = useState<{ field: string; visible: boolean } | null>(null);
        //     const [form] = Form.useForm();
        //     const [lookupForm] = Form.useForm();
        //     const [fieldsForLookup, setFieldsForLookup] = useState<Record<string, string[]>>({});

        //     /** Fetch main resource data */
        //     const fetchData = async () => {
        //         setLoading(true);
        //         try {
        //             const res = await fetch(`${apiBaseUrl}/${resourceName}`);
        //             const json: Record<string, unknown>[] = await res.json();
        //             setData(json);
        //         } catch (err) {
        //             console.error("Failed to fetch data:", err);
        //             message.error("Failed to load data");
        //         } finally {
        //             setLoading(false);
        //         }
        //     };

        //     /** Fetch lookup table data */
        //     const fetchLookups = async () => {
        //         const newLookup: Record<string, LookupItem[]> = {};
        //         for (const f of fields) {
        //             if (f.toLowerCase().endsWith("id")) {
        //                 let endpoint = f.replace(/Id$/i, "s");
        //                 if (f.toLowerCase().endsWith("yid")) endpoint = f.replace(/yId$/i, "ies");
        //                 if (f.toLowerCase().endsWith("ssid")) endpoint = f.replace(/ssId$/i, "sses");

        //                 try {
        //                     const res = await fetch(`${apiBaseUrl}/${endpoint}`);
        //                     const items: Record<string, any>[] = await res.json();

        //                     newLookup[f] = items.map((i) => {
        //                         const keys = Object.keys(i);
        //                         const labelParts = [];
        //                         if (keys[1] && i[keys[1]] !== undefined) labelParts.push(i[keys[1]]);
        //                         if (keys[2] && i[keys[2]] !== undefined) labelParts.push(i[keys[2]]);
        //                         if (keys[3] && i[keys[3]] !== undefined) labelParts.push(i[keys[3]]);
        //                         if (labelParts.length === 0 && keys[0]) labelParts.push(String(i[keys[0]]));
        //                         return {
        //                             id: i.id ?? i[keys[0]],
        //                             label: labelParts.join(" - "),
        //                         };
        //                     });

        //                     // Also store the fields of this lookup table for add modal
        //                     if (items.length > 0) setFieldsForLookup((prev) => ({ ...prev, [f]: Object.keys(items[0]) }));
        //                 } catch (err) {
        //                     console.error(`Failed to fetch lookup for ${f}:`, err);
        //                 }
        //             }
        //         }
        //         setLookupData(newLookup);
        //     };

        //     useEffect(() => {
        //         fetchData();
        //         fetchLookups();
        //     }, [resourceName]);

        //     /** Auto detect rowKey */
        //     const getRowKey = (record: Record<string, unknown>) => {
        //         const idField = fields.find(f => f.toLowerCase().endsWith("id"));
        //         if (idField && record[idField] !== undefined) return String(record[idField]);
        //         return JSON.stringify(record);
        //     };

        //     /** Save main form */
        //     const handleSave = async (values: Record<string, unknown>) => {
        //         const method = editingItem ? "PUT" : "POST";
        //         const rowKey = editingItem ? getRowKey(editingItem) : "";
        //         const url = editingItem
        //             ? `${apiBaseUrl}/${resourceName}/${rowKey}`
        //             : `${apiBaseUrl}/${resourceName}`;

        //         try {
        //             await fetch(url, {
        //                 method,
        //                 headers: { "Content-Type": "application/json" },
        //                 body: JSON.stringify(values),
        //             });
        //             message.success("Saved successfully");
        //         } catch (err) {
        //             console.error("Failed to save:", err);
        //             message.error("Save failed");
        //         } finally {
        //             setModalVisible(false);
        //             setEditingItem(null);
        //             form.resetFields();
        //             fetchData();
        //         }
        //     };

        //     /** Edit record */
        //     const handleEdit = (record: Record<string, unknown>) => {
        //         const values: Record<string, unknown> = { ...record };
        //         // For dropdowns, map current value to id for Select
        //         for (const f of fields) {
        //             if (f.toLowerCase().endsWith("id") && lookupData[f]?.length) {
        //                 console.log(JSON.stringify(record[f]));
        //                 values[f] = String(record[f]);
        //             }
        //         }
        //        console.log(JSON.stringify(values));
        //         setEditingItem(values);
        //         form.setFieldsValue(values);
        //         setModalVisible(true);
        //     };
        // //    const newId =
        // //     Number(newItem.id ?? newItem[Object.keys(newItem)[0]]);
        // // form.setFieldsValue({
        // //     [field]: newId
        // // });
        //     /** Delete record */
        //     const handleDelete = async (record: Record<string, unknown>) => {
        //         const rowKey = getRowKey(record);
        //         try {
        //             await fetch(`${apiBaseUrl}/${resourceName}/${rowKey}`, { method: "DELETE" });
        //             message.success("Deleted successfully");
        //         } catch (err) {
        //             console.error("Delete failed:", err);
        //             message.error("Delete failed");
        //         } finally {
        //             fetchData();
        //         }
        //     };

        //     /** Add new lookup item */
        //     const handleAddLookup = async (values: Record<string, unknown>) => {
        //         const field = lookupModal?.field;
        //         if (!field) return;
        //         const endpoint = field.replace(/Id$/i, "s");
        //         try {
        //             const res = await fetch(`${apiBaseUrl}/${endpoint.toLowerCase()}`, {
        //                 method: "POST",
        //                 headers: { "Content-Type": "application/json" },
        //                 body: JSON.stringify(values),
        //             });
        //             const newItem = await res.json();
        //             await fetchLookups(); // refresh dropdown
        //             setLookupModal(null);
        //             lookupForm.resetFields();
        //             message.success(`${endpoint} added`);

        //             // Auto-select the newly added item in main form
        //             const newId =
        //     Number(newItem.id ?? newItem[Object.keys(newItem)[0]]);
        // form.setFieldsValue({
        //     [field]: newId
        // });
        //           //  form.setFieldsValue({ [field]: newItem.id ?? newItem[Object.keys(newItem)[0]] });
        //         } catch (err) {
        //             console.error(err);
        //             message.error("Failed to add");
        //         }
        //     };

        //     /** Table columns */
        //     const columns: ColumnsType<Record<string, unknown>> = [
        //         ...fields.map(f => ({
        //             title: f,
        //             dataIndex: f,
        //             key: f,
        //             render: (value: any) => {
        //                 if (f.toLowerCase().endsWith("id") && lookupData[f]?.length) {
        //                     const item = lookupData[f].find(i => Number(i.id) === Number(value));
        //                     return item ? item.label : value;
        //                 }
        //                 return value?.toString() || "-";
        //             },
        //         })),
        //         {
        //             title: "Actions",
        //             key: "actions",
        //             render: (_value, record) => (
        //                 <Space>
        //                     <Button type="link" onClick={() => handleEdit(record)}>Edit</Button>
        //                     <Button type="link" danger onClick={() => handleDelete(record)}>Delete</Button>
        //                 </Space>
        //             ),
        //         },
        //     ];

        //     return (
        //         <div style={{ padding: 20 }}>
        //             <Button type="primary" onClick={() => setModalVisible(true)} style={{ marginBottom: 16 }}>
        //                 Add {resourceName}
        //             </Button>

        //             <Table
        //                 dataSource={data}
        //                 columns={columns}
        //                 rowKey={getRowKey}
        //                 loading={loading}
        //                 locale={{ emptyText: `No ${resourceName} found` }}
        //             />

        //             {/* Main Add/Edit Modal */}
        //             <Modal
        //                 title={editingItem ? `Edit ${resourceName}` : `Add ${resourceName}`}
        //                 open={modalVisible}
        //                 onCancel={() => {
        //                     setModalVisible(false);
        //                     setEditingItem(null);
        //                     form.resetFields();
        //                 }}
        //                 onOk={() => form.submit()}
        //             >
        //                 <Form form={form} onFinish={handleSave} layout="vertical">
        //                     {fields.map((f, index) => {
        //                         if (!editingItem && index === 0) return null; // skip ID on add
        //   if (editingItem && index === 0) return (
        //                             <Form.Item key={f} label={f} name={f}>
        //                                  <Input disabled />
        //                             </Form.Item>
        //                         ); // skip ID on Eidt
        //                    //   console.log(JSON.stringify(editingItem));

        //                      //  console.log(JSON.stringify(index));
        //                         if (f.toLowerCase().endsWith("id")) {
        //                             const options = lookupData[f]?.map(i => ({ label: i.label, value: Number(i.id) })) || [];
        //                               // DEBUG LOGS
        //     console.log("---- DEBUG FIELD ----");
        //     console.log("Field:", f);
        //     console.log("Form value:", form.getFieldValue(f), "type:", typeof form.getFieldValue(f));
        //     console.log("Lookup data:", lookupData[f]);
        //     console.log("Options:", options);
        //     console.log(
        //         "Option value types:", 
        //         options.map(o => ({ value: o.value, type: typeof o.value }))
        //     );
        //     console.log("----------------------");
        //                                console.log(JSON.stringify(options));
        //                             return (
        //                                 <Form.Item key={f} label={f} name={f} rules={[{ required: true }]}>
        //                                     <Space.Compact style={{ display: "flex" }}>
        //                                         <Select
        //                                             options={options}
        //                                             placeholder={`Select ${f}`}
        //                                             style={{ flex: 1 }}
        //                                             showSearch
        //                                             optionFilterProp="label"
        //                                         />
        //                                         <Button
        //                                             type="dashed"
        //                                             onClick={() => setLookupModal({ field: f, visible: true })}
        //                                         >
        //                                             +
        //                                         </Button>
        //                                     </Space.Compact>
        //                                 </Form.Item>
        //                             );
        //                         }

        //                         return (
        //                             <Form.Item key={f} label={f} name={f}>
        //                                 <Input />
        //                             </Form.Item>
        //                         );
        //                     })}
        //                 </Form>
        //             </Modal>

        //             {/* Inline Add Lookup Modal */}
        //             <Modal
        //                 title={`Add New ${lookupModal?.field?.replace(/Id$/, "")}`}
        //                 open={!!lookupModal}
        //                 onCancel={() => {
        //                     setLookupModal(null);
        //                     lookupForm.resetFields();
        //                 }}
        //                 onOk={() => lookupForm.submit()}
        //             >
        //                 <Form form={lookupForm} onFinish={handleAddLookup} layout="vertical">
        //                     {lookupModal?.field &&
        //                         fieldsForLookup[lookupModal.field]?.map((f) => {
        //                             if (f.toLowerCase().endsWith("id")) return null; // skip ID

        //                             return (
        //                                 <Form.Item key={f} label={f} name={f} rules={[{ required: true }]}>
        //                                     <Input />
        //                                 </Form.Item>
        //                             );
        //                         })}
        //                 </Form>
        //             </Modal>
        //         </div>
        //     );
        // };
