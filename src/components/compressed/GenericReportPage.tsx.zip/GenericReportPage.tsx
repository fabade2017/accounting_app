// src/components/GenericReportPage.tsx
import { useEffect, useState } from "react";
import { Table, DatePicker, Input, Button, Form, message } from "antd";
import dayjs from "dayjs";

export const GenericReportPage = ({ resourceName, apiBaseUrl, fields }) => {  
  const [form] = Form.useForm();
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);

  const endpoint = `${apiBaseUrl}/procedures/${resourceName}`;

  // ----------------------------------------
  // FIX: fields always exists (fields = [])
  // ----------------------------------------
//   const parameterFields = fields.filter(
//     (f) => f.in === "query" || f.in === "body" || f.in === "formData"|| f.in === "AsOfDate"
// //   );
// console.log("fields.in:" + fields.in);
const parameterFields = fields;
console.log("fields.in:" + parameterFields + "|" + fields);
//   const [form] = Form.useForm();
//   const [data, setData] = useState([]);
//   const [loading, setLoading] = useState(false);

//  const endpoint = `${apiBaseUrl}/${resourceName}`;

  // --------------------------------------------------
  // Auto-extract required parameters from Swagger
  // --------------------------------------------------
//   const parameterFields = fields.filter(
//     (f) => f.in === "query" || f.in === "body" || f.in === "formData"
//   );

  // --------------------------------------------------
  // Set default form values
  // --------------------------------------------------

  //console.log("fields:" +JSON.stringify(fields));
  useEffect(() => {
    const defaults = {};
    console.log("fields:" +JSON.stringify(fields));

    parameterFields.forEach((p) => {
      const key = p.toLowerCase();
 // console.log("keys:" + key);

      if (key.includes("date")) {
        defaults[p] = dayjs();
      }
      if (key.includes("company")) {
        defaults[p] = 1; // auto default
      }
    });

    form.setFieldsValue(defaults);
  }, [parameterFields]);

  // --------------------------------------------------
  // Build request body for POST
  // --------------------------------------------------
  const buildRequestBody = () => {
    const values = form.getFieldsValue();
    const body = {};
console.log("value:");
    Object.keys(values).forEach((key) => {
      const value = values[key];
console.log("value:"+ value);
      if (dayjs.isDayjs(value)) {
        body[key] = value.format("YYYY-MM-DD");
      } else {
        body[key] = value;
      }
    });

    return body;
  };

  // --------------------------------------------------
  // Load Report (POST)
  // --------------------------------------------------
  const loadReport = async () => {
    console.log("Loading Report");
    setLoading(true);
    try {
      const body = buildRequestBody();

      const res = await fetch(endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(body),
      });

      if (!res.ok) throw new Error("Failed to load report");

      const json = await res.json();
      setData(json);
    } catch (err: any) {
      message.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  // --------------------------------------------------
  // Render Filters + Table
  // --------------------------------------------------
  return (
    <div>
      <h2>{resourceName.toUpperCase()}</h2>

      {/* FILTER FORM */}
      <Form form={form} layout="inline" onFinish={loadReport} style={{ marginBottom: 20 }}>
        {parameterFields.map((p) => {
          const key = p;

          if (key.toLowerCase().includes("date")) {
            console.log(`Reaching Here ${key.toLowerCase()}`);
            return (
              <Form.Item key={key} name={key} label={key}>
                <DatePicker />
              </Form.Item>
            );
          }

          return (
            <Form.Item key={key} name={key} label={key}>
              <Input />
            </Form.Item>
          );
        })}

        <Form.Item>
          <Button type="primary" htmlType="submit" loading={loading}>
            Run Report
          </Button>
        </Form.Item>
      </Form>

      {/* DATA TABLE */}
      <Table
        dataSource={data}
        loading={loading}
        rowKey={(r, i) => i}
        columns={
          data.length > 0
            ? Object.keys(data[0]).map((key) => ({
                title: key,
                dataIndex: key,
              }))
            : []
        }
      />
    </div>
  );
};
