import { Table, Button, Modal, Form, Input, Select, Space, message, Checkbox, Row, Col, DatePicker, InputNumber } from "antd";
import { ColumnsType } from "antd/es/table";
import { useEffect, useState } from "react";
import moment from "moment";

interface Props {
    resourceName: string;
    apiBaseUrl?: string;
    fields: string[];
}

interface LookupItem {
    id: string | number;
    label: string;
}

export const GenericResourcePage = ({ resourceName, apiBaseUrl = "", fields }: Props) => {
    const [data, setData] = useState<Record<string, any>[]>([]);
    const [loading, setLoading] = useState(false);
    const [modalVisible, setModalVisible] = useState(false);
    const [editingItem, setEditingItem] = useState<Record<string, any> | null>(null);
    const [lookupData, setLookupData] = useState<Record<string, LookupItem[]>>({});
    const [fieldsForLookup, setFieldsForLookup] = useState<Record<string, string[]>>({});
    const [form] = Form.useForm();
    const [showMoreFields, setShowMoreFields] = useState(false);

    const loggedInUserId = localStorage.getItem("userId");

    const isReport = resourceName.toLowerCase().includes("report");
    const [reportParams, setReportParams] = useState<Record<string, any>>({});
    const [reportData, setReportData] = useState<any[]>([]);

    const fetchData = async () => {
        setLoading(true);
        try {
            const res = await fetch(`${apiBaseUrl}/${resourceName}`);
            const json: Record<string, any>[] = await res.json();
            setData(json);
        } catch (err) {
            console.error(err);
            message.error("Failed to load data");
        } finally {
            setLoading(false);
        }
    };

    const runReport = async () => {
        setLoading(true);
        try {
            const res = await fetch(`${apiBaseUrl}/procedures/${resourceName}`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(reportParams)
            });
            const json = await res.json();
            setReportData(json);
        } catch (err) {
            message.error("Failed to run report");
        } finally {
            setLoading(false);
        }
    };

    const fetchLookups = async () => {
        const newLookup: Record<string, LookupItem[]> = {};
        for (const f of fields.filter(f => f.toLowerCase().endsWith("id") || f.toLowerCase().endsWith("by"))) {
            let endpoint = f.replace(/\s/g, '');
            if (endpoint.toLowerCase().endsWith('by')) endpoint = "users";
            if (endpoint.toLowerCase().endsWith('accountid')) endpoint = "bankaccounts";
            if (endpoint.toLowerCase().endsWith("yid")) endpoint = endpoint.replace("yId", "ies");
            if (endpoint.toLowerCase().endsWith("y")) endpoint = endpoint.replace(/y$/i, "ies");
            if (endpoint.toLowerCase().endsWith("ssid")) endpoint = endpoint.replace(/ssId$/i, "sses");
            if (endpoint.toLowerCase().endsWith("id")) endpoint = endpoint.replace(/Id$/i, "s");

            try {
                const res = await fetch(`${apiBaseUrl}/${endpoint}`);
                const items: Record<string, any>[] = await res.json();
                newLookup[f] = items.map(i => {
                    const keys = Object.keys(i);
                    const labelParts = keys.slice(1, 4).map(k => i[k]).filter(Boolean);
                    if (labelParts.length === 0 && keys[0]) labelParts.push(String(i[keys[0]]));
                    return { id: i.id ?? Number(i[keys[0]]), label: labelParts.join(" - ") };
                });
                if (items.length > 0) setFieldsForLookup(prev => ({ ...prev, [f]: Object.keys(items[0]) }));
            } catch (err) {
                console.error(`Failed to fetch lookup for ${f}:`, err);
            }
        }
        setLookupData(newLookup);
    };

    useEffect(() => {
        if (isReport) runReport(); else fetchData();
        fetchLookups();
    }, [resourceName]);

    useEffect(() => {
        if (editingItem && Object.keys(lookupData).length > 0) {
            const values = { ...editingItem };
            fields.forEach(f => {
                if (f.toLowerCase().endsWith("id") && values[f] != null) values[f] = Number(values[f]);
                if (f.toLowerCase().includes("date") && values[f]) values[f] = moment(values[f]);
                if (f.toLowerCase().includes("year") && values[f]) values[f] = moment(values[f], "YYYY");
                if (f.toLowerCase().includes("month") && values[f]) values[f] = moment(values[f], "YYYY-MM");
            });
            form.setFieldsValue(values);
        }
    }, [editingItem, lookupData]);

    const getRowKey = (record: Record<string, any>) => {
        const idField = fields.find(f => f.toLowerCase().endsWith("id"));
        return idField && record[idField] !== undefined ? String(record[idField]) : JSON.stringify(record);
    };

    // ---------------- Generic handleSave with parent update ----------------
    const handleSave = async (values: Record<string, any>) => {
        fields.forEach(f => {
            if (values[f] && moment.isMoment(values[f])) values[f] = values[f].format("YYYY-MM-DD");
            if (!editingItem && f.toLowerCase().includes("by")) values[f] = Number(loggedInUserId);
        });

        let method = "POST";
        let url = `${apiBaseUrl}/${resourceName}`;

        let parentIdField: string | null = null;
        let parentIdValue: any = null;

        if (editingItem) {
            method = "PUT";
            const pkField = fields[0];
            const pkValue = editingItem[pkField];
            delete values[pkField];
            url = `${apiBaseUrl}/${resourceName}/${pkValue}`;
        }

        // Detect parent field dynamically (any field ending with "id" but not PK)
        for (const f of Object.keys(values)) {
            if (f.toLowerCase() !== fields[0].toLowerCase() && f.toLowerCase().endsWith("id")) {
                parentIdField = f;
                parentIdValue = values[f];
                break;
            }
        }

        try {
            const res = await fetch(url, {
                method,
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(values),
            });

            if (!res.ok) throw new Error("Save failed");

            // ---------------- Call generic parent totals procedure ----------------
            if (parentIdField && parentIdValue) {
                const parentTable = parentIdField.replace(/Id$/i, "s"); // e.g., SalesOrderId -> SalesOrders
                await fetch(`${apiBaseUrl}/procedures/UpdateParentTotals`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ ParentTable: parentTable, ParentId: parentIdValue }),
                });
            }

            message.success("Saved successfully");
        } catch (err) {
            console.error(err);
            message.error("Save failed");
        } finally {
            setModalVisible(false);
            setEditingItem(null);
            form.resetFields();
            fetchData();
        }
    };

    // ---------------- Generic handleDelete with parent update ----------------
    const handleDelete = async (record: Record<string, any>) => {
        const rowKey = getRowKey(record);

        let parentIdField: string | null = null;
        let parentIdValue: any = null;
        for (const f of Object.keys(record)) {
            if (f.toLowerCase() !== fields[0].toLowerCase() && f.toLowerCase().endsWith("id")) {
                parentIdField = f;
                parentIdValue = record[f];
                break;
            }
        }

        try {
            await fetch(`${apiBaseUrl}/${resourceName}/${rowKey}`, { method: "DELETE" });

            if (parentIdField && parentIdValue) {
                const parentTable = parentIdField.replace(/Id$/i, "s");
                await fetch(`${apiBaseUrl}/procedures/UpdateParentTotals`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ ParentTable: parentTable, ParentId: parentIdValue }),
                });
            }

            message.success("Deleted successfully");
        } catch (err) {
            console.error(err);
            message.error("Delete failed");
        } finally {
            fetchData();
        }
    };

    const handleEdit = (record: Record<string, any>) => {
        const values = { ...record };
        fields.filter(f => f.toLowerCase().endsWith("id")).forEach(f => {
            if (record[f] !== undefined) values[f] = Number(record[f]);
        });
        setEditingItem(values);
        setModalVisible(true);
    };

    // ---------------- Columns ----------------
    const columns: ColumnsType<Record<string, any>> = [
        {
            title: "Actions",
            key: "actions",
            align: "center",
            fixed: "left",
            render: (_value, record) => (
                <Space>
                    <Button type="link" onClick={() => handleEdit(record)}>Edit</Button>
                    <Button type="link" danger onClick={() => handleDelete(record)}>Delete</Button>
                </Space>
            ),
        },
        ...fields.slice(0, 6).map(f => ({
            title: f,
            dataIndex: f,
            key: f,
            align: "left",
            render: (value) => {
                if (f.toLowerCase().endsWith("id") && lookupData[f]?.length) {
                    const item = lookupData[f].find(i => Number(i.id) === Number(value));
                    return item ? item.label : value;
                }
                if (typeof value === "number" || (!isNaN(Number(value)) && value !== "")) {
                    return <div style={{ textAlign: "right" }}>{Number(value).toLocaleString("en-US")}</div>;
                }
                return value?.toString() || "-";
            },
        })),
    ];

    const renderFormItem = (f: string, idx: number) => {
        if (!editingItem && idx === 0) return null;
        if (editingItem && idx === 0) return <Form.Item key={f} label={f} name={f}><Input disabled /></Form.Item>;

        if (f.toLowerCase().endsWith("id") || f.toLowerCase().endsWith("by")) {
            const options = lookupData[f]?.map(i => ({ label: i.label, value: i.id })) || [];
            return (
                <Form.Item key={f} label={f} name={f} rules={[{ required: true, message: `Please select ${f}` }]}>
                    <Select
                        options={options}
                        placeholder={`Select ${f}`}
                        showSearch
                        optionFilterProp="label"
                        disabled={f.toLowerCase().includes("by")}
                    />
                </Form.Item>
            );
        }

        if (f.toLowerCase().includes("is") || f.toLowerCase().includes("active") || f.toLowerCase().includes("enabled")) {
            return <Form.Item key={f} label={f} name={f} valuePropName="checked"><Checkbox /></Form.Item>;
        }

        if (f.toLowerCase().includes("date")) return <Form.Item key={f} label={f} name={f}><DatePicker style={{ width: "100%" }} /></Form.Item>;
        if (f.toLowerCase().includes("year")) return <Form.Item key={f} label={f} name={f}><DatePicker picker="year" style={{ width: "100%" }} /></Form.Item>;
        if (f.toLowerCase().includes("month")) return <Form.Item key={f} label={f} name={f}><DatePicker picker="month" style={{ width: "100%" }} /></Form.Item>;

        if (f.toLowerCase().includes("amount") || f.toLowerCase().includes("price") || f.toLowerCase().includes("total") ||
            f.toLowerCase().includes("qty") || f.toLowerCase().includes("quantity") || f.toLowerCase().includes("rate") ||
            f.toLowerCase().includes("balance") || f.toLowerCase().includes("number")) {
            return (
                <Form.Item key={f} label={f} name={f}>
                    <InputNumber
                        style={{ width: "100%" }}
                        formatter={(value) => `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ",")}
                        parser={(value) => value.replace(/,/g, "")}
                    />
                </Form.Item>
            );
        }

        return <Form.Item key={f} label={f} name={f}><Input /></Form.Item>;
    };

    return (
        <div style={{ padding: 20 }}>
            <div style={{ marginBottom: 16, display: "flex", alignItems: "center", gap: 8 }}>
                <Button type="primary" onClick={() => setModalVisible(true)}>Add {resourceName}</Button>
                {showMoreFields ? <Button onClick={() => setShowMoreFields(false)}>Hide Extra Fields</Button> : <Button onClick={() => setShowMoreFields(true)}>Show More Fields</Button>}
            </div>

            <Table
                dataSource={data}
                columns={columns}
                rowKey={getRowKey}
                loading={loading}
                scroll={{ x: "max-content" }}
                rowClassName={(record, index) => index % 2 === 0 ? "even-row" : "odd-row"}
            />

            <Modal
                title={editingItem ? `Edit ${resourceName}` : `Add ${resourceName}`}
                open={modalVisible}
                onCancel={() => { setModalVisible(false); setEditingItem(null); form.resetFields(); }}
                onOk={() => form.submit()}
                width={800}
            >
                <Form form={form} onFinish={handleSave} layout="vertical">
                    <Row gutter={16}>
                        {(showMoreFields ? fields : fields.slice(0, 6)).map((f, idx) => <Col span={8} key={f}>{renderFormItem(f, idx)}</Col>)}
                    </Row>
                </Form>
            </Modal>
        </div>
    );
};
