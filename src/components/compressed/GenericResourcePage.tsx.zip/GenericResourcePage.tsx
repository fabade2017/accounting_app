import { Table, Button, Modal, Form, Input } from "antd";
import { ColumnsType } from "antd/es/table";
import { useEffect, useState } from "react";

interface Props {
    resourceName: string;
    apiBaseUrl?: string;
    fields: string[];     // <-- NEW
}

export const GenericResourcePage = ({ resourceName, apiBaseUrl = "" , fields }: Props) => {
    const [data, setData] = useState<Record<string, unknown>[]>([]);
    const [loading, setLoading] = useState(false);
    const [modalVisible, setModalVisible] = useState(false);
    const [editingItem, setEditingItem] = useState<Record<string, unknown> | null>(null);
    const [form] = Form.useForm();

    const fetchData = async () => {
        setLoading(true);
        console.log(JSON.stringify(resourceName));
        const res = await fetch(`${apiBaseUrl}/${resourceName}`);
        const json: Record<string, unknown>[] = await res.json();
        setData(json);
        setLoading(false);
    };

    useEffect(() => {
        fetchData();
    }, [resourceName]);

    const handleSave = async (values: Record<string, unknown>) => {
        const method = editingItem ? "PUT" : "POST";
        const url = editingItem
            ? `${apiBaseUrl}/${resourceName}/${editingItem.id}`
            : `${apiBaseUrl}/${resourceName}`;

        await fetch(url, {
            method,
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(values),
        });
        
        setModalVisible(false);
        setEditingItem(null);
        form.resetFields();
        fetchData();
    };

    const handleEdit = (record: Record<string, unknown>) => {
        setEditingItem(record);
        form.setFieldsValue(record);
        setModalVisible(true);
    };

    const handleDelete = async (record: Record<string, unknown>) => {
        await fetch(`${apiBaseUrl}/${resourceName}/${record.id}`, {
            method: "DELETE",
        });
        fetchData();
    };
    // If there is no data, show Add button + empty form
if (!data || data.length === 0) {
    return (
        <div style={{ padding: 20 }}>
            <Button type="primary" onClick={() => setModalVisible(true)}>
                Add {resourceName}
            </Button>

            <p style={{ marginTop: 16 }}>No {resourceName} found.</p>

            <Modal
                title={`Add ${resourceName}`}
                open={modalVisible}
                onCancel={() => {
                    setModalVisible(false);
                    form.resetFields();
                }}
                onOk={() => form.submit()}
            >
                <Form form={form} onFinish={handleSave} layout="vertical">
                    {/** 🔥 FIX: If data doesn't exist, use editingItem or empty form */}

                    {(editingItem ? Object.keys(editingItem) : ["id", "name"]).map((key) => (
                        <Form.Item key={key} label={key} name={key}>
                            <Input />
                        </Form.Item>
                    ))}
                </Form>
            </Modal>
        </div>
    );
}

                    // if (!data || data.length === 0) {
                    //     return (
                    //         <div style={{ padding: 20 }}>
                    //             <Button type="primary" onClick={() => setModalVisible(true)}>
                    //                 Add {resourceName}
                    //             </Button>

                    //             <p style={{ marginTop: 16 }}>No {resourceName} found.</p>

                    //             <Modal
                    //                 title={`Add ${resourceName}`}
                    //                 open={modalVisible}
                    //                 onCancel={() => {
                    //                     setModalVisible(false);
                    //                     form.resetFields();
                    //                 }}
                    //                 onOk={() => form.submit()}
                    //             >
                    //                 <Form form={form} onFinish={handleSave} layout="vertical">
                    //                     <p>Enter details below:</p>
                    //                 </Form>
                    //             </Modal>
                    //         </div>
                    //     );
                    // }

  //  if (!data.length) return <div>Loading {resourceName}...</div>;

    // Define the columns type
    const columns: ColumnsType<Record<string, unknown>> = fields.map((key) => ({
        title: key,
        dataIndex: key,
        key: key,
    })) as ColumnsType<Record<string, unknown>>;

    // Add Actions column
    columns.push({
        title: "Actions",
        key: "actions",
        render: (_value: unknown, record: Record<string, unknown>) => (
            <>
                <Button type="link" onClick={() => handleEdit(record)}>
                    Edit
                </Button>
                <Button type="link" danger onClick={() => handleDelete(record)}>
                    Delete
                </Button>
            </>
        ),
    });

    return (
        <div>
            <Button type="primary" onClick={() => setModalVisible(true)}>
                Add {resourceName}
            </Button>
            <Table
                dataSource={data}
                columns={columns}
                rowKey={(record) => record.id as string}
                loading={loading}
            />

            <Modal
                title={editingItem ? `Edit ${resourceName}` : `Add ${resourceName}`}
                open={modalVisible}
                onCancel={() => {
                    setModalVisible(false);
                    setEditingItem(null);
                    form.resetFields();
                }}
                onOk={() => form.submit()}
            >
                <Form form={form} onFinish={handleSave} layout="vertical">
                    {/* {data.length > 0 &&
                        fields.map((key) => (
                            <Form.Item key={key} label={key} name={key}>
                                <Input />
                            </Form.Item>
                        ))} */}
                        {fields.map((key) => (
    <Form.Item key={key} label={key} name={key}>
        <Input />
    </Form.Item>
))}
                </Form>
            </Modal>
        </div>
    );
};
