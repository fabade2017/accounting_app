import React, { useEffect, useState } from "react";
import {
  Table,
  Button,
  Modal,
  Form,
  Input,
  Select,
  Space,
  message,
  Checkbox,
  Row,
  Col,
  DatePicker,
  InputNumber,
} from "antd";
import { ColumnsType } from "antd/es/table";
import moment from "moment";

interface Props {
  resourceName: string;
  apiBaseUrl?: string;
  fields: string[];
}

interface LookupItem {
  id: string | number;
  label: string;
  [k: string]: any;
}

export const GenericResourcePage: React.FC<Props> = ({
  resourceName,
  apiBaseUrl = "",
  fields,
}) => {
  const [data, setData] = useState<Record<string, any>[]>([]);
  const [loading, setLoading] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [editingItem, setEditingItem] = useState<Record<string, any> | null>(
    null
  );
  const [lookupData, setLookupData] = useState<Record<string, LookupItem[]>>(
    {}
  );
  const [fieldsForLookup, setFieldsForLookup] = useState<
    Record<string, string[]>
  >({});
  const [form] = Form.useForm();
  const [showAllFields, setShowAllFields] = useState(false);
  const [rowColor, setRowColor] = useState("#ffffff");
  const loggedInUserId = Number(localStorage.getItem("userId") || 0);

  // Lookup modal state (single modal reused for any lookup field)
  const [lookupModalVisible, setLookupModalVisible] = useState(false);
  const [lookupModalField, setLookupModalField] = useState<string | null>(
    null
  );
  const [lookupForm] = Form.useForm();

  const isReport = resourceName.toLowerCase().includes("report");
  const [reportParams, setReportParams] = useState<Record<string, any>>({});
  const [reportData, setReportData] = useState<any[]>([]);

  // Utils
  const shadeColor = (color: string, percent: number) => {
    let R = parseInt(color.substring(1, 3), 16);
    let G = parseInt(color.substring(3, 5), 16);
    let B = parseInt(color.substring(5, 7), 16);
    R = Math.min(255, Math.max(0, Math.round(R + R * percent)));
    G = Math.min(255, Math.max(0, Math.round(G + G * percent)));
    B = Math.min(255, Math.max(0, Math.round(B + B * percent)));
    const RR = R.toString(16).padStart(2, "0");
    const GG = G.toString(16).padStart(2, "0");
    const BB = B.toString(16).padStart(2, "0");
    return `#${RR}${GG}${BB}`;
  };

  const generateNumberField = (fieldName: string) => {
    const letters = (fieldName.match(/[A-Z]/g) || []).join("") || "";
    const datePart = moment().format("YYYYMMDD");
    const randomPart = Math.floor(Math.random() * 1_000_000_0000)
      .toString()
      .padStart(10, "0");
    return `${letters}${datePart}${randomPart}`;
  };

  // Fetch main data
  const fetchData = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${apiBaseUrl}/${resourceName}`);
      const json = await res.json();
      setData(Array.isArray(json) ? json : []);
    } catch (err) {
      console.error(err);
      message.error("Failed to load data");
    } finally {
      setLoading(false);
    }
  };

  // Run stored procedure style report
  const runReport = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${apiBaseUrl}/procedures/${resourceName}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(reportParams),
      });
      const json = await res.json();
      setReportData(Array.isArray(json) ? json : []);
    } catch (err) {
      console.error(err);
      message.error("Failed to run report");
    } finally {
      setLoading(false);
    }
  };

  // Build endpoint name for a lookup field
  const lookupEndpointFromField = (f: string) => {
    let endpoint = f.replace(/\s/g, "");
    if (endpoint.toLowerCase().endsWith("by")) endpoint = "users";
    if (endpoint.toLowerCase().endsWith("accountid")) endpoint = "bankaccounts";
    // common heuristics
    endpoint = endpoint
      .replace(/yId$/i, "ies")
      .replace(/y$/i, "ies")
      .replace(/ssId$/i, "sses")
      .replace(/Id$/i, "s");
    return endpoint.toLowerCase();
  };

  // Fetch lookups for fields (called after data load or on demand)
  const fetchLookups = async () => {
    const newLookup: Record<string, LookupItem[]> = {};
    const newFieldsForLookup: Record<string, string[]> = {};

    // use the provided fields list (so lookups are predictable)
    const lookupFields = fields.filter(
      (f) =>
        f.toLowerCase().endsWith("id") ||
        f.toLowerCase().endsWith("by") ||
        f.toLowerCase().endsWith("currency") ||
        f.toLowerCase().endsWith("company")
    );

    for (const f of lookupFields) {
      const endpoint = lookupEndpointFromField(f);
      try {
        const res = await fetch(`${apiBaseUrl}/${endpoint}`);
        if (!res.ok) {
          console.warn(`lookup fetch not ok for ${endpoint}`);
          continue;
        }
        const items = await res.json();
        if (!Array.isArray(items) || items.length === 0) {
          newLookup[f] = [];
          continue;
        }

        // choose sensible label fields (first few keys except id)
        const sample = items[0];
        const keys = Object.keys(sample);
        const labelCandidates = keys.filter((k) => /name|title|code|desc|label/i.test(k));
        const labelKeys = labelCandidates.length ? labelCandidates.slice(0, 2) : keys.slice(1, 4);

        newLookup[f] = items.map((i: any) => {
          const labelParts = labelKeys.map((k) => i[k]).filter(Boolean);
          const label = labelParts.length ? labelParts.join(" - ") : String(i[keys[0]]);
          return { id: i.id ?? i[Object.keys(i)[0]], label, ...i };
        });

        newFieldsForLookup[f] = keys;
      } catch (err) {
        console.error(`Failed to fetch lookup for ${f}`, err);
        newLookup[f] = [];
      }
    }

    setLookupData(newLookup);
    setFieldsForLookup(newFieldsForLookup);
  };

  useEffect(() => {
    if (isReport) runReport();
    else fetchData();
    fetchLookups();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [resourceName]);

  // When editingItem or lookups change, set form values
  useEffect(() => {
    if (editingItem) {
      const values = { ...editingItem };
      fields.forEach((f) => {
        if (f.toLowerCase().endsWith("id") && values[f] != null) values[f] = Number(values[f]);
        if (f.toLowerCase().includes("date") && values[f]) values[f] = moment(values[f]);
        if (f.toLowerCase().includes("year") && values[f]) values[f] = moment(values[f], "YYYY");
        if (f.toLowerCase().includes("month") && values[f]) values[f] = moment(values[f], "YYYY-MM");
      });
      form.setFieldsValue(values);
    } else {
      form.resetFields();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [editingItem, lookupData]);

  const getRowKey = (record: Record<string, any>) => {
    const idField = fields.find((f) => f.toLowerCase().endsWith("id"));
    return idField && record[idField] !== undefined ? String(record[idField]) : JSON.stringify(record);
  };

  // Save handler
  const handleSave = async (values: Record<string, any>) => {
    // convert moments and default values
    fields.forEach((f) => {
      if (values[f] && moment.isMoment(values[f])) values[f] = values[f].format("YYYY-MM-DD");
      if (!editingItem && f.toLowerCase().includes("by")) values[f] = loggedInUserId;
      if (!editingItem && f.toLowerCase().includes("number")) values[f] = generateNumberField(f);
    });

    let method = "POST";
    let url = `${apiBaseUrl}/${resourceName}`;
    if (editingItem) {
      method = "PUT";
      const pkField = fields[0];
      const pkValue = editingItem[pkField];
      if (pkField) delete values[pkField];
      url = `${apiBaseUrl}/${resourceName}/${pkValue}`;
    }

    try {
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(values),
      });
      if (!res.ok) throw new Error("Save failed");
      message.success("Saved successfully");
    } catch (err) {
      console.error(err);
      message.error("Save failed");
    } finally {
      setModalVisible(false);
      setEditingItem(null);
      form.resetFields();
      fetchData();
      fetchLookups();
    }
  };

  const handleEdit = (record: Record<string, any>) => {
    setEditingItem({ ...record });
    setModalVisible(true);
  };

  const handleDelete = async (record: Record<string, any>) => {
    const rowKey = getRowKey(record);
    try {
      const res = await fetch(`${apiBaseUrl}/${resourceName}/${rowKey}`, { method: "DELETE" });
      if (!res.ok) throw new Error("delete failed");
      message.success("Deleted successfully");
    } catch (err) {
      console.error(err);
      message.error("Delete failed");
    } finally {
      fetchData();
    }
  };

  // Add-new-for-lookup modal submit
  const handleAddNewLookup = async () => {
    if (!lookupModalField) return;
    try {
      const values = await lookupForm.validateFields().catch(() => null);
      // simple payload: try to use the keys available for that lookup, otherwise { name: value }
      let payload: Record<string, any> = {};
      if (values && Object.keys(values).length > 0) payload = values;
      else {
        const single = lookupForm.getFieldValue("name");
        payload = { name: single ?? lookupForm.getFieldValue(Object.keys(fieldsForLookup[lookupModalField] || {})[0]) ?? "" };
      }

      const endpoint = lookupEndpointFromField(lookupModalField);
      const res = await fetch(`${apiBaseUrl}/${endpoint}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!res.ok) throw new Error("create lookup failed");
      message.success("Added successfully");
      setLookupModalVisible(false);
      lookupForm.resetFields();
      await fetchLookups();
    } catch (err) {
      console.error(err);
      message.error("Failed to add lookup item");
    }
  };

  // Columns for table
  const columns: ColumnsType<Record<string, any>> = [
    {
      title: "Actions",
      key: "actions",
      fixed: "left",
      width: 140,
      render: (_v, record) => (
        <Space>
          <Button type="link" onClick={() => handleEdit(record)}>
            Edit
          </Button>
          <Button type="link" danger onClick={() => handleDelete(record)}>
            Delete
          </Button>
        </Space>
      ),
    },
    ...fields.slice(0, showAllFields ? fields.length : 6).map((f) => ({
      title: f,
      dataIndex: f,
      key: f,
      align:
        f.toLowerCase().includes("amount") ||
        f.toLowerCase().includes("price") ||
        f.toLowerCase().includes("total") ||
        f.toLowerCase().includes("qty") ||
        f.toLowerCase().includes("quantity") ||
        f.toLowerCase().includes("rate") ||
        f.toLowerCase().includes("balance") ||
        f.toLowerCase().includes("number")
          ? "right"
          : "left",
      render: (value) => {
        if (f.toLowerCase().endsWith("id") && lookupData[f]?.length) {
          const item = lookupData[f].find((i) => Number(i.id) === Number(value));
          return item ? item.label : value;
        }
        if ((typeof value === "number" || (!isNaN(Number(value)) && value !== "")) && !f.toLowerCase().includes("account")) {
          return <div style={{ textAlign: "right" }}>{Number(value).toLocaleString("en-US")}</div>;
        }
        return value?.toString() || "-";
      },
    })),
  ];

  // render form item (no hooks inside)
  const renderFormItem = (f: string, idx: number) => {
    if (!editingItem && idx === 0) return null;
    if (editingItem && idx === 0)
      return (
        <Form.Item key={f} label={f} name={f}>
          <Input disabled />
        </Form.Item>
      );

    if (f.toLowerCase().endsWith("id") || f.toLowerCase().endsWith("currency") || f.toLowerCase().endsWith("company") || f.toLowerCase().endsWith("by")) {
      const options = lookupData[f]?.map((i) => ({ label: i.label, value: i.id })) || [];
      return (
        <Form.Item key={f} label={
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <span>{f}</span>
            {/* show add button (disabled for xBy fields) */}
            {!f.toLowerCase().includes("by") && (
              <Button
                size="small"
                onClick={() => {
                  setLookupModalField(f);
                  setLookupModalVisible(true);
                }}
                style={{ marginLeft: 8 }}
              >
                + Add
              </Button>
            )}
          </div>
        } name={f} rules={[{ required: false }]}>
          <Select
            options={options}
            placeholder={`Select ${f}`}
            showSearch
            optionFilterProp="label"
            disabled={f.toLowerCase().includes("by")}
            allowClear
          />
        </Form.Item>
      );
    }

    if (f.toLowerCase().includes("is") || f.toLowerCase().includes("active") || f.toLowerCase().includes("enabled")) {
      return (
        <Form.Item key={f} label={f} name={f} valuePropName="checked">
          <Checkbox />
        </Form.Item>
      );
    }

    if (f.toLowerCase().includes("date")) return <Form.Item key={f} label={f} name={f}><DatePicker style={{ width: "100%" }} /></Form.Item>;
    if (f.toLowerCase().includes("year")) return <Form.Item key={f} label={f} name={f}><DatePicker picker="year" style={{ width: "100%" }} /></Form.Item>;
    if (f.toLowerCase().includes("month")) return <Form.Item key={f} label={f} name={f}><DatePicker picker="month" style={{ width: "100%" }} /></Form.Item>;

    if (f.toLowerCase().includes("amount") || f.toLowerCase().includes("price") || f.toLowerCase().includes("total") || f.toLowerCase().includes("qty") || f.toLowerCase().includes("quantity") || f.toLowerCase().includes("rate") || f.toLowerCase().includes("balance")) {
      return (
        <Form.Item key={f} label={f} name={f}>
          <InputNumber
            style={{ width: "100%" }}
            formatter={(value) => `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ",")}
            parser={(value) => (value ? value.toString().replace(/,/g, "") : "")}
          />
        </Form.Item>
      );
    }

    if (f.toLowerCase().includes("number")) {
      return (
        <Form.Item key={f} label={f} name={f}>
          <Input.Group compact>
            <Form.Item noStyle name={f}>
              <Input style={{ width: "calc(100% - 110px)" }} placeholder={`Enter ${f}`} />
            </Form.Item>
            {!editingItem && (
              <Button
                type="default"
                onClick={() => {
                  const prefix = (f.match(/[A-Z]/g) || []).join("") || "XX";
                  const dateStr = moment().format("YYYYMMDD");
                  const rand10 = Math.floor(Math.random() * 1_000_000_0000).toString().padStart(10, "0");
                  const newValue = `${prefix}${dateStr}${rand10}`;
                  form.setFieldValue(f, newValue);
                }}
                style={{ width: 110 }}
              >
                Regenerate
              </Button>
            )}
          </Input.Group>
        </Form.Item>
      );
    }

    return (
      <Form.Item key={f} label={f} name={f}>
        <Input />
      </Form.Item>
    );
  };

  return (
    <div style={{ padding: 20 }}>
      <Row style={{ marginBottom: 16 }} gutter={8}>
        <Col>
          <Button type="primary" onClick={() => { setModalVisible(true); setEditingItem(null); }}>
            Add {resourceName}
          </Button>
        </Col>
        <Col>
          <Button onClick={() => setShowAllFields((p) => !p)}>{showAllFields ? "Show Less" : "Show More Fields"}</Button>
        </Col>
        <Col>
          <input type="color" value={rowColor} onChange={(e) => setRowColor(e.target.value)} title="Select Row Color" style={{ width: 40, height: 32, border: "none" }} />
        </Col>
      </Row>

      {isReport ? (
        <>
          <Button type="primary" onClick={runReport} style={{ marginBottom: 16 }}>Run Report</Button>
          <Table
            dataSource={reportData}
            columns={
              reportData.length
                ? Object.keys(reportData[0]).map((k) => ({
                    title: k,
                    dataIndex: k,
                    key: k,
                    render: (value: any) => {
                      if (typeof value === "number" || (!isNaN(Number(value)) && value !== "")) {
                        return <div style={{ textAlign: "right" }}>{Number(value).toLocaleString("en-US")}</div>;
                      }
                      return value;
                    },
                  }))
                : []
            }
            rowKey={(r, i) => i.toString()}
            loading={loading}
          />
        </>
      ) : (
        <Table
          dataSource={data}
          columns={columns}
          rowKey={getRowKey}
          loading={loading}
          scroll={{ x: "max-content" }}
          rowClassName={(record, index) => (index % 2 === 0 ? "even-row" : "odd-row")}
          style={{ ["--row-bg-even" as any]: rowColor, ["--row-bg-odd" as any]: shadeColor(rowColor, -0.05) } as any}
          locale={{ emptyText: `No ${resourceName} found` }}
        />
      )}

      <Modal
        title={editingItem ? `Edit ${resourceName}` : `Add ${resourceName}`}
        open={modalVisible}
        onCancel={() => { setModalVisible(false); setEditingItem(null); form.resetFields(); }}
        onOk={() => form.submit()}
        width={900}
      >
        <Form form={form} onFinish={handleSave} layout="vertical">
          <Row gutter={16}>
            {fields.map((f, idx) => (
              <Col span={8} key={f}>
                {renderFormItem(f, idx)}
              </Col>
            ))}
          </Row>
        </Form>
      </Modal>

      {/* Lookup add modal */}
      <Modal
        title={lookupModalField ? `Add New ${lookupModalField}` : "Add New"}
        open={lookupModalVisible}
        onCancel={() => { setLookupModalVisible(false); lookupForm.resetFields(); setLookupModalField(null); }}
        onOk={handleAddNewLookup}
      >
        <Form form={lookupForm} layout="vertical">
          {lookupModalField && fieldsForLookup[lookupModalField] ? (
            // render inputs for available keys in that lookup sample
            fieldsForLookup[lookupModalField].slice(0, 4).map((k) => (
              <Form.Item key={k} name={k} label={k} rules={[{ required: k.toLowerCase() === "name" || k.toLowerCase().includes("name") }]}>
                <Input />
              </Form.Item>
            ))
          ) : (
            // fallback: simple name field
            <Form.Item name="name" label="Name" rules={[{ required: true }]}>
              <Input />
            </Form.Item>
          )}
        </Form>
      </Modal>

      <style>{`
        .even-row { background-color: var(--row-bg-even, #ffffff); }
        .odd-row { background-color: var(--row-bg-odd, #f9f9f9); }
      `}</style>
    </div>
  );
};

export default GenericResourcePage;
