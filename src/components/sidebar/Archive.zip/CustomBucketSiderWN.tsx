// src/components/sidebar/CustomBucketSider.tsx
import React, { useState, useEffect } from "react";
import {
  DashboardOutlined,
  TeamOutlined,
  ShopOutlined,
  GoldOutlined,
  BookOutlined,
  FileTextOutlined,
  RightOutlined,
  DownOutlined,
} from "@ant-design/icons";
import { Layout, Menu, theme } from "antd";
import { Link, useLocation } from "react-router-dom";

const { Sider } = Layout;

export const CustomBucketSider: React.FC = () => {
  const { token } = theme.useToken();
  const location = useLocation();

  const menuGroups = [
    { key: "dashboard", icon: <DashboardOutlined />, label: "Dashboard", path: "/dashboard" },

   {
      key: "ar",
      icon: <TeamOutlined />,
      label: "Accounts Receivable",
      items: [
        { label: "Customers", path: "/customers" },
        { label: "Invoices", path: "/invoices" },
        { label: "Receipts", path: "/receipts" },
        { label: "Sales Orders", path: "/salesorders" },
      ],
    },
  /*   {
      key: "ap",
      icon: <ShopOutlined />,
      label: "Accounts Payable",
      items: [
        { label: "Suppliers", path: "/suppliers" },
        { label: "Purchase Orders", path: "/purchaseorders" },
        { label: "Supplier Invoices", path: "/supplierinvoices" },
      ],
    },
    {
      key: "inventory",
      icon: <GoldOutlined />,
      label: "Inventory",
      items: [
        { label: "Products", path: "/products" },
        { label: "Inventory Stock", path: "/inventorystock" },
        { label: "Warehouses", path: "/warehouses" },
      ],
    },
    {
      key: "gl",
      icon: <BookOutlined />,
      label: "General Ledger",
      items: [
        { label: "Chart of Accounts", path: "/chartofaccounts" },
        { label: "Journal Entries", path: "/journalentries" },
        { label: "General Ledger", path: "/generalledger" },
        { label: "Bank Accounts", path: "/bankaccounts" },
      ],
    },
    {
      key: "assets",
      icon: <FileTextOutlined />,
      label: "Assets & Budgets",
      items: [
        { label: "Fixed Assets", path: "/fixedassets" },
        { label: "Budgets", path: "/budgets" },
      ],
    },*/
  ];

  // Auto-expand the group containing the current route
  const autoOpen = menuGroups
   // .filter(group => group.items?.some(item => location.pathname.startsWith(item.path)))
    .map(g => g.key);

  const [openKeys, setOpenKeys] = useState<string[]>(autoOpen);

  useEffect(() => {
    setOpenKeys(autoOpen);
  }, [location.pathname]);

  const items = menuGroups.map(group => {
    if (group.items) {
      return {
        key: group.key,
        icon: group.icon,
        label: (
          <div style={{ display: "flex", justifyContent: "space-between", width: "100%" }}>
            <span>{group.label}</span>
            {openKeys.includes(group.key) ? (
              <DownOutlined style={{ fontSize: 12 }} />
            ) : (
              <RightOutlined style={{ fontSize: 12 }} />
            )}
          </div>
        ),
        // children: group.items.map(item => ({
        //   key: item.path,
        //   label: <Link to={item.path}>{item.label}</Link>,
        // })),
      };
    }

    return {
      key: group.path,
      icon: group.icon,
      label: <Link to={group.path}>{group.label}</Link>,
    };
  });

  return (
    <Sider
      width={280}
      style={{
        background: token.colorBgContainer,
        position: "fixed",
        height: "100vh",
        left: 0,
        top: 0,
        borderRight: `1px solid ${token.colorBorder}`,
        zIndex: 1000,
      }}
    >
      <div
        style={{
          height: 64,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: 22,
          fontWeight: "bold",
          color: token.colorPrimary,
          borderBottom: `1px solid ${token.colorBorder}`,
        }}
      >
        My ERP Pro
      </div>

      <Menu
        mode="inline"
        selectedKeys={[location.pathname]}
        openKeys={openKeys}
        onOpenChange={setOpenKeys}
        style={{ borderRight: 0, marginTop: 16 }}
        items={items}
      />
    </Sider>
  );
};
