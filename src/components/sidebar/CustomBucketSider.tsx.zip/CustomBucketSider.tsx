// src/components/sidebar/CustomBucketSider.tsx
import React, { useState } from "react";
import { useTranslate, useIsExistAuthentication } from "@refinedev/core";
import {
  DashboardOutlined,
  SettingOutlined,
  ShopOutlined,
  TeamOutlined,
  DollarCircleOutlined,
  BarChartOutlined,
  UserOutlined,
  RightOutlined,
  DownOutlined,
} from "@ant-design/icons";
import { Layout, Menu, theme } from "antd";
const { Sider } = Layout;

export const CustomBucketSider: React.FC = () => {
  const { token } = theme.useToken();
  const t = useTranslate();
  
  const [openKeys, setOpenKeys] = useState<string[]>(["general"]);

  const toggle = (key: string) => {
    setOpenKeys(prev => 
      prev.includes(key) ? prev.filter(k => k !== key) : [...prev, key]
    );
  };

  const isActive = (path: string) => 
    window.location.pathname.startsWith(path);

  const items = [
    { key: "dashboard", label: t("dashboard", "Dashboard"), icon: <DashboardOutlined />, path: "/dashboard" },
    {
      key: "general",
      label: t("generalSetup", "General Setup"),
      icon: <SettingOutlined />,
      children: [
        { key: "company-profile", label: "Company Profile", path: "/general/company-profile" },
        { key: "branches", label: "Branches", path: "/general/branches" },
        { key: "departments", label: "Departments", path: "/general/departments" },
        { key: "currency", label: "Currency", path: "/general/currency" },
        { key: "exchange-rates", label: "Exchange Rates", path: "/general/exchange-rates" },
        { key: "financial-year", label: "Financial Year", path: "/general/financial-year" },
      ],
    },
    {
      key: "products",
      label: t("productSetup", "Product Setup"),
      icon: <ShopOutlined />,
      children: [
        { key: "category", label: "Categories", path: "/products/category" },
        { key: "list", label: "Product List", path: "/products/list" },
        { key: "pricing", label: "Pricing", path: "/products/pricing" },
      ],
    },
    {
      key: "customers",
      label: t("customerManagement", "Customer Management"),
      icon: <TeamOutlined />,
      children: [
        { key: "list", label: "Customer List", path: "/customers/list" },
        { key: "groups", label: "Groups", path: "/customers/group" },
        { key: "rating", label: "Rating", path: "/customers/rating" },
      ],
    },
    {
      key: "reports",
      label: t("reports", "Reports"),
      icon: <BarChartOutlined />,
      children: [
        { key: "profit-loss", label: "Profit & Loss", path: "/reports/profit-loss" },
        { key: "balance-sheet", label: "Balance Sheet", path: "/reports/balance-sheet" },
        { key: "trial-balance", label: "Trial Balance", path: "/reports/trial-balance" },
      ],
    },
    {
      key: "admin",
      label: t("administration", "Administration"),
      icon: <UserOutlined />,
      children: [
        { key: "users", label: "Users", path: "/admin/users" },
        { key: "roles", label: "Roles", path: "/admin/roles" },
        { key: "audit", label: "Audit Trail", path: "/admin/audit" },
      ],
    },
  ];

  const renderMenuItems = (data: any[]) => {
    return data.map(item => {
      if (item.children) {
        return {
          key: item.key,
          icon: item.icon,
          label: (
            <div className="flex justify-between items-center">
              <span>{item.label}</span>
              {openKeys.includes(item.key) ? <DownOutlined className="text-xs" /> : <RightOutlined className="text-xs" />}
            </div>
          ),
          onTitle: item.label,
          onTitleClick: () => toggle(item.key),
          children: renderMenuItems(item.children),
        };
      }
      return {
        key: item.key,
        icon: item.icon,
        label: <a href={item.path}>{item.label}</a>,
      };
    });
  };

  return (
    <Sider
      width={256}
      style={{
        background: token.colorBgContainer,
        borderRight: `1px solid ${token.colorBorder}`,
      }}
    >
      {/* Logo – exactly like default Refine */}
      <div
        style={{
          height: 64,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: 20,
          fontWeight: "bold",
          color: token.colorPrimary,
          borderBottom: `1px solid ${token.colorBorder}`,
        }}
      >
        My ERP Pro
      </div>

      <Menu
        mode="inline"
        selectedKeys={[window.location.pathname]}
        openKeys={openKeys}
        onOpenChange={setOpenKeys}
        style={{ borderRight: 0, marginTop: 16 }}
        items={renderMenuItems(items)}
      />
    </Sider>
  );
};