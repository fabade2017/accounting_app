import { Layout, Avatar, Dropdown, Space, Input } from "antd";
import type { MenuProps } from "antd";
import { UserOutlined, LogoutOutlined, BellOutlined } from "@ant-design/icons";

const { Header } = Layout;
const { Search } = Input;

interface AppHeaderProps {
  onSearchChange: (value: string) => void;
}

export const AppHeader: React.FC<AppHeaderProps> = ({ onSearchChange }) => {
  const username = localStorage.getItem("userName") || "User";

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("userName");
    localStorage.removeItem("userid");
    window.location.href = "/login";
  };

  const menuItems: MenuProps["items"] = [
    {
      key: "logout",
      label: (
        <span onClick={handleLogout}>
          <LogoutOutlined style={{ marginRight: 8 }} />
          Logout
        </span>
      ),
    },
  ];

  return (
    <Header
      style={{
        background: "var(--card-color)",
        color: "var(--text-color)",
        padding: "0 24px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        height: 64,
        boxShadow: "0 2px 5px rgba(0,0,0,0.1)",
      }}
    >
      {/* Left */}
      <div style={{ fontSize: 20, fontWeight: 600, minWidth: 200 }}>
        Admin Dashboard
      </div>

      {/* Center */}
      <div style={{ flex: 1, maxWidth: 500, margin: "0 32px" }}>
        <Search
          placeholder="Search modules..."
          allowClear
          enterButton="Search"
          onSearch={onSearchChange}
          style={{ width: "100%" }}
        />
      </div>

      {/* Right */}
      <Space size="large">
        <BellOutlined style={{ fontSize: 20, cursor: "pointer" }} />

        <Dropdown menu={{ items: menuItems }} placement="bottomRight">
          <Space style={{ cursor: "pointer" }}>
            <Avatar
              size="small"
              style={{ background: "#3b82f6" }}
              icon={<UserOutlined />}
            />
            <span>{username}</span>
          </Space>
        </Dropdown>
      </Space>
    </Header>
  );
};


// import { Layout, Avatar, Dropdown, Space, Input } from "antd";
// import type { MenuProps } from "antd";
// import { UserOutlined, LogoutOutlined, BellOutlined } from "@ant-design/icons";

// const { Header } = Layout;
// const { Search } = Input;

// interface AppHeaderProps {
//   onSearchChange: (value: string) => void;
// }

// export const AppHeader: React.FC<AppHeaderProps> = ({ onSearchChange }) => {
//   const username = localStorage.getItem("userName") || "User";

//   const handleLogout = () => {
//     localStorage.removeItem("token");
//     localStorage.removeItem("userName");
//     localStorage.removeItem("userid");
//     window.location.href = "/login";
//   };

//   const menuItems: MenuProps["items"] = [
//     {
//       key: "logout",
//       label: (
//         <span onClick={handleLogout}>
//           <LogoutOutlined style={{ marginRight: 8 }} />
//           Logout
//         </span>
//       ),
//     },
//   ];

//   return (
//     <Header style={{ display: "flex", justifyContent: "space-between" }}>
//       <div style={{ fontSize: 20, fontWeight: 600 }}>Admin Dashboard</div>

//       <Search
//         placeholder="Search modules..."
//         onSearch={onSearchChange}
//         style={{ maxWidth: 500 }}
//       />

//       <Space size="large">
//         <BellOutlined />

//         <Dropdown menu={{ items: menuItems }} placement="bottomRight">
//           <Space style={{ cursor: "pointer" }}>
//             <Avatar icon={<UserOutlined />} />
//             <span>{username}</span>
//           </Space>
//         </Dropdown>
//       </Space>
//     </Header>
//   );
// };
