 import React, { useEffect, useRef, useState, useCallback } from "react";
import {
  Table,
  Button,
  Modal,
  Form,
  Input,
  Select,
  Space,
  message,
  Checkbox,
  Row,
  Col,
  DatePicker,
  InputNumber,
  InputRef,
  Typography,
  Divider,
  Alert,
} from "antd";
import { SearchOutlined, PlusOutlined } from "@ant-design/icons";
import type { FilterConfirmProps } from "antd/es/table/interface";
import { ColumnsType } from "antd/es/table";
import moment from "moment";
import Highlighter from "react-highlight-words";
const { Text } = Typography;
interface LookupItem {
  id: string | number;
  label: string;
  [k: string]: any;
}
// interface DetailConfig {
// resourceName: string;
// foreignKey: string;
// fields: string[];
// quantityField?: string;
// priceField?: string;
// lineTotalField?: string;
// taxField?: string;
// }
interface DetailConfig {
  resourceName: string; // Line item API/table
  foreignKey: string; // e.g. InvoiceId
  fields: string[]; // Columns in line items table
  quantityField?: string;
  priceField?: string;
  lineTotalField?: string;
  taxField?: string;
}
interface Props {
  resourceName: string;
  apiBaseUrl?: string;
  fields: string[];
  detailConfig?: DetailConfig;
}
export const GenericResourcePage: React.FC<Props> = ({
  resourceName,
  apiBaseUrl = "",
  fields,
  detailConfig,
}) => {
  const [data, setData] = useState<Record<string, any>[]>([]);
  const [loading, setLoading] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [editingItem, setEditingItem] = useState<Record<string, any> | null>(null);
  const [lookupData, setLookupData] = useState<Record<string, LookupItem[]>>({});
  const [fieldsForLookup, setFieldsForLookup] = useState<Record<string, string[]>>({});
  const [form] = Form.useForm();
  const [showAllFields, setShowAllFields] = useState(false);
  const [rowColor, setRowColor] = useState("#ffffff");
  const [globalSearch, setGlobalSearch] = useState("");
  const [searchText, setSearchText] = useState("");
  const [searchedColumn, setSearchedColumn] = useState("");
  const [sortedInfo, setSortedInfo] = useState<{ columnKey?: string; order?: "ascend" | "descend" }>({});
  const searchInput = useRef<InputRef>(null);
  const loggedInUserId = Number(localStorage.getItem("userid") || 0);
  const [lookupModalVisible, setLookupModalVisible] = useState(false);
  const [lookupModalField, setLookupModalField] = useState<string | null>(null);
  const [lookupForm] = Form.useForm();
  const isReport = resourceName.toLowerCase().includes("report");
  const [reportParams, setReportParams] = useState<Record<string, any>>({});
  const [reportData, setReportData] = useState<any[]>([]);
  //const isMaster = !!detailConfig;
const [detailConfigState, setDetailConfigState] = useState<DetailConfig | undefined>(undefined);
const effectiveDetailConfig = detailConfig || detailConfigState;
const isMaster = Boolean(effectiveDetailConfig);
  const qtyField = effectiveDetailConfig?.quantityField || "quantity";
  const priceField = effectiveDetailConfig?.priceField || "price";
  const lineTotalField = effectiveDetailConfig?.lineTotalField || "lineTotal";
  const taxField = effectiveDetailConfig?.taxField;
  const [excludedLookupFields, setExcludedLookupFields] = useState<string[]>([]);
  // For lazy-loaded expandable line items
  const [expandedRowKeys, setExpandedRowKeys] = useState<string[]>([]);
  const [expandedLines, setExpandedLines] = useState<Record<string, any[]>>({});
  const [warning, setWarning] = useState("");
  const [lineWarning, setLineWarning] = useState("");
  const [lineModalVisible, setLineModalVisible] = useState(false);
  const [currentMaster, setCurrentMaster] = useState<Record<string, any> | null>(null);
  const [lineForm] = Form.useForm();
  // ==================== Helpers ====================
  const handleSearch = (
    selectedKeys: string[],
    confirm: (param?: FilterConfirmProps) => void,
    dataIndex: string,
  ) => {
    confirm();
    setSearchText(selectedKeys[0]);
    setSearchedColumn(dataIndex);
  };
  const handleReset = (clearFilters: () => void) => {
    clearFilters();
    setSearchText("");
  };
  const getColumnSearchProps = (dataIndex: string): any => ({
    filterDropdown: ({ setSelectedKeys, selectedKeys, confirm, clearFilters }: any) => (
      <div style={{ padding: 8 }} onKeyDown={(e) => e.stopPropagation()}>
        <Input
          ref={searchInput}
          placeholder={`Search ${dataIndex}`}
          value={selectedKeys[0]}
          onChange={(e) => setSelectedKeys(e.target.value ? [e.target.value] : [])}
          onPressEnter={() => handleSearch(selectedKeys as string[], confirm, dataIndex)}
          style={{ marginBottom: 8, display: "block" }}
        />
        <Space>
          <Button
            type="primary"
            onClick={() => handleSearch(selectedKeys as string[], confirm, dataIndex)}
            icon={<SearchOutlined />}
            size="small"
            style={{ width: 90 }}
          >
            OK
          </Button>
          <Button onClick={() => clearFilters && handleReset(clearFilters)} size="small" style={{ width: 90 }}>
            Reset
          </Button>
        </Space>
      </div>
    ),
    filterIcon: (filtered: boolean) => <SearchOutlined style={{ color: filtered ? "#1677ff" : undefined }} />,
    onFilter: (value: any, record: any) =>
      record[dataIndex] ? String(record[dataIndex]).toLowerCase().includes((value as string).toLowerCase()) : false,
    onFilterDropdownOpenChange: (visible: boolean) => {
      if (visible) {
        setTimeout(() => searchInput.current?.select(), 100);
      }
    },
    render: (text: any) =>
      searchedColumn === dataIndex ? (
        <Highlighter
          highlightStyle={{ backgroundColor: "#ffc069", padding: 0 }}
          searchWords={[searchText]}
          autoEscape
          textToHighlight={text ? text.toString() : ""}
        />
      ) : (
        text
      ),
  });
  const shadeColor = (color: string, percent: number) => {
    let R = parseInt(color.substring(1, 3), 16);
    let G = parseInt(color.substring(3, 5), 16);
    let B = parseInt(color.substring(5, 7), 16);
    R = Math.min(255, Math.max(0, Math.round(R + R * percent)));
    G = Math.min(255, Math.max(0, Math.round(G + G * percent)));
    B = Math.min(255, Math.max(0, Math.round(B + B * percent)));
    const RR = R.toString(16).padStart(2, "0");
    const GG = G.toString(16).padStart(2, "0");
    const BB = B.toString(16).padStart(2, "0");
    return `#${RR}${GG}${BB}`;
  };
  const generateNumberField = (fieldName: string) => {
    const letters = (fieldName.match(/[A-Z]/g) || []).join("") || "";
    const datePart = moment().format("YYYYMMDD");
    const randomPart = Math.floor(Math.random() * 1_000_000_0000)
      .toString()
      .padStart(10, "0");
    return `${letters}${datePart}${randomPart}`;
  };
const normalize = (s: string) =>
  s.toLowerCase().replace(/[^a-z0-9]/g, "");

const singularize = (name: string) => {
  if (name.endsWith("ies")) return name.slice(0, -3) + "y";
  if (name.endsWith("ses")) return name.slice(0, -2);
  if (name.endsWith("s")) return name.slice(0, -1);
  return name;
};

const resolveDetailConfig = async (
  resourceName: string
): Promise<DetailConfig | null> => {
  const masterNorm = normalize(resourceName);
  const masterSingular = singularize(masterNorm);

  // 1️⃣ Ask backend for tables (preferred)
  const candidates = [
    `${masterSingular}lineitems`,
    `${masterNorm}lineitems`,
    `${masterSingular}_lineitems`,
    `${masterNorm}_lineitems`,
  ];

  for (const table of candidates) {
    try {
      const res = await fetch(`${apiBaseUrl}/${table}?_limit=1`);
      if (!res.ok) continue;

      const rows = await res.json();
      if (!Array.isArray(rows) || !rows.length) continue;

      const fields = Object.keys(rows[0]);

      // 2️⃣ Find FK properly
      const fk = fields.find(f =>
        normalize(f).includes(masterSingular) &&
        normalize(f).endsWith("id")
      );

      if (!fk) continue;

      return {
        resourceName: table,
        foreignKey: fk,
        fields,
        quantityField: fields.find(f => /qty|quantity/i.test(f)),
        priceField: fields.find(f => /price|rate/i.test(f)),
        lineTotalField: fields.find(f => /total|amount/i.test(f)),
        taxField: fields.find(f => /tax/i.test(f)),
      };
    } catch {
      continue;
    }
  }

  return null;
};

  const _resolveDetailConfigDDD = async (
  resourceName: string
): Promise<DetailConfig | null> => {
  const lineItemName = `${resourceName.replace(/s$/, "")}LineItems`;

  try {
    const res = await fetch(`${apiBaseUrl}/${lineItemName}?_limit=1`);
    if (!res.ok) return null;

    const sample = await res.json();
    if (!Array.isArray(sample) || !sample.length) return null;

    const fields = Object.keys(sample[0]);

    const foreignKey = fields.find(f =>
      f.toLowerCase().includes(resourceName.replace(/s$/, "")) &&
      f.toLowerCase().endsWith("id")
    );

    if (!foreignKey) return null;

    return {
      resourceName: lineItemName,
      foreignKey,
      fields,
      quantityField: fields.find(f => /qty|quantity/i.test(f)),
      priceField: fields.find(f => /price|rate/i.test(f)),
      lineTotalField: fields.find(f => /total|amount/i.test(f)),
      taxField: fields.find(f => /tax/i.test(f)),
    };
  } catch {
    return null;
  }
};
useEffect(() => {
  (async () => {
    const detected = await resolveDetailConfig(resourceName);
    if (detected) {
      setDetailConfigState(detected);
    }
  })();
}, [resourceName]);
  // ==================== Data Fetching ====================
  const fetchData = async () => {
    // alert(`${resourceName}`);
   setData([]);
    setLoading(true);
    try {
      const res = await fetch(`${apiBaseUrl}/${resourceName}`);
      const json = await res.json();
      setData(Array.isArray(json) ? json : []);
    // console.log(data);
    } catch (err) {
      message.error("Failed to load data" + err);
    } finally {
      setLoading(false);
    }
  };
  const runReport = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${apiBaseUrl}/procedures/${resourceName}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(reportParams),
      });
      const json = await res.json();
      setReportData(Array.isArray(json) ? json : []);
    } catch (err) {
      message.error("Failed to run report");
    } finally {
      setLoading(false);
    }
  };

  const fetchLineItems = async (parentId: any) => {
  if (!detailConfig) return [];
console.log("Did I reach here...");
  const fk = detailConfig.foreignKey;

  const attempts = [
    `${fk}=${parentId}`,
    `${fk.toLowerCase()}=${parentId}`,
    `${fk.replace(/[A-Z]/g, m => "_" + m.toLowerCase())}=${parentId}`,
    `parentid=${parentId}`,
  ];

  for (const q of attempts) {
    try {
      const res = await fetch(
        `${apiBaseUrl}/${detailConfig.resourceName}?${q}`
      );
      const json = await res.json();

      if (Array.isArray(json) && json.length) {
        return json;
      }
    } catch {}
  }

  // fallback → return empty (NOT ALL DATA)
  return [];
};
const stripLineItems = (obj: any) => {
  const clean = { ...obj };
  delete clean.lineItems;
  return clean;
};

  // const fetchLineItems = async (parentId: any) => {
  //   if (!effectiveDetailConfig) return [];
  //   try {
  //     const res = await fetch(`${apiBaseUrl}/${effectiveDetailConfig.resourceName}?${effectiveDetailConfig.foreignKey}=${parentId}`);
  //     const json = await res.json();
  //     return Array.isArray(json) ? json : [];
  //   } catch (err) {
  //     message.error("Failed to load line items");
  //     return [];
  //   }
  // };
  const lookupEndpointFromField = (f: string) => {
    let endpoint = f.replace(/\s/g, "");
    if (endpoint.toLowerCase().endsWith("by")) endpoint = "users";
   // if (endpoint.toLowerCase().endsWith("by")) endpoint = "users";
    if (endpoint.toLowerCase().endsWith("accountid")) endpoint = "bankaccountid";
     if (endpoint.toLowerCase().endsWith("goodsreceivedid")) endpoint = "goodsreceivedid";
    endpoint = endpoint
      .replace(/yId$/i, "ies")
       .replace(/type$/i, "types")
      .replace(/y$/i, "ies")
      .replace(/ssId$/i, "sses")
     // .replace(/erId$/i, "er")
      .replace(/edId$/i, "ed")
      .replace(/Id$/i, "s");
    return endpoint.toLowerCase();
  };
  // ==================== Fetch Lookups ====================
  const fetchLookups = async () => {
    const newLookup: Record<string, LookupItem[]> = {};
    const newFieldsForLookup: Record<string, string[]> = {};
    const allFields = [...fields, ...(effectiveDetailConfig?.fields || [])];
  
    const lookupFields = allFields.filter((f) => {
      const lower = f.toLowerCase();
      if (excludedLookupFields.length > 0 && excludedLookupFields.some(ex => lower === ex || lower.endsWith(ex))) {
        console.log("Same: "+JSON.stringify(excludedLookupFields) +" " + lower);
        return false;
      }
      if (
        lower.endsWith("id") ||
        lower.endsWith("currency") ||
        lower.endsWith("company") ||
          lower.endsWith("accounttype") || lower.endsWith("entitytype") || lower.endsWith("status") ||
        lower.endsWith("edby")
      ) {
        return true;
      }
      return false;
    });
    for (const f of lookupFields) {
      let endpointField = f;
      if (f.toLowerCase().endsWith("edby") || f.toLowerCase().endsWith("by")) {
        endpointField = "users";
      }
      let endpoint = lookupEndpointFromField(endpointField);
       
      endpoint=  endpoint.toLowerCase().replace("lines","lineitems");

       console.log(`Endpoing:  ${endpoint}`);
        console.log(`Endpoing:  ${apiBaseUrl}/${endpoint}`);
      try {
        const res = await fetch(`${apiBaseUrl}/${endpoint}`);
        if (!res.ok) continue;
        const items = await res.json();
        if (!Array.isArray(items) || items.length === 0) continue;
        const sample = items[0];
        const keys = Object.keys(sample);
        const labelCandidates = keys.filter((k) => /name|title|code|desc|label/i.test(k));
        const labelKeys = labelCandidates.length ? labelCandidates.slice(0, 2) : keys.slice(1, 4);
        newLookup[f] = items.map((i: any) => {
          const labelParts = labelKeys.map((k) => i[k]).filter(Boolean);
          const label = labelParts.length ? labelParts.join(" - ") : String(i.id || i[keys[0]]);
          return { id: i.id ?? i[Object.keys(i)[0]], label, ...i };
        });
        newFieldsForLookup[f] = keys;
      } catch (err) {
        console.error(`Fetch failed for ${f} → ${endpoint}`, err);
      }
    }
    setLookupData(newLookup);
    setFieldsForLookup(newFieldsForLookup);
  };
  // ==================== Load Excluded Fields ====================
  useEffect(() => {
    const fetchExcludedLookups = async () => {
      try {
        const res = await fetch(`${apiBaseUrl}/excludedlookup`);
        if (res.ok) {
          const json = await res.json();
          const names = json.map((item: { Id: number; Name: string }) => item.Name.toLowerCase());
          setExcludedLookupFields(names);
        } else {
          throw new Error("Bad response");
        }
      } catch (err) {
        console.warn("Failed to load excluded lookups, using fallback", err);
        setExcludedLookupFields(["transactionid", "referenceid", "movementid", "parentid", "grnid"]);
      }
    };
    fetchExcludedLookups();
  }, [apiBaseUrl]);
useEffect(() => {
  if (editingItem) {
    // Only set values if we are editing and the item exists
    form.setFieldsValue(editingItem);
  } else {
    // Optionally reset the form when adding a new item
    form.resetFields();
  }
}, [editingItem, form]); // Re-run whenever editingItem or form changes
  // ==================== Initial Load ====================
  useEffect(() => {
    if (isReport) runReport();
    else fetchData();
     fetchLookups();
  }, [resourceName, excludedLookupFields, effectiveDetailConfig]);
  // ==================== Auto-detect Detail Config ====================
  useEffect(() => {
        console.log(resourceName);
        resourceName.replace("lines","lineitems");
    if (!detailConfig && !resourceName.toLowerCase().endsWith("lineitems") && !isReport) {
      let singularBase = resourceName;
      console.log(singularBase);
      if (singularBase.endsWith("ies")) singularBase = singularBase.slice(0, -3) + "y";
      else if (singularBase.endsWith("sses")) singularBase = singularBase.slice(0, -2);
      else if (singularBase.endsWith("s")) singularBase = singularBase.slice(0, -1);
      const detailResource = `${singularBase}`.toLowerCase();
      const foreignKey = `${singularBase}Id`.toLowerCase();
      const checkDetail = async () => {
        setLoading(true);
        try {
          const res = await fetch(`${apiBaseUrl}/${detailResource}`);
          if (res.ok) {
            const json = await res.json();
            if (Array.isArray(json) && json.length > 0) {
              const sample = json[0];
              const detailFields = Object.keys(sample);
              setDetailConfigState({
                resourceName: detailResource,
                foreignKey,
                fields: detailFields,
                quantityField: detailFields.find((f) => /quantity|qty/i.test(f.toLowerCase())) || "quantity",
                priceField: detailFields.find((f) => /price|rate|amount/i.test(f.toLowerCase())) || "price",
                lineTotalField: detailFields.find((f) => /linetotal|total/i.test(f.toLowerCase())) || "lineTotal",
                taxField: detailFields.find((f) => /tax|vat/i.test(f.toLowerCase())),
              });
            }
          }
        } catch {}
        setLoading(false);
      };
      checkDetail();
    }
  }, [resourceName, apiBaseUrl, detailConfig, isReport]);
  // ==================== Edit & Calculations ====================
const handleEdit = async (record: Record<string, any>) => {
  // 1. Reset form completely
  form.resetFields();
  // 2. Make a deep copy and normalize ALL possible field types
  const normalizedValues: Record<string, any> = {};
  // Process master fields
  fields.forEach((field) => {
    let value = record[field];
    if (value === undefined || value === null) {
      normalizedValues[field] = undefined;
      return;
    }
    const lower = field.toLowerCase();
    // Date handling
    if (lower.includes("date") || lower.includes("year") || lower.includes("month") || lower.endsWith("edat")) {
      if (typeof value === "string" && value.trim()) {
        normalizedValues[field] = moment(value);
      } else if (moment.isMoment(value)) {
        normalizedValues[field] = value;
      } else {
        normalizedValues[field] = undefined;
      }
    }
    // Number fields – ensure number type if needed (Selects with number IDs need this)
    else if (/id$/i.test(lower) && lookupData[field]) {
      normalizedValues[field] = Number(value); // Critical for Select with numeric IDs
    }
    // Boolean fields
    else if (/is|active|enabled/i.test(lower)) {
      normalizedValues[field] = Boolean(value);
    }
    // Everything else
    else {
      normalizedValues[field] = value;
    }
  });

  console.log(`effectiveDetailConfig.  with isMaster`);
  console.log(JSON.stringify(isMaster));
  console.log(JSON.stringify(effectiveDetailConfig));
  // 3. Handle master-detail line items
  if (isMaster && effectiveDetailConfig) {
    try {
      const lines = await fetchLineItems(record[fields[0]]);
      const normalizedLines = (Array.isArray(lines) ? lines : []).map((line: any) => {
        const normalizedLine: any = {};
        effectiveDetailConfig.fields.forEach((f) => {
          let val = line[f];
          if (val !== null && val !== undefined) {
            if (f.toLowerCase().endsWith("id") && typeof val === "string") {
              normalizedLine[f] = Number(val);
            } else if (/date|year|month|edat/i.test(f) && typeof val === "string") {
              normalizedLine[f] = moment(val);
            } else {
              normalizedLine[f] = val;
            }
          }
        });
        return normalizedLine;
      });
      normalizedValues.lineItems = normalizedLines;
    } catch (err) {
      console.error("Failed to load line items", err);
      normalizedValues.lineItems = [];
    }
  }
  // 4. Small delay to ensure Form.List is ready (AntD quirk)
  setTimeout(() => {
    form.setFieldsValue(normalizedValues);
  }, 0);
  // 5. Set editing state
  setEditingItem(record);
  setModalVisible(true);
};
useEffect(() => {
  console.log("Current editingItem:", editingItem ? JSON.stringify(editingItem) : null);
}, [editingItem]);
// const handleEdit = (record: any) => {
// setEditingItem(record);
// setModalVisible(true);
// // Populate form fields
// form.setFieldsValue({
// ...record, // master fields
// lineItems: record.lineItems || [], // ensure line items exist
// });
// };
  const calculateTotals = useCallback(() => {
    const lines: any[] = form.getFieldValue("lineItems") || [];
    let subtotal = 0;
    lines.forEach((line: any, index: number) => {
      const qty = Number(line[qtyField] || 0);
      const price = Number(line[priceField] || 0);
      const lineTotal = qty * price;
      subtotal += lineTotal;
      if (lineTotalField) {
        form.setFieldValue(["lineItems", index, lineTotalField], lineTotal);
      }
    });
    let tax = 0;
    if (taxField) {
      tax = lines.reduce((sum: number, line: any) => {
        const lineSub = Number(line[qtyField] || 0) * Number(line[priceField] || 0);
        return sum + lineSub * (Number(line[taxField] || 0) / 100);
      }, 0);
    }
    const grandTotal = subtotal + tax;
    form.setFieldsValue({
      subtotal,
      taxAmount: tax,
      grandTotal,
    });
    // Check for exceeding limits
    let newWarning = "";
    const currentValues = form.getFieldsValue(true);
    const possibleLimitFields = ["totalCredit", "totalDebit", "totalAmount", "budget", "maxAmount"];
    const limitField = possibleLimitFields.find((lf) => fields.includes(lf));
    if (limitField) {
      const limit = Number(currentValues[limitField] || 0);
      if (grandTotal > limit) {
        newWarning = `Warning: Grand total (${grandTotal.toLocaleString()}) exceeds ${limitField} (${limit.toLocaleString()})`;
      }
    }
    setWarning(newWarning);
  }, [form, qtyField, priceField, lineTotalField, taxField, fields]);
  const calculateLineTotals = useCallback(() => {
    const lines: any[] = lineForm.getFieldValue("lineItems") || [];
    let subtotal = 0;
    let tax = 0;
    lines.forEach((line: any) => {
      const qty = Number(line[qtyField] || 0);
      const price = Number(line[priceField] || 0);
      const lineTotal = qty * price;
      subtotal += lineTotal;
      if (taxField) {
        tax += lineTotal * (Number(line[taxField] || 0) / 100);
      }
    });
    const grandTotal = subtotal + tax;
    // Check for exceeding limits
    let newWarning = "";
    const possibleLimitFields = ["totalCredit", "totalDebit", "totalAmount", "budget", "maxAmount"];
    const limitField = possibleLimitFields.find((lf) => fields.includes(lf));
    if (limitField && currentMaster) {
      const limit = Number(currentMaster[limitField] || 0);
      if (grandTotal > limit) {
        newWarning = `Warning: Grand total (${grandTotal.toLocaleString()}) exceeds ${limitField} (${limit.toLocaleString()})`;
      }
    }
    setLineWarning(newWarning);
    return { subtotal, tax, grandTotal };
  }, [lineForm, qtyField, priceField, taxField, fields, currentMaster]);
  // Trigger recalculation on form changes
  const handleValuesChange = useCallback(() => {
    if (isMaster) {
      calculateTotals();
    }
  }, [isMaster, calculateTotals]);
  const handleLineValuesChange = useCallback(() => {
    if (isMaster) {
      calculateLineTotals();
    }
  }, [isMaster, calculateLineTotals]);
  // ==================== Save Logic ====================
  const handleSave_older = async (values: Record<string, any>) => {
    fields.forEach((f) => {
      if (values[f] && moment.isMoment(values[f])) values[f] = values[f].format("YYYY-MM-DD");
      if (!editingItem && f.toLowerCase().includes("by")) values[f] = loggedInUserId;
      if (!editingItem && f.toLowerCase().includes("number")) values[f] = generateNumberField(f);
    });
    let url = `${apiBaseUrl}/${resourceName}`;
    let method = "POST";
    let payload: any = { ...values };
    if (editingItem) {
      method = "PUT";
      const pk = editingItem[fields[0]];
      url = `${apiBaseUrl}/${resourceName}/${pk}`;
    }
if ((method === "POST") || (method === "PUT")) {
  const primaryKeyField = fields[0];
  if (primaryKeyField?.toLowerCase().endsWith("id")) {
    delete payload[primaryKeyField];
  }
}
   
    if (isMaster) {
      const lineItemsValue = form.getFieldValue("lineItems") || [];
     // payload = { ...values, [effectiveDetailConfig!.resourceName]: lineItemsValue };
      payload = {
  ...values,
  lineItems: lineItemsValue, // 🔥 ONLY THIS
};

      url = `${apiBaseUrl}/${resourceName}/${editingItem ? `${editingItem[fields[0]]}` : ""}`;
    }

const { lineItems, ...payloadWithoutLineItems } = payload;

console.log(JSON.stringify(payload));
    try {
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payloadWithoutLineItems),
      });
      if (!res.ok) throw new Error(await res.text() || "Save failed");
      message.success("Saved successfully");
      closeModal();
      fetchData();
    } catch (err: any) {
      if (isMaster && err.message.includes("404")) {
        await handleSaveFallback(values);
      } else {
        message.error(err.message || "Save failed");
      }
    }
  };
  const handleSave = async (values: Record<string, any>) => {
  // Normalize dates and auto-fill fields
  fields.forEach((f) => {
    if (values[f] && moment.isMoment(values[f])) {
      values[f] = values[f].format("YYYY-MM-DD");
    }
    if (!editingItem && f.toLowerCase().includes("by")) {
      values[f] = loggedInUserId;
    }
    if (!editingItem && f.toLowerCase().includes("number")) {
      values[f] = generateNumberField(f);
    }
  });

  let savedHeader = editingItem ? { ...editingItem } : null;
  let parentId = editingItem ? editingItem[fields[0]] : null;
      console.log(`This is the point of 729`);
   console.log(JSON.stringify(editingItem));
   console.log(JSON.stringify(savedHeader));
   console.log(JSON.stringify(parentId));
  try {
    // Step 1: Save header
    let url = `${apiBaseUrl}/${resourceName}`;
    let method = "POST";
    if (editingItem) {
      method = "PUT";
      url = `${apiBaseUrl}/${resourceName}/${parentId}`;
    }

    const headerPayload = { ...values };
    delete headerPayload.lineItems; // never send lineItems to header endpoint

    const headerRes = await fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(headerPayload),
    });

    if (!headerRes.ok) {
      throw new Error(await headerRes.text().catch(() => "Save failed"));
    }
    console.log(`This is the point of 751`);
  console.log(JSON.stringify(headerRes));
    console.log(JSON.stringify(editingItem));
    if (!editingItem) {
      savedHeader = await headerRes.json();
      parentId = savedHeader[fields[0]];
    }

    message.success("Header saved");
     console.log(`${isMaster}`);
       console.log(`${effectiveDetailConfig}`);
   console.log(`${parentId}`);
    // Step 2: Save line items (only if master-detail)
    if (isMaster && effectiveDetailConfig) {
      const lines = form.getFieldValue("lineItems") || [];

      // Optional: delete old lines on edit
      if (editingItem) {
        await fetch(
          `${apiBaseUrl}/${effectiveDetailConfig.resourceName}/${parentId}`,  //${effectiveDetailConfig.foreignKey}
          { method: "DELETE" }
        ).catch(() => {});
      }

      // Save each line
      for (const line of lines) {
        const linePayload = {
          ...line,
          [effectiveDetailConfig.foreignKey]: parentId,
        };

        // Normalize dates in lines
        effectiveDetailConfig.fields.forEach((f) => {
          if (linePayload[f] && moment.isMoment(linePayload[f])) {
            linePayload[f] = linePayload[f].format("YYYY-MM-DD");
          }
        });
         console.log(`791:`);
   console.log(`${apiBaseUrl}/${effectiveDetailConfig.resourceName}`);
   console.log(JSON.stringify(linePayload));
        const lineRes = await fetch(
          `${apiBaseUrl}/${effectiveDetailConfig.resourceName}`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(linePayload),
          }
        );

        if (!lineRes.ok) {
          console.error("Failed to save line item", linePayload);
        }
      }

      message.success("Line items saved");
    }

    closeModal();
    fetchData();
  } catch (err: any) {
    message.error(err.message || "Save failed");
  }
};
  const handleSaveFallback = async (headerValues: any) => {
    try {
      const headerUrl = `${apiBaseUrl}/${resourceName}${editingItem ? `/${editingItem[fields[0]]}` : ""}`;
      const headerRes = await fetch(headerUrl, {
        method: editingItem ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(headerValues),
      });
      if (!headerRes.ok) throw new Error("Header save failed");
      const savedHeader = editingItem ? editingItem : await headerRes.json();
      const parentId = savedHeader[fields[0]];
      const lines = form.getFieldValue("lineItems") || [];
      if (editingItem) {
        await fetch(`${apiBaseUrl}/${effectiveDetailConfig!.resourceName}/by-${effectiveDetailConfig!.foreignKey}/${parentId}`, {
          method: "DELETE",
        }).catch(() => {});
      }
      for (const line of lines) {
        const linePayload = { ...line, [effectiveDetailConfig!.foreignKey]: parentId };
        await fetch(`${apiBaseUrl}/${effectiveDetailConfig!.resourceName}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(linePayload),
        });
      }
      message.success("Saved successfully (fallback)");
      closeModal();
      fetchData();
    } catch (err) {
      message.error("Fallback save failed" + err);
    }
  };
  const handleDelete = async (record: Record<string, any>) => {
    const rowKey = getRowKey(record);
    try {
      const res = await fetch(`${apiBaseUrl}/${resourceName}/${rowKey}`, { method: "DELETE" });
      if (!res.ok) throw new Error("delete failed");
      message.success("Deleted successfully");
    } catch (err) {
      message.error("Delete failed" + err);
    } finally {
      fetchData();
    }
  };
  const closeModal = () => {
    setModalVisible(false);
    setEditingItem(null);
    form.resetFields();
    setExpandedRowKeys([]); // optional
    setWarning("");
  };
  const getRowKey = (record: Record<string, any>) => {
    const idField = fields.find((f) => f.toLowerCase().endsWith("id"));
    return idField && record[idField] !== undefined ? String(record[idField]) : JSON.stringify(record);
  };
  // ==================== Manage Lines ====================
  const handleManageLines = async (record: Record<string, any>) => {
    setCurrentMaster(record);
    setLoading(true);
    try {
      const lines = await fetchLineItems(record[fields[0]]);
      const normalizedLines = lines.map((line: any) => {
        const normalizedLine: any = {};
        effectiveDetailConfig!.fields.forEach((f) => {
          let val = line[f];
          if (val !== null && val !== undefined) {
            if (f.toLowerCase().endsWith("id") && typeof val === "string") {
              normalizedLine[f] = Number(val);
            } else if (/date|year|month|edat/i.test(f) && typeof val === "string") {
              normalizedLine[f] = moment(val);
            } else {
              normalizedLine[f] = val;
            }
          }
        });
        return normalizedLine;
      });
      lineForm.setFieldsValue({ lineItems: normalizedLines });
    } catch (err) {
      console.error("Failed to load line items", err);
      lineForm.setFieldsValue({ lineItems: [] });
    }
    setLoading(false);
    setLineModalVisible(true);
  };
  const handleSaveLines = async () => {
    try {
      const values = await lineForm.validateFields();
      let lines = values.lineItems;
      // Normalize dates
      lines = lines.map((line: any) => {
        const norm = { ...line };
        Object.keys(norm).forEach((k) => {
          if (moment.isMoment(norm[k])) norm[k] = norm[k].format("YYYY-MM-DD");
        });
        return norm;
      });
      const parentId = currentMaster![fields[0]];
      // Delete existing lines
      await fetch(`${apiBaseUrl}/${effectiveDetailConfig!.resourceName}/${effectiveDetailConfig!.foreignKey}/${parentId}`, {
        method: "DELETE",
      }).catch(() => {});
      // Post new lines
  
      for (const line of lines) {
        const payload = { ...line, [effectiveDetailConfig!.foreignKey]: parentId };
            console.log(`This is the payload link: ${apiBaseUrl}/${effectiveDetailConfig!.resourceName}`);
            console.log(`This is the payload:  ${payload}`);
        await fetch(`${apiBaseUrl}/${effectiveDetailConfig!.resourceName}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
      }
      // Calculate totals
      const { subtotal, tax: taxAmount, grandTotal } = calculateLineTotals();
      // Update master totals if fields exist
      const masterUpdate: Record<string, any> = {};
      if (fields.includes("subtotal")) masterUpdate.subtotal = subtotal;
      if (fields.includes("taxAmount")) masterUpdate.taxAmount = taxAmount;
      if (fields.includes("grandTotal")) masterUpdate.grandTotal = grandTotal;
      if (Object.keys(masterUpdate).length > 0) {
        //const masterPayload = { ...currentMaster, ...masterUpdate };
        const masterPayload = {
  ...stripLineItems(currentMaster),
  ...masterUpdate,
};
        const masterUrl = `${apiBaseUrl}/${resourceName}/${parentId}`;
        await fetch(masterUrl, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(masterPayload),
        });
      }
      message.success("Line items saved successfully");
      setLineModalVisible(false);
      lineForm.resetFields();
      setCurrentMaster(null);
      setLineWarning("");
      fetchData();
    } catch (err) {
      message.error("Failed to save line items" + err);
    }
  };
  // ==================== + Add Lookup Item ====================
  const openAddLookup = (field: string) => {
   setLookupModalField(field);
  
    setLookupModalVisible(true); //alert("Saveing");
  };
  const handleAddNewLookup = async () => {
    if (!lookupModalField) return;
   
    try {
      const values = await lookupForm.validateFields();
      const endpoint = lookupEndpointFromField(lookupModalField);
      const res = await fetch(`${apiBaseUrl}/${endpoint}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(values),
      });
      if (!res.ok) throw new Error("create lookup failed");
      message.success("Added successfully");
      setLookupModalVisible(false);
      lookupForm.resetFields();
      await fetchLookups();
    } catch (err) {
      message.error("Failed to add lookup item" + err);
    }
  };
  // ==================== Render Form Items ====================
  const renderFormItemComponent = (f: string, _isLineItem = false) => {
    const lower = f.toLowerCase();
    const isExcluded = excludedLookupFields.some((ex) => lower === ex || lower.endsWith(ex));
    const isByField = lower.endsWith("by") || lower.endsWith("edby");
    const isLookup = (lower.endsWith("id") || lower.endsWith("currency") || lower.endsWith("company") || lower.endsWith("accounttype") || lower.endsWith("status") || lower.endsWith("entitytype")) && !isExcluded && !isByField;
    const isBoolean = /is|active|enabled/i.test(f);
   // const isDate = /date/i.test(f);
    const isDate =
  lower.includes("date") ||
  lower.endsWith("edat");
    const isYear = /year/i.test(f);
    const isMonth = /month/i.test(f);
    const isNumber = /amount|price|total|qty|quantity|rate|balance/i.test(f);
    if (isLookup) {
      const options = lookupData[f]?.map((i) => ({ label: i.label, value: i.id })) || [];
      return (
        <Select
          options={options}
          showSearch
          optionFilterProp="label"
          allowClear
          placeholder={`Select ${f}`}
        />
      );
    }
    if (isByField && lookupData[f]) {
      const options = lookupData[f]?.map((i) => ({ label: i.label, value: i.id })) || [];
      return <Select options={options} disabled />;
    }
    if (isBoolean) return <Checkbox />;
    if (isDate) return <DatePicker style={{ width: "100%" }} />;
    if (isYear) return <DatePicker picker="year" style={{ width: "100%" }} />;
    if (isMonth) return <DatePicker picker="month" style={{ width: "100%" }} />;
    if (isNumber) {
      return (
        <InputNumber
          style={{ width: "100%" }}
          formatter={(value) => `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ",")}
          parser={(value) => value?.replace(/,/g, "") || ""}
        />
      );
    }
   // return <Input placeholder={`Enter ${f}`} />;
    return <Input id={f} placeholder={`Enter ${f}`} />;
  };
  const renderFormItem = (f: string, idx: number, _isLineItem = false) => {
    if (!editingItem && idx === 0 && !_isLineItem) return null;
    if (editingItem && idx === 0 && !_isLineItem) {
      return (
        <Form.Item key={f} label={f} name={f}>
          <Input disabled />
        </Form.Item>
      );
    }
    const lower = f.toLowerCase();
    const isLookup = (lower.endsWith("id") || lower.endsWith("currency") || lower.endsWith("company") || lower.endsWith("accounttype")|| lower.endsWith("status")|| lower.endsWith("entitytype")) && !excludedLookupFields.some(ex => lower === ex || lower.endsWith(ex)) && !lower.endsWith("by") && !lower.endsWith("edby");
    // const label = isLookup && !isLineItem ? (
    // <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
    // <span>{f}</span>
    // <Button size="small" onClick={() => openAddLookup(f)} style={{ marginLeft: 8 }}>
    // + Add
    // </Button>
    // </div>
    // ) : f;
    const label = isLookup && !_isLineItem ? (
  <div
    style={{
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      gap: 8,
    }}
  >
    <span>{f}</span>
    <Button id={f} name={f}
      size="small"
      htmlType="button"
    onClick={() => openAddLookup(f)}
    >
      + Add
    </Button>
  </div>
) : f;
    if (_isLineItem) {
      return renderFormItemComponent(f, true);
    }
    if (lower.includes("number") && !editingItem) {
      return (
        <Form.Item key={f} label={f}>
      {/* <Input.Group compact> */}
    <Form.Item name={f} noStyle>
      <Input
        style={{ width: "calc(100% - 110px)" }}
        placeholder={`Enter ${f}`}
      />
    </Form.Item>
    <Button
      type="default"
      style={{ width: 110 }}
      onClick={() => {
        const prefix = (f.match(/[A-Z]/g) || []).join("") || "XX";
        const dateStr = moment().format("YYYYMMDD");
        const rand10 = Math.floor(Math.random() * 1_000_000_0000)
          .toString()
          .padStart(10, "0");
        form.setFieldValue(f, `${prefix}${dateStr}${rand10}`);
      }}
    >
      Regenerate
    </Button>
  {/* </Input.Group> */}
</Form.Item>
      );
    }
 // Default case: normal form item
  return (
    <Form.Item key={f} label={label} name={f}>
      {renderFormItemComponent(f, _isLineItem)}
    </Form.Item>
  );
    // return (
    // <Form.Item key={f} label={f} name={f}>
    // <div style={{ display: "flex", gap: 8 }}>
    // <div style={{ flex: 1 }}>
    // {renderFormItemComponent(f)}
    // </div>
    // {/* {isLookup && !isLineItem && (
    // <Button
    // size="small"
    // htmlType="button"
    // onClick={() => openAddLookup(f)}
    // >
    // + Add
    // </Button>
    // )} */}
    // </div>
    // </Form.Item>
    // );
  };
  // ==================== Table Columns ====================
  const handleTableChange = (_pagination: any, _filters: any, sorter: any) => {
    setSortedInfo(sorter);
  };
  const columns: ColumnsType<Record<string, any>> = [
    {
      title: "Actions",
      key: "actions",
      fixed: "left",
      width: 140,
      render: (_: any, record: any) => (
        <Space>
          <Button type="link" onClick={() => handleEdit(record)}>
            Edit
          </Button>

    {isMaster && (
      <Button
        type="link"
        onClick={() => {
          handleEdit(record);
          setTimeout(() => {
            document.getElementById("line-items-anchor")?.scrollIntoView({
              behavior: "smooth",
            });
          }, 300);
        }}
      >
        Line Items
      </Button>
    )}
          {isMaster && (
            <Button type="link" onClick={() => handleManageLines(record)}>
              Lines
            </Button>
          )}
          <Button type="link" danger onClick={() => handleDelete(record)}>
            Delete
          </Button>
        </Space>
      ),
    },
    ...fields
      .slice(0, showAllFields ? fields.length : 6)
      .map((f) => {
        const isNumberField = /amount|price|total|qty|quantity|rate|balance|number/i.test(f.toLowerCase());
        const isDateField = /date|year|month|edat/i.test(f.toLowerCase());
        return {
          title: f,
          dataIndex: f,
          key: f,
          align: isNumberField ? ("right" as const) : ("left" as const),
          sorter: isDateField
            ? (a: any, b: any) => {
                const dateA = a[f] ? new Date(a[f]).getTime() : 0;
                const dateB = b[f] ? new Date(b[f]).getTime() : 0;
                return dateA - dateB;
              }
            : isNumberField
            ? (a: any, b: any) => (a[f] || 0) - (b[f] || 0)
            : (a: any, b: any) =>
                String(a[f] || "").localeCompare(String(b[f] || "")),
          sortOrder: sortedInfo.columnKey === f ? sortedInfo.order : undefined,
          ...getColumnSearchProps(f),
          render: (value: any) => {
            if (f.toLowerCase().endsWith("id") && lookupData[f]?.length) {
              const item = lookupData[f].find((i) => Number(i.id) === Number(value));
              return item ? item.label : value;
            }
            if (isNumberField && (typeof value === "number" || !isNaN(Number(value)))) {
              return <div style={{ textAlign: "right" }}>{Number(value).toLocaleString("en-US")}</div>;
            }
            if (isDateField && value) {
              return moment(value).format(f.toLowerCase().includes("year") ? "YYYY" : "YYYY-MM-DD");
            }
            return value?.toString() || "-";
          },
        };
      }),
  ];
  const filteredData = data.filter((item) =>
    fields.some((field) => {
      const value = item[field];
      return value != null && String(value).toLowerCase().includes(globalSearch.toLowerCase());
    })
  );
  // ==================== Expandable Row for Line Items ====================
  const handleExpand = async (expanded: boolean, record: Record<string, any>) => {
    if (!isMaster || !effectiveDetailConfig) return;
    const key = getRowKey(record);
    if (expanded && !expandedLines[key]) {
      const lines = await fetchLineItems(record[fields[0]]);
      setExpandedLines((prev) => ({ ...prev, [key]: lines }));
    }
    setExpandedRowKeys(expanded ? [key] : []);
  };
  const expandedRowRender = (record: Record<string, any>) => {
    const key = getRowKey(record);
    const lines = expandedLines[key] || [];
    if (lines.length === 0) return <Text type="secondary">No line items</Text>;
    return (
      <Table
        dataSource={lines}
        columns={effectiveDetailConfig!.fields.map((f) => ({
          title: f,
          dataIndex: f,
          key: f,
          render: (val: any) => {
            if (f.toLowerCase().endsWith("id") && lookupData[f]?.length) {
              const item = lookupData[f].find((i) => i.id === val);
              return item ? item.label : val;
            }
            const isNumber = /amount|price|total|qty|quantity|rate|balance/i.test(f.toLowerCase());
            if (isNumber && val != null) {
              return <div style={{ textAlign: "right" }}>{Number(val).toLocaleString()}</div>;
            }
            return val ?? "-";
          },
        }))}
        pagination={false}
        size="small"
      expandable={
    isMaster
      ? {
          expandedRowKeys,
          onExpand: handleExpand,
          expandedRowRender,
        }
      : undefined
  }
      />
    );
  };
  // ==================== JSX ====================
  return (
    <div style={{ padding: 20 }}>
      <Row style={{ marginBottom: 16 }} gutter={8} justify="space-between">
        <Col>
          <Button type="primary" onClick={() => {
            setEditingItem(editingItem);
            form.resetFields();
            setModalVisible(true);
          }}>
            Add {resourceName}
          </Button>
        </Col>
        <Col flex="auto" style={{ textAlign: 'right' }}>
          <Input
            placeholder="Search all records..."
            prefix={<SearchOutlined />}
            allowClear
            value={globalSearch}
            onChange={(e) => setGlobalSearch(e.target.value)}
            style={{ width: 300 }}
          />
        </Col>
        <Col>
          <Button onClick={() => setShowAllFields((p) => !p)}>{showAllFields ? "Show Less" : "Show More Fields"}</Button>
        </Col>
        <Col>
          <input type="color" value={rowColor} onChange={(e) => setRowColor(e.target.value)} title="Select Row Color" style={{ width: 40, height: 32, border: "none" }} />
        </Col>
      </Row>
      {isReport ? (
        <></> // omitted for brevity, same as before
      ) : (
        <Table
          dataSource={globalSearch ? filteredData : data}
          columns={columns}
          rowKey={getRowKey}
          loading={loading}
          scroll={{ x: "max-content" }}
          onChange={handleTableChange}
          rowClassName={(_record, index) => (index % 2 === 0 ? "even-row" : "odd-row")}
          style={{ ["--row-bg-even" as any]: rowColor, ["--row-bg-odd" as any]: shadeColor(rowColor, -0.05) } as any}
          locale={{ emptyText: `No ${resourceName} found` }}
          expandable={isMaster ? {
            expandedRowKeys,
            onExpand: handleExpand,
            expandedRowRender,
          } : undefined}
          onRow={(record) => ({ onDoubleClick: () => handleEdit(record) })}
        />
      )}
<Modal
  title={editingItem ? `Edit ${resourceName}` : `Add ${resourceName}`}
  open={modalVisible}
  width={1300}
  onCancel={closeModal}
  onOk={() => form.submit()}
 
  destroyOnClose={true} // updated per antd v5
>
  <Form
    form={form}
    onFinish={handleSave}
    layout="vertical"
  
    onValuesChange={handleValuesChange}
  >
    <Row gutter={16}>
      {fields.map((f, idx) => (
        <Col span={8} key={f}>
          {renderFormItem(f, idx)}
        </Col>
      ))}
    </Row>
    {isMaster && effectiveDetailConfig && (
      <>
        <Divider orientation="left">Line Items (Detailed View)</Divider>
      
        <Form.List name="lineItems">
          {(lineFields, { add, remove }) => (
            <>
              <Table
                dataSource={lineFields} // directly use Form.List fields
                pagination={false}
                size="small"
                rowKey={(field) => field.key} // each field has a unique key
                columns={[
                  ...effectiveDetailConfig.fields.map((f) => ({
                    title: f,
                    width: 200,
                    render: (_: any, __: any, index: number) => {
                      const field = lineFields[index];
                      return (
                        <Form.Item
                          name={[field.name, f]} // use Form.List name
                         fieldKey={[String(field.fieldKey ?? ""), String(f ?? "")]} //fieldKey={[field.fieldKey, f]} // use Form.List fieldKey
                          noStyle
                        >
                          {renderFormItemComponent(f, true)}
                        </Form.Item>
                      );
                    },
                  })),
                  {
                    title: "Action",
                    width: 100,
                    render: (_: any, __: any, index: number) => (
                      <Button
                        danger
                        size="small"
                        onClick={() => remove(index)}
                      >
                        Delete
                      </Button>
                    ),
                  },
                ]}
              />
              <Button
                type="dashed"
                onClick={() => add({ [qtyField]: 1, [priceField]: 0 })}
                block
                icon={<PlusOutlined />}
                style={{ marginTop: 16 }}
              >
                Add Line Item
              </Button>
            </>
          )}
        </Form.List>
        {warning && <Alert message={warning} type="warning" showIcon style={{ marginTop: 16 }} />}
      </>
    )}
  </Form>
</Modal>
      {/* Line Items Modal */}
      <Modal
        title={`Manage Line Items for ${resourceName} #${currentMaster ? currentMaster[fields.find((f) => f.toLowerCase().includes("number")) || fields[0]] : ""}`}
        open={lineModalVisible}
        width={1300}
        onCancel={() => {
          setLineModalVisible(false);
          lineForm.resetFields();
          setCurrentMaster(null);
          setLineWarning("");
        }}
        onOk={() => lineForm.submit()}
        destroyOnHidden
      >
        <Form form={lineForm} onFinish={handleSaveLines} layout="vertical" onValuesChange={handleLineValuesChange}>
          <Form.List name="lineItems">
            {(lineFields, { add, remove }) => (
              <>
                <Table
                  dataSource={lineFields}
                  pagination={false}
                  size="small"
                  rowKey={(field) => field.key}
                  columns={[
                    ...effectiveDetailConfig!.fields.map((f) => ({
                      title: f,
                      width: 200,
                      render: (_: any, __: any, index: number) => (
                        <Form.Item name={[lineFields[index].name, f]} noStyle>
                          {renderFormItemComponent(f, true)}
                        </Form.Item>
                      ),
                    })),
                    {
                      title: "Action",
                      width: 100,
                      render: (_: any, __: any, index: number) => (
                        <Button danger size="small" onClick={() => remove(index)}>
                          Delete
                        </Button>
                      ),
                    },
                  ]}
                />
                <Button
                  type="dashed"
                  onClick={() => add({ [qtyField]: 1, [priceField]: 0 })}
                  block
                  icon={<PlusOutlined />}
                  style={{ marginTop: 16 }}
                >
                  Add Line Item
                </Button>
              </>
            )}
          </Form.List>
          {lineWarning && <Alert message={lineWarning} type="warning" showIcon style={{ marginTop: 16 }} />}
        </Form>
      </Modal>
      {/* Lookup Modal - simplified for brevity, same as before but using values directly
 
<Modal
  title={lookupModalField ? `Add New ${lookupModalField}` : "Add New"}
  open={lookupModalVisible}
  width={900}
  destroyOnHidden
  onCancel={() => {
    setLookupModalVisible(false);
    lookupForm.resetFields();
    setLookupModalField(null);
  }}
  onOk={() => lookupForm.submit()} // submit lookup form
>
  <Form
    form={lookupForm}
    layout="vertical"
    onFinish={handleAddNewLookup}
  >
    <Row gutter={16}>
      {lookupModalField &&
        (fieldsForLookup[lookupModalField] || []).map((f: string) => (
          <Col span={8} key={f}>
            <Form.Item
              label={f}
              name={f}
              rules={[{ required: true }]}
            >
              {renderFormItemComponent(f)}
            </Form.Item>
          </Col>
        ))}
    </Row>
  </Form>
</Modal>*/}
<Modal
  title={`Add New ${lookupModalField}`}
  open={lookupModalVisible}
  width={900}
  onCancel={() => {
    setLookupModalVisible(false);
    lookupForm.resetFields();
    setLookupModalField(null);
  }}
  onOk={() => lookupForm.submit()}
  destroyOnClose
>
  <Form
    form={lookupForm}
    layout="vertical"
    onFinish={handleAddNewLookup}
  >
    <Row gutter={16}>
      {lookupModalField &&
        (fieldsForLookup[lookupModalField] || [])
          .filter((field: string, index: number, array: string[]) => {
            // If there are no fields, don't filter
            if (array.length === 0) return true;
            const lowerField = field.toLowerCase();
            const isFirstField = index === 0;
            // Derive expected table name from the lookup field (e.g., "CustomerId" → "customer")
            const lookupFieldLower = lookupModalField!.toLowerCase();
            let expectedTableName = lookupEndpointFromField(lookupModalField!); // e.g., "customers"
           
            // Fallback: extract from field name (remove "Id" and pluralize rules)
            if (lookupFieldLower.endsWith("id")) {
              let base = lookupModalField!.slice(0, -2); // remove "Id"
              // Simple plural to singular guess
              if (base.endsWith("ies")) base = base.slice(0, -3) + "y";
              else if (base.endsWith("s")) base = base.slice(0, -1);
              expectedTableName = base.toLowerCase();
            }
            const expectedPkPattern = new RegExp(`^${expectedTableName}id$`, "i");
            // Hide only if:
            // - It's the first field AND
            // - Its name matches the expected primary key pattern (e.g., CustomerId for customers)
            const isPrimaryKey = isFirstField && expectedPkPattern.test(field);
            return !isPrimaryKey;
          })
          .map((field: string) => (
            <Col span={8} key={field}>
              <Form.Item
                label={field}
                name={field}
                rules={[
                  {
                    required: /name|code|title|description|label/i.test(field),
                    message: `${field} is required`,
                  },
                ]}
              >
                {renderFormItemComponent(field)}
              </Form.Item>
            </Col>
          ))}
    </Row>
  </Form>
</Modal>
      <style>{`
        .even-row { background-color: var(--row-bg-even, #ffffff); }
        .odd-row { background-color: var(--row-bg-odd, #f9f9f9); }
      `}</style>
    </div>
  );
};
export default GenericResourcePage;

// import React, { useEffect, useRef, useState, useCallback } from "react";
              // import {
              //   Table,
              //   Button,
              //   Modal,
              //   Form,
              //   Input,
              //   Select,
              //   Space,
              //   message,
              //   Checkbox,
              //   Row,
              //   Col,
              //   DatePicker,
              //   InputNumber,
              //   InputRef,
              //   Typography,
              //   Divider,
              // } from "antd";
              // import { SearchOutlined, PlusOutlined } from "@ant-design/icons";
              // import type { FilterConfirmProps } from "antd/es/table/interface";
              // import { ColumnsType } from "antd/es/table";
              // import moment from "moment";
              // import Highlighter from "react-highlight-words";

              // const { Text } = Typography;

              // interface LookupItem {
              //   id: string | number;
              //   label: string;
              //   [k: string]: any;
              // }

              // // interface DetailConfig {
              // //   resourceName: string;
              // //   foreignKey: string;
              // //   fields: string[];
              // //   quantityField?: string;
              // //   priceField?: string;
              // //   lineTotalField?: string;
              // //   taxField?: string;
              // // }
              // interface DetailConfig {
              //   resourceName: string;      // Line item API/table
              //   foreignKey: string;        // e.g. InvoiceId
              //   fields: string[];          // Columns in line items table
              //   quantityField?: string;
              //   priceField?: string;
              //   lineTotalField?: string;
              //   taxField?: string;
              // }
              // interface Props {
              //   resourceName: string;
              //   apiBaseUrl?: string;
              //   fields: string[];
              //   detailConfig?: DetailConfig;
              // }

              // export const GenericResourcePage: React.FC<Props> = ({
              //   resourceName,
              //   apiBaseUrl = "",
              //   fields,
              //   detailConfig,
              // }) => {
              //   const [data, setData] = useState<Record<string, any>[]>([]);
              //   const [loading, setLoading] = useState(false);
              //   const [modalVisible, setModalVisible] = useState(false);
              //   const [editingItem, setEditingItem] = useState<Record<string, any> | null>(null);
              //   const [lookupData, setLookupData] = useState<Record<string, LookupItem[]>>({});
              //   const [fieldsForLookup, setFieldsForLookup] = useState<Record<string, string[]>>({});
              //   const [form] = Form.useForm();
              //   const [showAllFields, setShowAllFields] = useState(false);
              //   const [rowColor, setRowColor] = useState("#ffffff");
              //   const [globalSearch, setGlobalSearch] = useState("");
              //   const [searchText, setSearchText] = useState("");
              //   const [searchedColumn, setSearchedColumn] = useState("");
              //   const [sortedInfo, setSortedInfo] = useState<{ columnKey?: string; order?: "ascend" | "descend" }>({});
              //   const searchInput = useRef<InputRef>(null);
              //   const loggedInUserId = Number(localStorage.getItem("userid") || 0);

              //   const [lookupModalVisible, setLookupModalVisible] = useState(false);
              //   const [lookupModalField, setLookupModalField] = useState<string | null>(null);
              //   const [lookupForm] = Form.useForm();

              //   const isReport = resourceName.toLowerCase().includes("report");
              //   const [reportParams, setReportParams] = useState<Record<string, any>>({});
              //   const [reportData, setReportData] = useState<any[]>([]);

              //   //const isMaster = !!detailConfig;
              // const isMaster = Boolean(detailConfig);
              //   const qtyField = detailConfig?.quantityField || "quantity";
              //   const priceField = detailConfig?.priceField || "price";
              //   const lineTotalField = detailConfig?.lineTotalField || "lineTotal";
              //   const taxField = detailConfig?.taxField;

              //   const [excludedLookupFields, setExcludedLookupFields] = useState<string[]>([]);

              //   // For lazy-loaded expandable line items
              //   const [expandedRowKeys, setExpandedRowKeys] = useState<string[]>([]);
              //   const [expandedLines, setExpandedLines] = useState<Record<string, any[]>>({});

              //   // ==================== Helpers ====================
              //   const handleSearch = (
              //     selectedKeys: string[],
              //     confirm: (param?: FilterConfirmProps) => void,
              //     dataIndex: string,
              //   ) => {
              //     confirm();
              //     setSearchText(selectedKeys[0]);
              //     setSearchedColumn(dataIndex);
              //   };

              //   const handleReset = (clearFilters: () => void) => {
              //     clearFilters();
              //     setSearchText("");
              //   };

              //   const getColumnSearchProps = (dataIndex: string): any => ({
              //     filterDropdown: ({ setSelectedKeys, selectedKeys, confirm, clearFilters }: any) => (
              //       <div style={{ padding: 8 }} onKeyDown={(e) => e.stopPropagation()}>
              //         <Input
              //           ref={searchInput}
              //           placeholder={`Search ${dataIndex}`}
              //           value={selectedKeys[0]}
              //           onChange={(e) => setSelectedKeys(e.target.value ? [e.target.value] : [])}
              //           onPressEnter={() => handleSearch(selectedKeys as string[], confirm, dataIndex)}
              //           style={{ marginBottom: 8, display: "block" }}
              //         />
              //         <Space>
              //           <Button
              //             type="primary"
              //             onClick={() => handleSearch(selectedKeys as string[], confirm, dataIndex)}
              //             icon={<SearchOutlined />}
              //             size="small"
              //             style={{ width: 90 }}
              //           >
              //             OK
              //           </Button>
              //           <Button onClick={() => clearFilters && handleReset(clearFilters)} size="small" style={{ width: 90 }}>
              //             Reset
              //           </Button>
              //         </Space>
              //       </div>
              //     ),
              //     filterIcon: (filtered: boolean) => <SearchOutlined style={{ color: filtered ? "#1677ff" : undefined }} />,
              //     onFilter: (value: any, record: any) =>
              //       record[dataIndex] ? String(record[dataIndex]).toLowerCase().includes((value as string).toLowerCase()) : false,
              //     onFilterDropdownOpenChange: (visible: boolean) => {
              //       if (visible) {
              //         setTimeout(() => searchInput.current?.select(), 100);
              //       }
              //     },
              //     render: (text: any) =>
              //       searchedColumn === dataIndex ? (
              //         <Highlighter
              //           highlightStyle={{ backgroundColor: "#ffc069", padding: 0 }}
              //           searchWords={[searchText]}
              //           autoEscape
              //           textToHighlight={text ? text.toString() : ""}
              //         />
              //       ) : (
              //         text
              //       ),
              //   });

              //   const shadeColor = (color: string, percent: number) => {
              //     let R = parseInt(color.substring(1, 3), 16);
              //     let G = parseInt(color.substring(3, 5), 16);
              //     let B = parseInt(color.substring(5, 7), 16);
              //     R = Math.min(255, Math.max(0, Math.round(R + R * percent)));
              //     G = Math.min(255, Math.max(0, Math.round(G + G * percent)));
              //     B = Math.min(255, Math.max(0, Math.round(B + B * percent)));
              //     const RR = R.toString(16).padStart(2, "0");
              //     const GG = G.toString(16).padStart(2, "0");
              //     const BB = B.toString(16).padStart(2, "0");
              //     return `#${RR}${GG}${BB}`;
              //   };

              //   const generateNumberField = (fieldName: string) => {
              //     const letters = (fieldName.match(/[A-Z]/g) || []).join("") || "";
              //     const datePart = moment().format("YYYYMMDD");
              //     const randomPart = Math.floor(Math.random() * 1_000_000_0000)
              //       .toString()
              //       .padStart(10, "0");
              //     return `${letters}${datePart}${randomPart}`;
              //   };

              //   // ==================== Data Fetching ====================
              //   const fetchData = async () => {
              //     // alert(`${resourceName}`);
              //    setData([]);
              //     setLoading(true);
              //     try {
              //       const res = await fetch(`${apiBaseUrl}/${resourceName}`);
              //       const json = await res.json();
              //       setData(Array.isArray(json) ? json : []);
              //     //  console.log(data);
              //     } catch (err) {
              //       message.error("Failed to load data" + err);
              //     } finally {
              //       setLoading(false);
              //     }
              //   };

              //   const runReport = async () => {
              //     setLoading(true);
              //     try {
              //       const res = await fetch(`${apiBaseUrl}/procedures/${resourceName}`, {
              //         method: "POST",
              //         headers: { "Content-Type": "application/json" },
              //         body: JSON.stringify(reportParams),
              //       });
              //       const json = await res.json();
              //       setReportData(Array.isArray(json) ? json : []);
              //     } catch (err) {
              //       message.error("Failed to run report");
              //     } finally {
              //       setLoading(false);
              //     }
              //   };

              //   const fetchLineItems = async (parentId: any) => {
              //     if (!detailConfig) return [];
              //     try {
              //       const res = await fetch(`${apiBaseUrl}/${detailConfig.resourceName}?${detailConfig.foreignKey}=${parentId}`);
              //       const json = await res.json();
              //       return Array.isArray(json) ? json : [];
              //     } catch (err) {
              //       message.error("Failed to load line items");
              //       return [];
              //     }
              //   };

              //   const lookupEndpointFromField = (f: string) => {
              //     let endpoint = f.replace(/\s/g, "");
              //     if (endpoint.toLowerCase().endsWith("by")) endpoint = "users";
              //    //  if (endpoint.toLowerCase().endsWith("by")) endpoint = "users";
              //     if (endpoint.toLowerCase().endsWith("accountid")) endpoint = "bankaccountid";
              //      if (endpoint.toLowerCase().endsWith("goodsreceivedid")) endpoint = "goodsreceivedid";
              //     endpoint = endpoint
              //       .replace(/yId$/i, "ies")
              //        .replace(/type$/i, "types")   
              //       .replace(/y$/i, "ies")
              //       .replace(/ssId$/i, "sses")   
              //      // .replace(/erId$/i, "er")
              //       .replace(/edId$/i, "ed")
              //       .replace(/Id$/i, "s");
              //     return endpoint.toLowerCase();
              //   };

              //   // ==================== Fetch Lookups ====================
              //   const fetchLookups = async () => {
              //     const newLookup: Record<string, LookupItem[]> = {};
              //     const newFieldsForLookup: Record<string, string[]> = {};

              //     const allFields = [...fields, ...(detailConfig?.fields || [])];
                
              //     const lookupFields = allFields.filter((f) => {
              //       const lower = f.toLowerCase();

              //       if (excludedLookupFields.length > 0 && excludedLookupFields.some(ex => lower === ex || lower.endsWith(ex))) { 
              //         console.log("Same: "+JSON.stringify(excludedLookupFields) +"  " + lower);
              //         return false;
              //       }

              //       if (
              //         lower.endsWith("id") ||
              //         lower.endsWith("currency") ||
              //         lower.endsWith("company") ||
              //           lower.endsWith("accounttype") || lower.endsWith("entitytype") || lower.endsWith("status") ||
              //         lower.endsWith("edby")
              //       ) {
              //         return true;
              //       }

              //       return false;
              //     });

              //     for (const f of lookupFields) {
              //       let endpointField = f;
              //       if (f.toLowerCase().endsWith("edby") || f.toLowerCase().endsWith("by")) {
              //         endpointField = "users";
              //       }

              //       const endpoint = lookupEndpointFromField(endpointField);

              //       try {
              //         const res = await fetch(`${apiBaseUrl}/${endpoint}`);
              //         if (!res.ok) continue;

              //         const items = await res.json();
              //         if (!Array.isArray(items) || items.length === 0) continue;

              //         const sample = items[0];
              //         const keys = Object.keys(sample);
              //         const labelCandidates = keys.filter((k) => /name|title|code|desc|label/i.test(k));
              //         const labelKeys = labelCandidates.length ? labelCandidates.slice(0, 2) : keys.slice(1, 4);

              //         newLookup[f] = items.map((i: any) => {
              //           const labelParts = labelKeys.map((k) => i[k]).filter(Boolean);
              //           const label = labelParts.length ? labelParts.join(" - ") : String(i.id || i[keys[0]]);
              //           return { id: i.id ?? i[Object.keys(i)[0]], label, ...i };
              //         });

              //         newFieldsForLookup[f] = keys;
              //       } catch (err) {
              //         console.error(`Fetch failed for ${f} → ${endpoint}`, err);
              //       }
              //     }

              //     setLookupData(newLookup);
              //     setFieldsForLookup(newFieldsForLookup);
              //   };

              //   // ==================== Load Excluded Fields ====================
              //   useEffect(() => {
              //     const fetchExcludedLookups = async () => {
              //       try {
              //         const res = await fetch(`${apiBaseUrl}/excludedlookup`);
              //         if (res.ok) {
              //           const json = await res.json();
              //           const names = json.map((item: { Id: number; Name: string }) => item.Name.toLowerCase());
              //           setExcludedLookupFields(names);
              //         } else {
              //           throw new Error("Bad response");
              //         }
              //       } catch (err) {
              //         console.warn("Failed to load excluded lookups, using fallback", err);
              //         setExcludedLookupFields(["transactionid", "referenceid", "movementid", "parentid", "grnid"]);
              //       }
              //     };
              //     fetchExcludedLookups();
              //   }, [apiBaseUrl]);
              // useEffect(() => {
              //   if (editingItem) {
              //     // Only set values if we are editing and the item exists
              //     form.setFieldsValue(editingItem);
              //   } else {
              //     // Optionally reset the form when adding a new item
              //     form.resetFields();
              //   }
              // }, [editingItem, form]); // Re-run whenever editingItem or form changes
              //   // ==================== Initial Load ====================
              //   useEffect(() => {
              //     if (isReport) runReport();
              //     else fetchData();
              //      fetchLookups();
              //   }, [resourceName, excludedLookupFields]);

              //   // ==================== Edit & Calculations ====================

              // const handleEdit = async (record: Record<string, any>) => {
              //   // 1. Reset form completely
              //   form.resetFields();

              //   // 2. Make a deep copy and normalize ALL possible field types
              //   const normalizedValues: Record<string, any> = {};

              //   // Process master fields
              //   fields.forEach((field) => {
              //     let value = record[field];

              //     if (value === undefined || value === null) {
              //       normalizedValues[field] = undefined;
              //       return;
              //     }

              //     const lower = field.toLowerCase();

              //     // Date handling
              //     if (lower.includes("date") || lower.includes("year") || lower.includes("month") || lower.endsWith("edat")) {
              //       if (typeof value === "string" && value.trim()) {
              //         normalizedValues[field] = moment(value);
              //       } else if (moment.isMoment(value)) {
              //         normalizedValues[field] = value;
              //       } else {
              //         normalizedValues[field] = undefined;
              //       }
              //     }
              //     // Number fields – ensure number type if needed (Selects with number IDs need this)
              //     else if (/id$/i.test(lower) && lookupData[field]) {
              //       normalizedValues[field] = Number(value); // Critical for Select with numeric IDs
              //     }
              //     // Boolean fields
              //     else if (/is|active|enabled/i.test(lower)) {
              //       normalizedValues[field] = Boolean(value);
              //     }
              //     // Everything else
              //     else {
              //       normalizedValues[field] = value;
              //     }
              //   });

              //   // 3. Handle master-detail line items
              //   if (isMaster && detailConfig) {
              //     try {
              //       const lines = await fetchLineItems(record[fields[0]]);
              //       const normalizedLines = (Array.isArray(lines) ? lines : []).map((line: any) => {
              //         const normalizedLine: any = {};
              //         detailConfig.fields.forEach((f) => {
              //           let val = line[f];
              //           if (val !== null && val !== undefined) {
              //             if (f.toLowerCase().endsWith("id") && typeof val === "string") {
              //               normalizedLine[f] = Number(val);
              //             } else if (/date|year|month|edat/i.test(f) && typeof val === "string") {
              //               normalizedLine[f] = moment(val);
              //             } else {
              //               normalizedLine[f] = val;
              //             }
              //           }
              //         });
              //         return normalizedLine;
              //       });

              //       normalizedValues.lineItems = normalizedLines;
              //     } catch (err) {
              //       console.error("Failed to load line items", err);
              //       normalizedValues.lineItems = [];
              //     }
              //   }

              //   // 4. Small delay to ensure Form.List is ready (AntD quirk)
              //   setTimeout(() => {
              //     form.setFieldsValue(normalizedValues);
              //   }, 0);

              //   // 5. Set editing state
              //   setEditingItem(record);
              //   setModalVisible(true);
              // };
              // useEffect(() => {
              //   console.log("Current editingItem:", editingItem ? JSON.stringify(editingItem) : null);
              // }, [editingItem]);
              // // const handleEdit = (record: any) => {
              // //   setEditingItem(record);
              // //   setModalVisible(true);

              // //   // Populate form fields
              // //   form.setFieldsValue({
              // //     ...record, // master fields
              // //     lineItems: record.lineItems || [], // ensure line items exist
              // //   });
              // // };
              //   const calculateTotals = useCallback(() => {
              //     const lines: any[] = form.getFieldValue("lineItems") || [];
              //     let subtotal = 0;

              //     lines.forEach((line: any, index: number) => {
              //       const qty = Number(line[qtyField] || 0);
              //       const price = Number(line[priceField] || 0);
              //       const lineTotal = qty * price;
              //       subtotal += lineTotal;

              //       if (lineTotalField) {
              //         form.setFieldValue(["lineItems", index, lineTotalField], lineTotal);
              //       }
              //     });

              //     let tax = 0;
              //     if (taxField) {
              //       tax = lines.reduce((sum: number, line: any) => {
              //         const lineSub = Number(line[qtyField] || 0) * Number(line[priceField] || 0);
              //         return sum + lineSub * (Number(line[taxField] || 0) / 100);
              //       }, 0);
              //     }

              //     const grandTotal = subtotal + tax;

              //     form.setFieldsValue({
              //       subtotal,
              //       taxAmount: tax,
              //       grandTotal,
              //     });
              //   }, [form, qtyField, priceField, lineTotalField, taxField]);

              //   // Trigger recalculation on form changes
              //   const handleValuesChange = useCallback(() => {
              //     if (isMaster) {
              //       calculateTotals();
              //     }
              //   }, [isMaster, calculateTotals]);

              //   // ==================== Save Logic ====================
              //   const handleSave = async (values: Record<string, any>) => {
              //     fields.forEach((f) => {
              //       if (values[f] && moment.isMoment(values[f])) values[f] = values[f].format("YYYY-MM-DD");
              //       if (!editingItem && f.toLowerCase().includes("by")) values[f] = loggedInUserId;
              //       if (!editingItem && f.toLowerCase().includes("number")) values[f] = generateNumberField(f);
              //     });

              //     let url = `${apiBaseUrl}/${resourceName}`;
              //     let method = "POST";
              //     let payload: any = { ...values };

              //     if (editingItem) {
              //       method = "PUT";
              //       const pk = editingItem[fields[0]];
              //       url = `${apiBaseUrl}/${resourceName}/${pk}`;
              //     }

              // if ((method === "POST") || (method === "PUT")) {
              //   const primaryKeyField = fields[0];
              //   if (primaryKeyField?.toLowerCase().endsWith("id")) {
              //     delete payload[primaryKeyField];
              //   }
              // }
                  
              //     if (isMaster) {
              //       const lineItemsValue = form.getFieldValue("lineItems") || [];
              //       payload = { ...values, [detailConfig!.resourceName]: lineItemsValue };
              //       url = `${apiBaseUrl}/${resourceName}/full${editingItem ? `/${editingItem[fields[0]]}` : ""}`;
              //     }
              // console.log(JSON.stringify(payload));
              //     try {
              //       const res = await fetch(url, {
              //         method,
              //         headers: { "Content-Type": "application/json" },
              //         body: JSON.stringify(payload),
              //       });

              //       if (!res.ok) throw new Error(await res.text() || "Save failed");

              //       message.success("Saved successfully");
              //       closeModal();
              //       fetchData();
              //     } catch (err: any) {
              //       if (isMaster && err.message.includes("404")) {
              //         await handleSaveFallback(values);
              //       } else {
              //         message.error(err.message || "Save failed");
              //       }
              //     }
              //   };

              //   const handleSaveFallback = async (headerValues: any) => {
              //     try {
              //       const headerUrl = `${apiBaseUrl}/${resourceName}${editingItem ? `/${editingItem[fields[0]]}` : ""}`;
              //       const headerRes = await fetch(headerUrl, {
              //         method: editingItem ? "PUT" : "POST",
              //         headers: { "Content-Type": "application/json" },
              //         body: JSON.stringify(headerValues),
              //       });
              //       if (!headerRes.ok) throw new Error("Header save failed");
              //       const savedHeader = editingItem ? editingItem : await headerRes.json();
              //       const parentId = savedHeader[fields[0]];

              //       const lines = form.getFieldValue("lineItems") || [];

              //       if (editingItem) {
              //         await fetch(`${apiBaseUrl}/${detailConfig!.resourceName}/by-${detailConfig!.foreignKey}/${parentId}`, {
              //           method: "DELETE",
              //         }).catch(() => {});
              //       }

              //       for (const line of lines) {
              //         const linePayload = { ...line, [detailConfig!.foreignKey]: parentId };
              //         await fetch(`${apiBaseUrl}/${detailConfig!.resourceName}`, {
              //           method: "POST",
              //           headers: { "Content-Type": "application/json" },
              //           body: JSON.stringify(linePayload),
              //         });
              //       }

              //       message.success("Saved successfully (fallback)");
              //       closeModal();
              //       fetchData();
              //     } catch (err) {
              //       message.error("Fallback save failed" + err);
              //     }
              //   };

              //   const handleDelete = async (record: Record<string, any>) => {
              //     const rowKey = getRowKey(record);
              //     try {
              //       const res = await fetch(`${apiBaseUrl}/${resourceName}/${rowKey}`, { method: "DELETE" });
              //       if (!res.ok) throw new Error("delete failed");
              //       message.success("Deleted successfully");
              //     } catch (err) {
              //       message.error("Delete failed" + err);
              //     } finally {
              //       fetchData();
              //     }
              //   };

              //   const closeModal = () => {
              //     setModalVisible(false);
              //     setEditingItem(null);
              //     form.resetFields();
              //     setExpandedRowKeys([]); // optional
              //   };

              //   const getRowKey = (record: Record<string, any>) => {
              //     const idField = fields.find((f) => f.toLowerCase().endsWith("id"));
              //     return idField && record[idField] !== undefined ? String(record[idField]) : JSON.stringify(record);
              //   };

              //   // ==================== + Add Lookup Item ====================
              //   const openAddLookup = (field: string) => {
              
              //    setLookupModalField(field);
                
              //     setLookupModalVisible(true);  //alert("Saveing");
              //   };

              //   const handleAddNewLookup = async () => {
              //     if (!lookupModalField) return;
                  
              //     try {
              //       const values = await lookupForm.validateFields();
              //       const endpoint = lookupEndpointFromField(lookupModalField);
              //       const res = await fetch(`${apiBaseUrl}/${endpoint}`, {
              //         method: "POST",
              //         headers: { "Content-Type": "application/json" },
              //         body: JSON.stringify(values),
              //       });
              //       if (!res.ok) throw new Error("create lookup failed");
              //       message.success("Added successfully");
              //       setLookupModalVisible(false);
              //       lookupForm.resetFields();
              //       await fetchLookups();
              //     } catch (err) {
              //       message.error("Failed to add lookup item" + err);
              //     }
              //   };

              //   // ==================== Render Form Items ====================
              //   const renderFormItemComponent = (f: string, _isLineItem = false) => {
              //     const lower = f.toLowerCase();
              //     const isExcluded = excludedLookupFields.some((ex) => lower === ex || lower.endsWith(ex));
              //     const isByField = lower.endsWith("by") || lower.endsWith("edby");
              //     const isLookup = (lower.endsWith("id") || lower.endsWith("currency") || lower.endsWith("company") || lower.endsWith("accounttype") || lower.endsWith("status") || lower.endsWith("entitytype")) && !isExcluded && !isByField;

              //     const isBoolean = /is|active|enabled/i.test(f);
              //    // const isDate = /date/i.test(f);
              //     const isDate =
              //   lower.includes("date") ||
              //   lower.endsWith("edat");
              //     const isYear = /year/i.test(f);
              //     const isMonth = /month/i.test(f);
              //     const isNumber = /amount|price|total|qty|quantity|rate|balance/i.test(f);

              //     if (isLookup) {
              //       const options = lookupData[f]?.map((i) => ({ label: i.label, value: i.id })) || [];
              //       return (
              //         <Select
              //           options={options}
              //           showSearch
              //           optionFilterProp="label"
              //           allowClear
              //           placeholder={`Select ${f}`}
              //         />
              //       );
              //     }

              //     if (isByField && lookupData[f]) {
              //       const options = lookupData[f]?.map((i) => ({ label: i.label, value: i.id })) || [];
              //       return <Select options={options} disabled />;
              //     }

              //     if (isBoolean) return <Checkbox />;
              //     if (isDate) return <DatePicker style={{ width: "100%" }} />;
              //     if (isYear) return <DatePicker picker="year" style={{ width: "100%" }} />;
              //     if (isMonth) return <DatePicker picker="month" style={{ width: "100%" }} />;

              //     if (isNumber) {
              //       return (
              //         <InputNumber
              //           style={{ width: "100%" }}
              //           formatter={(value) => `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ",")}
              //           parser={(value) => value?.replace(/,/g, "") || ""}
              //         />
              //       );
              //     }

              //    // return <Input placeholder={`Enter ${f}`} />;
              //     return <Input id={f} placeholder={`Enter ${f}`} />;
              //   };

              //   const renderFormItem = (f: string, idx: number, _isLineItem = false) => {
              //     if (!editingItem && idx === 0 && !_isLineItem) return null;
              //     if (editingItem && idx === 0 && !_isLineItem) {
              //       return (
              //         <Form.Item key={f} label={f} name={f}>
              //           <Input disabled />
              //         </Form.Item>
              //       );
              //     }

              //     const lower = f.toLowerCase();
              //     const isLookup = (lower.endsWith("id") || lower.endsWith("currency") || lower.endsWith("company") || lower.endsWith("accounttype")|| lower.endsWith("status")|| lower.endsWith("entitytype")) && !excludedLookupFields.some(ex => lower === ex || lower.endsWith(ex)) && !lower.endsWith("by") && !lower.endsWith("edby");

              //     // const label = isLookup && !isLineItem ? (
              //     //   <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              //     //     <span>{f}</span>
              //     //     <Button size="small" onClick={() => openAddLookup(f)} style={{ marginLeft: 8 }}>
              //     //       + Add
              //     //     </Button>
              //     //   </div>
              //     // ) : f;

              //     const label = isLookup && !_isLineItem ? (
              //   <div
              //     style={{
              //       display: "flex",
              //       justifyContent: "space-between",
              //       alignItems: "center",
              //       gap: 8,
              //     }}
              //   >
              //     <span>{f}</span>
              //     <Button  id={f}  name={f}
              //       size="small"
              //       htmlType="button"
              //     onClick={() => openAddLookup(f)}
              //     >
              //       + Add
              //     </Button>
              //   </div>
              // ) : f;


              //     if (_isLineItem) {
              //       return renderFormItemComponent(f, true);
              //     }

              //     if (lower.includes("number") && !editingItem) {
              //       return (
              //         <Form.Item key={f} label={f}>
              //       {/* <Input.Group compact> */}
              //     <Form.Item name={f} noStyle>
              //       <Input
              //         style={{ width: "calc(100% - 110px)" }}
              //         placeholder={`Enter ${f}`}
              //       />
              //     </Form.Item>

              //     <Button
              //       type="default"
              //       style={{ width: 110 }}
              //       onClick={() => {
              //         const prefix = (f.match(/[A-Z]/g) || []).join("") || "XX";
              //         const dateStr = moment().format("YYYYMMDD");
              //         const rand10 = Math.floor(Math.random() * 1_000_000_0000)
              //           .toString()
              //           .padStart(10, "0");

              //         form.setFieldValue(f, `${prefix}${dateStr}${rand10}`);
              //       }}
              //     >
              //       Regenerate
              //     </Button>
              //   {/* </Input.Group> */}
              // </Form.Item>

              //       );
              //     }
              //  // Default case: normal form item
              //   return (
              //     <Form.Item key={f} label={label} name={f}>
              //       {renderFormItemComponent(f, _isLineItem)}
              //     </Form.Item>
              //   );
              //     // return (
              //     //       <Form.Item key={f} label={f} name={f}>
              //     //         <div style={{ display: "flex", gap: 8 }}>
              //     //           <div style={{ flex: 1 }}>
              //     //             {renderFormItemComponent(f)}
              //     //           </div>

              //     //           {/* {isLookup && !isLineItem && (
              //     //             <Button
              //     //               size="small"
              //     //               htmlType="button"
              //     //               onClick={() => openAddLookup(f)}
              //     //             >
              //     //               + Add
              //     //             </Button>
              //     //           )} */}
              //     //         </div>
              //     //       </Form.Item>
              //     // );
              //   };

              //   // ==================== Table Columns ====================
              //   const handleTableChange = (_pagination: any, _filters: any, sorter: any) => {
              //     setSortedInfo(sorter);
              //   };

              //   const columns: ColumnsType<Record<string, any>> = [
              //     {
              //       title: "Actions",
              //       key: "actions",
              //       fixed: "left",
              //       width: 140,
              //       render: (_: any, record: any) => (
              //         <Space>
              //           <Button type="link" onClick={() => handleEdit(record)}>
              //             Edit
              //           </Button>
              //           <Button type="link" danger onClick={() => handleDelete(record)}>
              //             Delete
              //           </Button>
              //         </Space>
              //       ),
              //     },
              //     ...fields
              //       .slice(0, showAllFields ? fields.length : 6)
              //       .map((f) => {
              //         const isNumberField = /amount|price|total|qty|quantity|rate|balance|number/i.test(f.toLowerCase());
              //         const isDateField = /date|year|month|edat/i.test(f.toLowerCase());

              //         return {
              //           title: f,
              //           dataIndex: f,
              //           key: f,
              //           align: isNumberField ? ("right" as const) : ("left" as const),
              //           sorter: isDateField
              //             ? (a: any, b: any) => {
              //                 const dateA = a[f] ? new Date(a[f]).getTime() : 0;
              //                 const dateB = b[f] ? new Date(b[f]).getTime() : 0;
              //                 return dateA - dateB;
              //               }
              //             : isNumberField
              //             ? (a: any, b: any) => (a[f] || 0) - (b[f] || 0)
              //             : (a: any, b: any) =>
              //                 String(a[f] || "").localeCompare(String(b[f] || "")),
              //           sortOrder: sortedInfo.columnKey === f ? sortedInfo.order : undefined,
              //           ...getColumnSearchProps(f),
              //           render: (value: any) => {
              //             if (f.toLowerCase().endsWith("id") && lookupData[f]?.length) {
              //               const item = lookupData[f].find((i) => Number(i.id) === Number(value));
              //               return item ? item.label : value;
              //             }
              //             if (isNumberField && (typeof value === "number" || !isNaN(Number(value)))) {
              //               return <div style={{ textAlign: "right" }}>{Number(value).toLocaleString("en-US")}</div>;
              //             }
              //             if (isDateField && value) {
              //               return moment(value).format(f.toLowerCase().includes("year") ? "YYYY" : "YYYY-MM-DD");
              //             }
              //             return value?.toString() || "-";
              //           },
              //         };
              //       }),
              //   ];

              //   const filteredData = data.filter((item) =>
              //     fields.some((field) => {
              //       const value = item[field];
              //       return value != null && String(value).toLowerCase().includes(globalSearch.toLowerCase());
              //     })
              //   );

              //   // ==================== Expandable Row for Line Items ====================
              //   const handleExpand = async (expanded: boolean, record: Record<string, any>) => {
              //     if (!isMaster || !detailConfig) return;

              //     const key = getRowKey(record);
              //     if (expanded && !expandedLines[key]) {
              //       const lines = await fetchLineItems(record[fields[0]]);
              //       setExpandedLines((prev) => ({ ...prev, [key]: lines }));
              //     }
              //     setExpandedRowKeys(expanded ? [key] : []);
              //   };

              //   const expandedRowRender = (record: Record<string, any>) => {
              //     const key = getRowKey(record);
              //     const lines = expandedLines[key] || [];
              //     if (lines.length === 0) return <Text type="secondary">No line items</Text>;

              //     return (
              //       <Table
              //         dataSource={lines}
              //         columns={detailConfig!.fields.map((f) => ({
              //           title: f,
              //           dataIndex: f,
              //           key: f,
              //           render: (val: any) => {
              //             if (f.toLowerCase().endsWith("id") && lookupData[f]?.length) {
              //               const item = lookupData[f].find((i) => i.id === val);
              //               return item ? item.label : val;
              //             }
              //             const isNumber = /amount|price|total|qty|quantity|rate|balance/i.test(f.toLowerCase());
              //             if (isNumber && val != null) {
              //               return <div style={{ textAlign: "right" }}>{Number(val).toLocaleString()}</div>;
              //             }
              //             return val ?? "-";
              //           },
              //         }))}
              //         pagination={false}
              //         size="small"
              //       expandable={
              //     isMaster
              //       ? {
              //           expandedRowKeys,
              //           onExpand: handleExpand,
              //           expandedRowRender,
              //         }
              //       : undefined
              //   }
              //       />
              //     );
              //   };

              //   // ==================== JSX ====================
              //   return (
              //     <div style={{ padding: 20 }}>
              //       <Row style={{ marginBottom: 16 }} gutter={8} justify="space-between">
              //         <Col>
              //           <Button type="primary" onClick={() => {
              //             setEditingItem(editingItem);
              //             form.resetFields();
              //             setModalVisible(true);
              //           }}>
              //             Add {resourceName}
              //           </Button>
              //         </Col>
              //         <Col flex="auto" style={{ textAlign: 'right' }}>
              //           <Input
              //             placeholder="Search all records..."
              //             prefix={<SearchOutlined />}
              //             allowClear
              //             value={globalSearch}
              //             onChange={(e) => setGlobalSearch(e.target.value)}
              //             style={{ width: 300 }}
              //           />
              //         </Col>
              //         <Col>
              //           <Button onClick={() => setShowAllFields((p) => !p)}>{showAllFields ? "Show Less" : "Show More Fields"}</Button>
              //         </Col>
              //         <Col>
              //           <input type="color" value={rowColor} onChange={(e) => setRowColor(e.target.value)} title="Select Row Color" style={{ width: 40, height: 32, border: "none" }} />
              //         </Col>
              //       </Row>

              //       {isReport ? (
              //         <></> // omitted for brevity, same as before
              //       ) : (
              //         <Table
              //           dataSource={globalSearch ? filteredData : data}
              //           columns={columns}
              //           rowKey={getRowKey}
              //           loading={loading}
              //           scroll={{ x: "max-content" }}
              //           onChange={handleTableChange}
              //           rowClassName={(_record, index) => (index % 2 === 0 ? "even-row" : "odd-row")}
              //           style={{ ["--row-bg-even" as any]: rowColor, ["--row-bg-odd" as any]: shadeColor(rowColor, -0.05) } as any}
              //           locale={{ emptyText: `No ${resourceName} found` }}
              //           expandable={isMaster ? {
              //             expandedRowKeys,
              //             onExpand: handleExpand,
              //             expandedRowRender,
              //           } : undefined}
              //           onRow={(record) => ({ onDoubleClick: () => handleEdit(record) })}
              //         />
              //       )}


              // <Modal
              //   title={editingItem ? `Edit ${resourceName}` : `Add ${resourceName}`}
              //   open={modalVisible}
              //   width={1300}
              //   onCancel={closeModal}
              //   onOk={() => form.submit()}
                
              //   destroyOnClose={true} // updated per antd v5
              // >
              //   <Form
              //     form={form}
              //     onFinish={handleSave}
              //     layout="vertical"
                
              //     onValuesChange={handleValuesChange}
              //   >
              //     <Row gutter={16}>
              //       {fields.map((f, idx) => (
              //         <Col span={8} key={f}>
              //           {renderFormItem(f, idx)}
              //         </Col>
              //       ))}
              //     </Row>

              //     {isMaster && detailConfig && (
              //       <>
              //         <Divider orientation="left">Line Items (Detailed View)</Divider>
              //         <Form.List name="lineItems">
              //           {(lineFields, { add, remove }) => (
              //             <>
              //               <Table
              //                 dataSource={lineFields} // directly use Form.List fields
              //                 pagination={false}
              //                 size="small"
              //                 rowKey={(field) => field.key} // each field has a unique key
              //                 columns={[
              //                   ...detailConfig.fields.map((f) => ({
              //                     title: f,
              //                     width: 200,
              //                     render: (_: any, __: any, index: number) => {
              //                       const field = lineFields[index];
              //                       return (
              //                         <Form.Item
              //                           name={[field.name, f]}         // use Form.List name
              //                          fieldKey={[String(field.fieldKey ?? ""), String(f ?? "")]} //fieldKey={[field.fieldKey, f]} // use Form.List fieldKey
              //                           noStyle
              //                         >
              //                           {renderFormItemComponent(f, true)}
              //                         </Form.Item>
              //                       );
              //                     },
              //                   })),
              //                   {
              //                     title: "Action",
              //                     width: 100,
              //                     render: (_: any, __: any, index: number) => (
              //                       <Button
              //                         danger
              //                         size="small"
              //                         onClick={() => remove(index)}
              //                       >
              //                         Delete
              //                       </Button>
              //                     ),
              //                   },
              //                 ]}
              //               />
              //               <Button
              //                 type="dashed"
              //                 onClick={() => add({ [qtyField]: 1, [priceField]: 0 })}
              //                 block
              //                 icon={<PlusOutlined />}
              //                 style={{ marginTop: 16 }}
              //               >
              //                 Add Line Item
              //               </Button>
              //             </>
              //           )}
              //         </Form.List>
              //       </>
              //     )}
              //   </Form>
              // </Modal>


              //       {/* Lookup Modal - simplified for brevity, same as before but using values directly 
                
              // <Modal
              //   title={lookupModalField ? `Add New ${lookupModalField}` : "Add New"}
              //   open={lookupModalVisible}
              //   width={900}
              //   destroyOnHidden
              //   onCancel={() => {
              //     setLookupModalVisible(false);
              //     lookupForm.resetFields();
              //     setLookupModalField(null);
              //   }}
              //   onOk={() => lookupForm.submit()} // submit lookup form
              // >
              //   <Form
              //     form={lookupForm}
              //     layout="vertical"
              //     onFinish={handleAddNewLookup}
              //   >
              //     <Row gutter={16}>
              //       {lookupModalField &&
              //         (fieldsForLookup[lookupModalField] || []).map((f: string) => (
              //           <Col span={8} key={f}>
              //             <Form.Item
              //               label={f}
              //               name={f}
              //               rules={[{ required: true }]}
              //             >
              //               {renderFormItemComponent(f)}
              //             </Form.Item>
              //           </Col>
              //         ))}
              //     </Row>
              //   </Form>
              // </Modal>*/}
              // <Modal
              //   title={`Add New ${lookupModalField}`}
              //   open={lookupModalVisible}
              //   width={900}
              //   onCancel={() => {
              //     setLookupModalVisible(false);
              //     lookupForm.resetFields();
              //     setLookupModalField(null);
              //   }}
              //   onOk={() => lookupForm.submit()}
              //   destroyOnClose
              // >
              //   <Form
              //     form={lookupForm}
              //     layout="vertical"
              //     onFinish={handleAddNewLookup}
              //   >
              //     <Row gutter={16}>
              //       {lookupModalField &&
              //         (fieldsForLookup[lookupModalField] || [])
              //           .filter((field: string, index: number, array: string[]) => {
              //             // If there are no fields, don't filter
              //             if (array.length === 0) return true;

              //             const lowerField = field.toLowerCase();
              //             const isFirstField = index === 0;

              //             // Derive expected table name from the lookup field (e.g., "CustomerId" → "customer")
              //             const lookupFieldLower = lookupModalField!.toLowerCase();
              //             let expectedTableName = lookupEndpointFromField(lookupModalField!); // e.g., "customers"
                          
              //             // Fallback: extract from field name (remove "Id" and pluralize rules)
              //             if (lookupFieldLower.endsWith("id")) {
              //               let base = lookupModalField!.slice(0, -2); // remove "Id"
              //               // Simple plural to singular guess
              //               if (base.endsWith("ies")) base = base.slice(0, -3) + "y";
              //               else if (base.endsWith("s")) base = base.slice(0, -1);
              //               expectedTableName = base.toLowerCase();
              //             }

              //             const expectedPkPattern = new RegExp(`^${expectedTableName}id$`, "i");

              //             // Hide only if:
              //             // - It's the first field AND
              //             // - Its name matches the expected primary key pattern (e.g., CustomerId for customers)
              //             const isPrimaryKey = isFirstField && expectedPkPattern.test(field);

              //             return !isPrimaryKey;
              //           })
              //           .map((field: string) => (
              //             <Col span={8} key={field}>
              //               <Form.Item
              //                 label={field}
              //                 name={field}
              //                 rules={[
              //                   {
              //                     required: /name|code|title|description|label/i.test(field),
              //                     message: `${field} is required`,
              //                   },
              //                 ]}
              //               >
              //                 {renderFormItemComponent(field)}
              //               </Form.Item>
              //             </Col>
              //           ))}
              //     </Row>
              //   </Form>
              // </Modal>
              //       <style>{`
              //         .even-row { background-color: var(--row-bg-even, #ffffff); }
              //         .odd-row { background-color: var(--row-bg-odd, #f9f9f9); }
              //       `}</style>
              //     </div>
              //   );
              // };

              // export default GenericResourcePage;  

              // // <Form form={lookupForm} layout="vertical">
              // //           <Row gutter={16}>
              // //             {lookupModalField && fieldsForLookup[lookupModalField] ? (
              // //               fieldsForLookup[lookupModalField].map((k) => (
              // //                 <Col span={8} key={k}>
              // //                   <Form.Item name={k} label={k} rules={[{ required: k.toLowerCase().includes("name") }]}>
              // //                     <Input />
              // //                   </Form.Item>
              // //                 </Col>
              // //               ))
              // //             ) : (
              // //               <Col span={8}>
              // //                 <Form.Item name="name" label="Name" rules={[{ required: true }]}>
              // //                   <Input />
              // //                 </Form.Item>
              // //               </Col>
              // //             )}
              // //           </Row>
              // //         </Form>