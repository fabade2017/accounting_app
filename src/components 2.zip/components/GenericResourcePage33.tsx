import React, { useEffect, useRef, useState, useCallback } from "react";
import {
  Table,
  Button,
  Modal,
  Form,
  Input,
  Select,
  Space,
  message,
  Checkbox,
  Row,
  Col,
  DatePicker,
  InputNumber,
  InputRef,
  Typography,
  Divider,
  Alert,
} from "antd";
import { SearchOutlined, PlusOutlined } from "@ant-design/icons";
import type { FilterConfirmProps } from "antd/es/table/interface";
import { ColumnsType } from "antd/es/table";
import moment from "moment";
import Highlighter from "react-highlight-words";

const { Text } = Typography;

interface LookupItem {
  id: string | number;
  label: string;
  [k: string]: any;
}

interface DetailConfig {
  resourceName: string;
  foreignKey: string;
  fields: string[];
  quantityField?: string;
  priceField?: string;
  lineTotalField?: string;
  taxField?: string;
}

interface Props {
  resourceName: string;
  apiBaseUrl?: string;
  fields: string[];
  detailConfig?: DetailConfig;
}

export const GenericResourcePage: React.FC<Props> = ({
  resourceName,
  apiBaseUrl = "",
  fields,
  detailConfig,
}) => {
  const [data, setData] = useState<Record<string, any>[]>([]);
  const [loading, setLoading] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [editingItem, setEditingItem] = useState<Record<string, any> | null>(null);
  const [lookupData, setLookupData] = useState<Record<string, LookupItem[]>>({});
  const [fieldsForLookup, setFieldsForLookup] = useState<Record<string, string[]>>({});
  const [form] = Form.useForm();
  const [showAllFields, setShowAllFields] = useState(false);
  const [rowColor, setRowColor] = useState("#ffffff");
  const [globalSearch, setGlobalSearch] = useState("");
  const [searchText, setSearchText] = useState("");
  const [searchedColumn, setSearchedColumn] = useState("");
  const [sortedInfo, setSortedInfo] = useState<{ columnKey?: string; order?: "ascend" | "descend" }>({});
  const searchInput = useRef<InputRef>(null);
  const loggedInUserId = Number(localStorage.getItem("userid") || 0);
  const [lookupModalVisible, setLookupModalVisible] = useState(false);
  const [lookupModalField, setLookupModalField] = useState<string | null>(null);
  const [lookupForm] = Form.useForm();
  const isReport = resourceName.toLowerCase().includes("report");
  const [reportParams, setReportParams] = useState<Record<string, any>>({});
  const [reportData, setReportData] = useState<any[]>([]);

  const [detailConfigState, setDetailConfigState] = useState<DetailConfig | undefined>(undefined);
  const effectiveDetailConfig = detailConfig || detailConfigState;
  const isMaster = Boolean(effectiveDetailConfig);

  const qtyField = effectiveDetailConfig?.quantityField || "quantity";
  const priceField = effectiveDetailConfig?.priceField || "price";
  const lineTotalField = effectiveDetailConfig?.lineTotalField || "lineTotal";
  const taxField = effectiveDetailConfig?.taxField;

  const [excludedLookupFields, setExcludedLookupFields] = useState<string[]>([]);
  const [lineItemRows, setLineItemRows] = useState<any[]>([]);
  const [expandedRowKeys, setExpandedRowKeys] = useState<string[]>([]);
  const [expandedLines, setExpandedLines] = useState<Record<string, any[]>>({});
  const [warning, setWarning] = useState("");
  const [lineWarning, setLineWarning] = useState("");
  const [lineModalVisible, setLineModalVisible] = useState(false);
  const [currentMaster, setCurrentMaster] = useState<Record<string, any> | null>(null);
  const [lineForm] = Form.useForm();

  // Helper: PascalCase → camelCase
  const toCamelCase = (str: string) => str.charAt(0).toLowerCase() + str.slice(1);

  // ==================== Helpers ====================
  const handleSearch = (
    selectedKeys: string[],
    confirm: (param?: FilterConfirmProps) => void,
    dataIndex: string,
  ) => {
    confirm();
    setSearchText(selectedKeys[0]);
    setSearchedColumn(dataIndex);
  };
const calculateLineTotals = useCallback(() => {
      const lines: any[] = lineForm.getFieldValue("lineItems") || [];
      let subtotal = 0;
      let tax = 0;
      lines.forEach((line: any) => {
        const qty = Number(line[qtyField] || 0);
        const price = Number(line[priceField] || 0);
        const lineTotal = qty * price;
        subtotal += lineTotal;
        if (taxField) {
          tax += lineTotal * (Number(line[taxField] || 0) / 100);
        }
      });
      const grandTotal = subtotal + tax;
      // Check for exceeding limits
      let newWarning = "";
      const possibleLimitFields = ["totalCredit", "totalDebit", "totalAmount", "budget", "maxAmount"];
      const limitField = possibleLimitFields.find((lf) => fields.includes(lf));
      if (limitField && currentMaster) {
        const limit = Number(currentMaster[limitField] || 0);
        if (grandTotal > limit) {
          newWarning = `Warning: Grand total (${grandTotal.toLocaleString()}) exceeds ${limitField} (${limit.toLocaleString()})`;
        }
      }
      setLineWarning(newWarning);
      return { subtotal, tax, grandTotal };
    }, [lineForm, qtyField, priceField, taxField, fields, currentMaster]);

  const handleReset = (clearFilters: () => void) => {
    clearFilters();
    setSearchText("");
  };

  const getColumnSearchProps = (dataIndex: string): any => ({
    filterDropdown: ({ setSelectedKeys, selectedKeys, confirm, clearFilters }: any) => (
      <div style={{ padding: 8 }} onKeyDown={(e) => e.stopPropagation()}>
        <Input
          ref={searchInput}
          placeholder={`Search ${dataIndex}`}
          value={selectedKeys[0]}
          onChange={(e) => setSelectedKeys(e.target.value ? [e.target.value] : [])}
          onPressEnter={() => handleSearch(selectedKeys as string[], confirm, dataIndex)}
          style={{ marginBottom: 8, display: "block" }}
        />
        <Space>
          <Button
            type="primary"
            onClick={() => handleSearch(selectedKeys as string[], confirm, dataIndex)}
            icon={<SearchOutlined />}
            size="small"
            style={{ width: 90 }}
          >
            OK
          </Button>
          <Button onClick={() => clearFilters && handleReset(clearFilters)} size="small" style={{ width: 90 }}>
            Reset
          </Button>
        </Space>
      </div>
    ),
    filterIcon: (filtered: boolean) => <SearchOutlined style={{ color: filtered ? "#1677ff" : undefined }} />,
    onFilter: (value: any, record: any) =>
      record[dataIndex] ? String(record[dataIndex]).toLowerCase().includes((value as string).toLowerCase()) : false,
    onFilterDropdownOpenChange: (visible: boolean) => {
      if (visible) {
        setTimeout(() => searchInput.current?.select(), 100);
      }
    },
    render: (text: any) =>
      searchedColumn === dataIndex ? (
        <Highlighter
          highlightStyle={{ backgroundColor: "#ffc069", padding: 0 }}
          searchWords={[searchText]}
          autoEscape
          textToHighlight={text ? text.toString() : ""}
        />
      ) : (
        text
      ),
  });

  const shadeColor = (color: string, percent: number) => {
    let R = parseInt(color.substring(1, 3), 16);
    let G = parseInt(color.substring(3, 5), 16);
    let B = parseInt(color.substring(5, 7), 16);
    R = Math.min(255, Math.max(0, Math.round(R + R * percent)));
    G = Math.min(255, Math.max(0, Math.round(G + G * percent)));
    B = Math.min(255, Math.max(0, Math.round(B + B * percent)));
    const RR = R.toString(16).padStart(2, "0");
    const GG = G.toString(16).padStart(2, "0");
    const BB = B.toString(16).padStart(2, "0");
    return `#${RR}${GG}${BB}`;
  };

  const generateNumberField = (fieldName: string) => {
    const letters = (fieldName.match(/[A-Z]/g) || []).join("") || "";
    const datePart = moment().format("YYYYMMDD");
    const randomPart = Math.floor(Math.random() * 1_000_000_0000)
      .toString()
      .padStart(10, "0");
    return `${letters}${datePart}${randomPart}`;
  };

  const normalize = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, "");
  const singularize = (name: string) => {
    if (name.endsWith("ies")) return name.slice(0, -3) + "y";
    if (name.endsWith("ses")) return name.slice(0, -2);
    if (name.endsWith("s")) return name.slice(0, -1);
    return name;
  };

  const resolveDetailConfig = async (resourceName: string): Promise<DetailConfig | null> => {
    const masterNorm = normalize(resourceName);
    const masterSingular = singularize(masterNorm);
    const candidates = [
      `${masterSingular}lineitems`,
      `${masterNorm}lineitems`,
      `${masterSingular}_lineitems`,
      `${masterNorm}_lineitems`,
    ];
    for (const table of candidates) {
      try {
        const res = await fetch(`${apiBaseUrl}/${table}`);
        if (!res.ok) continue;
        const rows = await res.json();
        if (!Array.isArray(rows) || !rows.length) continue;
        const fields = Object.keys(rows[0]);
        const fk = fields.find(f =>
          normalize(f).includes(masterSingular) && normalize(f).endsWith("id")
        );
        if (!fk) continue;
        return {
          resourceName: table,
          foreignKey: fk,
          fields,
          quantityField: fields.find(f => /qty|quantity/i.test(f)),
          priceField: fields.find(f => /price|rate/i.test(f)),
          lineTotalField: fields.find(f => /total|amount/i.test(f)),
          taxField: fields.find(f => /tax/i.test(f)),
        };
      } catch {
        continue;
      }
    }
    return null;
  };

  useEffect(() => {
    (async () => {
      const detected = await resolveDetailConfig(resourceName);
      if (detected) {
        setDetailConfigState(detected);
      }
    })();
  }, [resourceName]);

  // ==================== Data Fetching ====================
  const fetchData = async () => {
    setData([]);
    setLoading(true);
    try {
      const res = await fetch(`${apiBaseUrl}/${resourceName}`);
      const json = await res.json();
      setData(Array.isArray(json) ? json : []);
    } catch (err) {
      message.error("Failed to load data");
    } finally {
      setLoading(false);
    }
  };

  const runReport = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${apiBaseUrl}/procedures/${resourceName}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(reportParams),
      });
      const json = await res.json();
      setReportData(Array.isArray(json) ? json : []);
    } catch (err) {
      message.error("Failed to run report");
    } finally {
      setLoading(false);
    }
  };

  const fetchLineItems = async (parentId: any) => {
    if (!effectiveDetailConfig) return [];
    const fk = effectiveDetailConfig.foreignKey;
    const attempts = [
      `${fk}=${parentId}`,
      `${fk.toLowerCase()}=${parentId}`,
      `${fk.replace(/[A-Z]/g, m => "_" + m.toLowerCase())}=${parentId}`,
      `parentid=${parentId}`,
    ];
    for (const q of attempts) {
      try {
        const res = await fetch(`${apiBaseUrl}/${effectiveDetailConfig.resourceName}?${q}`);
        const json = await res.json();
        if (Array.isArray(json) && json.length) return json;
      } catch {}
    }
    return [];
  };

  const lookupEndpointFromField = (f: string) => {
    let endpoint = f.replace(/\s/g, "");
    if (endpoint.toLowerCase().endsWith("by")) endpoint = "users";
    if (endpoint.toLowerCase().endsWith("accountid")) endpoint = "bankaccountid";
    if (endpoint.toLowerCase().endsWith("goodsreceivedid")) endpoint = "goodsreceivedid";
    endpoint = endpoint
      .replace(/yId$/i, "ies")
      .replace(/type$/i, "types")
      .replace(/y$/i, "ies")
      .replace(/ssId$/i, "sses")
      .replace(/edId$/i, "ed")
      .replace(/Id$/i, "s");
    return endpoint.toLowerCase().replace("lines", "lineitems");
  };

  // ==================== Fetch Lookups ====================
  const fetchLookups = async () => {
    const newLookup: Record<string, LookupItem[]> = {};
    const newFieldsForLookup: Record<string, string[]> = {};
    const allFields = [...fields, ...(effectiveDetailConfig?.fields || [])];

    const lookupFields = allFields.filter((f) => {
      const lower = f.toLowerCase();
      if (excludedLookupFields.some(ex => lower === ex || lower.endsWith(ex))) return false;
      return (
        lower.endsWith("id") ||
        lower.endsWith("currency") ||
        lower.endsWith("company") ||
        lower.endsWith("accounttype") ||
        lower.endsWith("entitytype") ||
        lower.endsWith("status") ||
        lower.endsWith("edby")
      );
    });

    for (const f of lookupFields) {
      let endpointField = f;
      if (f.toLowerCase().endsWith("edby") || f.toLowerCase().endsWith("by")) {
        endpointField = "users";
      }
      const endpoint = lookupEndpointFromField(endpointField);

      try {
        const res = await fetch(`${apiBaseUrl}/${endpoint}`);
        if (!res.ok) continue;
        const items = await res.json();
        if (!Array.isArray(items) || items.length === 0) continue;
        const sample = items[0];
        const keys = Object.keys(sample);
        const labelCandidates = keys.filter((k) => /name|title|code|desc|label/i.test(k));
        const labelKeys = labelCandidates.length ? labelCandidates.slice(0, 2) : keys.slice(1, 4);

        newLookup[f] = items.map((i: any) => {
          const labelParts = labelKeys.map((k) => i[k]).filter(Boolean);
          const label = labelParts.length ? labelParts.join(" - ") : String(i.id || i[keys[0]]);
          return { id: i.id ?? i[Object.keys(i)[0]], label, ...i };
        });
        newFieldsForLookup[f] = keys;
      } catch (err) {
        console.error(`Fetch failed for ${f} → ${endpoint}`, err);
      }
    }
    setLookupData(newLookup);
    setFieldsForLookup(newFieldsForLookup);
  };

  useEffect(() => {
    const fetchExcludedLookups = async () => {
      try {
        const res = await fetch(`${apiBaseUrl}/excludedlookup`);
        if (res.ok) {
          const json = await res.json();
          const names = json.map((item: { Id: number; Name: string }) => item.Name.toLowerCase());
          setExcludedLookupFields(names);
        } else {
          throw new Error("Bad response");
        }
      } catch (err) {
        console.warn("Failed to load excluded lookups, using fallback", err);
        setExcludedLookupFields(["transactionid", "referenceid", "movementid", "parentid", "grnid"]);
      }
    };
    fetchExcludedLookups();
  }, [apiBaseUrl]);

  useEffect(() => {
    if (isReport) runReport();
    else fetchData();
    fetchLookups();
  }, [resourceName, excludedLookupFields, effectiveDetailConfig]);

  // Auto-detect detail config fallback
  useEffect(() => {
    if (!detailConfig && !resourceName.toLowerCase().endsWith("lineitems") && !isReport) {
      let singularBase = resourceName;
      if (singularBase.endsWith("ies")) singularBase = singularBase.slice(0, -3) + "y";
      else if (singularBase.endsWith("sses")) singularBase = singularBase.slice(0, -2);
      else if (singularBase.endsWith("s")) singularBase = singularBase.slice(0, -1);
      const detailResource = singularBase.toLowerCase();
      const foreignKey = `${singularBase}Id`.toLowerCase();

      const checkDetail = async () => {
        setLoading(true);
        try {
          const res = await fetch(`${apiBaseUrl}/${detailResource}?_limit=1`);
          if (res.ok) {
            const json = await res.json();
            if (Array.isArray(json) && json.length > 0) {
              const sample = json[0];
              const detailFields = Object.keys(sample);
              setDetailConfigState({
                resourceName: detailResource,
                foreignKey,
                fields: detailFields,
                quantityField: detailFields.find((f) => /quantity|qty/i.test(f.toLowerCase())) || "quantity",
                priceField: detailFields.find((f) => /price|rate|amount/i.test(f.toLowerCase())) || "price",
                lineTotalField: detailFields.find((f) => /linetotal|total/i.test(f.toLowerCase())) || "lineTotal",
                taxField: detailFields.find((f) => /tax|vat/i.test(f.toLowerCase())),
              });
            }
          }
        } catch {}
        setLoading(false);
      };
      checkDetail();
    }
  }, [resourceName, apiBaseUrl, detailConfig, isReport]);

  // ==================== Edit ====================
  const handleEdit = async (record: Record<string, any>) => {
    form.resetFields();
    setLineItemRows([]);

    const normalizedValues: Record<string, any> = {};

    fields.forEach((field) => {
      let value = record[field];
      if (value === undefined || value === null) {
        normalizedValues[field] = undefined;
        return;
      }
      const lower = field.toLowerCase();
      if (lower.includes("date") || lower.includes("year") || lower.includes("month") || lower.endsWith("edat")) {
        normalizedValues[field] = typeof value === "string" && value.trim() ? moment(value) : undefined;
      } else if (/id$/i.test(lower) && lookupData[field]) {
        normalizedValues[field] = Number(value);
      } else if (/is|active|enabled/i.test(lower)) {
        normalizedValues[field] = Boolean(value);
      } else {
        normalizedValues[field] = value;
      }
    });

    let normalizedLines: any[] = [];

    if (isMaster && effectiveDetailConfig) {
      try {
        const lines = await fetchLineItems(record[fields[0]]);
        normalizedLines = (Array.isArray(lines) ? lines : []).map((line: any) => {
          const normalizedLine: any = {};
          effectiveDetailConfig.fields.forEach((f) => {
            let val = line[f];
            if (val !== null && val !== undefined) {
              if (f.toLowerCase().endsWith("id") && typeof val === "string") {
                normalizedLine[f] = Number(val);
              } else if (/date|year|month|edat/i.test(f) && typeof val === "string") {
                normalizedLine[f] = moment(val);
              } else {
                normalizedLine[f] = val;
              }
            }
          });
          return normalizedLine;
        });
      } catch (err) {
        console.error("Failed to load line items", err);
        normalizedLines = [];
      }
    }

    normalizedValues.lineItems = normalizedLines;
    setLineItemRows(normalizedLines);
    form.setFieldsValue(normalizedValues);

    setEditingItem(record);
    setModalVisible(true);
  };

  // ==================== Calculations ====================
  const calculateTotals = useCallback(() => {
    const lines: any[] = form.getFieldValue("lineItems") || [];
    let subtotal = 0;
    lines.forEach((line: any, index: number) => {
      const qty = Number(line[qtyField] || 0);
      const price = Number(line[priceField] || 0);
      const lineTotal = qty * price;
      subtotal += lineTotal;
      if (lineTotalField) {
        form.setFieldValue(["lineItems", index, lineTotalField], lineTotal);
      }
    });
    let tax = 0;
    if (taxField) {
      tax = lines.reduce((sum: number, line: any) => {
        const lineSub = Number(line[qtyField] || 0) * Number(line[priceField] || 0);
        return sum + lineSub * (Number(line[taxField] || 0) / 100);
      }, 0);
    }
    const grandTotal = subtotal + tax;
    form.setFieldsValue({ subtotal, taxAmount: tax, grandTotal });

    let newWarning = "";
    const currentValues = form.getFieldsValue(true);
    const possibleLimitFields = ["totalCredit", "totalDebit", "totalAmount", "budget", "maxAmount"];
    const limitField = possibleLimitFields.find((lf) => fields.includes(lf));
    if (limitField) {
      const limit = Number(currentValues[limitField] || 0);
      if (grandTotal > limit) {
        newWarning = `Warning: Grand total (${grandTotal.toLocaleString()}) exceeds ${limitField} (${limit.toLocaleString()})`;
      }
    }
    setWarning(newWarning);
  }, [form, qtyField, priceField, lineTotalField, taxField, fields]);

  const handleValuesChange = useCallback(() => {
    if (isMaster) calculateTotals();
  }, [isMaster, calculateTotals]);

  // ==================== Save ====================
  const handleSave = async (values: Record<string, any>) => {
    fields.forEach((f) => {
      if (values[f] && moment.isMoment(values[f])) {
        values[f] = values[f].format("YYYY-MM-DD");
      }
      if (!editingItem && f.toLowerCase().includes("by")) {
        values[f] = loggedInUserId;
      }
      if (!editingItem && f.toLowerCase().includes("number")) {
        values[f] = generateNumberField(f);
      }
    });

    let parentId = editingItem ? editingItem[fields[0]] : null;

    try {
      // Save header
      let url = `${apiBaseUrl}/${resourceName}`;
      let method = "POST";
      if (editingItem) {
        method = "PUT";
        url += `/${parentId}`;
      }

      const headerPayload = { ...values };
      delete headerPayload.lineItems;

      const headerRes = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(headerPayload),
      });

      if (!headerRes.ok) throw new Error(await headerRes.text().catch(() => "Header save failed"));

      if (!editingItem) {
        const savedHeader = await headerRes.json();
        parentId = savedHeader[fields[0]];
      }

      message.success("Header saved");

      // Save line items
      if (isMaster && effectiveDetailConfig && parentId) {
        const lines = form.getFieldValue("lineItems") || [];

        for (const line of lines) {
          const normalizedLine: any = {};
          Object.keys(line).forEach((key) => {
            normalizedLine[toCamelCase(key)] = line[key];
          });
          normalizedLine[toCamelCase(effectiveDetailConfig.foreignKey)] = parentId;

          effectiveDetailConfig.fields.forEach((f) => {
            const camelKey = toCamelCase(f);
            if (normalizedLine[camelKey] && moment.isMoment(normalizedLine[camelKey])) {
              normalizedLine[camelKey] = normalizedLine[camelKey].format("YYYY-MM-DD");
            }
          });

          const lineRes = await fetch(`${apiBaseUrl}/${effectiveDetailConfig.resourceName}`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(normalizedLine),
          });

          if (!lineRes.ok) {
            console.error("Line save failed:", await lineRes.text());
          }
        }
        message.success("Line items saved");
      }

      closeModal();
      fetchData();
    } catch (err: any) {
      message.error(err.message || "Save failed");
    }
  };

  const handleDelete = async (record: Record<string, any>) => {
    const rowKey = getRowKey(record);
    try {
      const res = await fetch(`${apiBaseUrl}/${resourceName}/${rowKey}`, { method: "DELETE" });
      if (!res.ok) throw new Error("delete failed");
      message.success("Deleted successfully");
    } catch (err) {
      message.error("Delete failed");
    } finally {
      fetchData();
    }
  };

  const closeModal = () => {
    setModalVisible(false);
    setEditingItem(null);
    form.resetFields();
    setLineItemRows([]);
    setWarning("");
  };

  const getRowKey = (record: Record<string, any>) => {
    const idField = fields.find((f) => f.toLowerCase().endsWith("id"));
    return idField && record[idField] !== undefined ? String(record[idField]) : JSON.stringify(record);
  };

  // ==================== Render Form Items ====================
  const renderFormItemComponent = (f: string, _isLineItem = false) => {
    const lower = f.toLowerCase();
    const isExcluded = excludedLookupFields.some((ex) => lower === ex || lower.endsWith(ex));
    const isByField = lower.endsWith("by") || lower.endsWith("edby");
    const isLookup = (lower.endsWith("id") || lower.endsWith("currency") || lower.endsWith("company") || lower.endsWith("accounttype") || lower.endsWith("status") || lower.endsWith("entitytype")) && !isExcluded && !isByField;
    const isBoolean = /is|active|enabled/i.test(f);
    const isDate = lower.includes("date") || lower.endsWith("edat");
    const isYear = /year/i.test(f);
    const isMonth = /month/i.test(f);
    const isNumber = /amount|price|total|qty|quantity|rate|balance/i.test(f);

    if (isLookup) {
      const options = lookupData[f]?.map((i) => ({ label: i.label, value: i.id })) || [];
      return (
        <Select options={options} showSearch optionFilterProp="label" allowClear placeholder={`Select ${f}`} />
      );
    }
    if (isByField && lookupData[f]) {
      const options = lookupData[f]?.map((i) => ({ label: i.label, value: i.id })) || [];
      return <Select options={options} disabled />;
    }
    if (isBoolean) return <Checkbox />;
    if (isDate) return <DatePicker style={{ width: "100%" }} />;
    if (isYear) return <DatePicker picker="year" style={{ width: "100%" }} />;
    if (isMonth) return <DatePicker picker="month" style={{ width: "100%" }} />;
    if (isNumber) {
      return (
        <InputNumber
          style={{ width: "100%" }}
          formatter={(value) => `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ",")}
          parser={(value) => value?.replace(/,/g, "") || ""}
        />
      );
    }
    return <Input placeholder={`Enter ${f}`} />;
  };

  const renderFormItem = (f: string, idx: number, _isLineItem = false) => {
    if (!editingItem && idx === 0 && !_isLineItem) return null;
    if (editingItem && idx === 0 && !_isLineItem) {
      return (
        <Form.Item key={f} label={f} name={f}>
          <Input disabled />
        </Form.Item>
      );
    }

    const lower = f.toLowerCase();
    const isLookup = (lower.endsWith("id") || lower.endsWith("currency") || lower.endsWith("company") || lower.endsWith("accounttype") || lower.endsWith("status") || lower.endsWith("entitytype")) && !excludedLookupFields.some(ex => lower === ex || lower.endsWith(ex)) && !lower.endsWith("by") && !lower.endsWith("edby");

    const label = isLookup && !_isLineItem ? (
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8 }}>
        <span>{f}</span>
        <Button size="small" onClick={() => openAddLookup(f)}>+ Add</Button>
      </div>
    ) : f;

    if (_isLineItem) return renderFormItemComponent(f, true);

    if (lower.includes("number") && !editingItem) {
      return (
        <Form.Item key={f} label={f}>
          <Form.Item name={f} noStyle>
            <Input style={{ width: "calc(100% - 110px)" }} placeholder={`Enter ${f}`} />
          </Form.Item>
          <Button
            type="default"
            style={{ width: 110 }}
            onClick={() => {
              const prefix = (f.match(/[A-Z]/g) || []).join("") || "XX";
              const dateStr = moment().format("YYYYMMDD");
              const rand10 = Math.floor(Math.random() * 1_000_000_0000).toString().padStart(10, "0");
              form.setFieldValue(f, `${prefix}${dateStr}${rand10}`);
            }}
          >
            Regenerate
          </Button>
        </Form.Item>
      );
    }

    return (
      <Form.Item key={f} label={label} name={f}>
        {renderFormItemComponent(f)}
      </Form.Item>
    );
  };
  // ==================== Manage Lines Modal ====================
  const handleManageLines = async (record: Record<string, any>) => {
    setCurrentMaster(record);
    setLineItemRows([]); // clear previous

    let normalizedLines: any[] = [];

    if (effectiveDetailConfig) {
      try {
        const lines = await fetchLineItems(record[fields[0]]);
        normalizedLines = (Array.isArray(lines) ? lines : []).map((line: any) => {
          const normalizedLine: any = {};
          effectiveDetailConfig.fields.forEach((f) => {
            let val = line[f];
            if (val !== null && val !== undefined) {
              if (f.toLowerCase().endsWith("id") && typeof val === "string") {
                normalizedLine[f] = Number(val);
              } else if (/date|year|month|edat/i.test(f) && typeof val === "string") {
                normalizedLine[f] = moment(val);
              } else {
                normalizedLine[f] = val;
              }
            }
          });
          return normalizedLine;
        });
      } catch (err) {
        console.error("Failed to load line items for manage modal", err);
        normalizedLines = [];
      }
    }

    setLineItemRows(normalizedLines);
    lineForm.setFieldsValue({ lineItems: normalizedLines });
    setLineModalVisible(true);
  };
    const handleLineValuesChange = useCallback(() => {
      if (isMaster) {
        calculateLineTotals();
      }
    }, [isMaster, calculateLineTotals]);
  // ==================== + Add Lookup Item ====================
  const openAddLookup = (field: string) => {
   setLookupModalField(field);
  
    setLookupModalVisible(true); //alert("Saveing");
  };
  //  const calculateTotals = useCallback(() => {
  //     const lines: any[] = form.getFieldValue("lineItems") || [];
  //     let subtotal = 0;
  //     lines.forEach((line: any, index: number) => {
  //       const qty = Number(line[qtyField] || 0);
  //       const price = Number(line[priceField] || 0);
  //       const lineTotal = qty * price;
  //       subtotal += lineTotal;
  //       if (lineTotalField) {
  //         form.setFieldValue(["lineItems", index, lineTotalField], lineTotal);
  //       }
  //     });
  //     let tax = 0;
  //     if (taxField) {
  //       tax = lines.reduce((sum: number, line: any) => {
  //         const lineSub = Number(line[qtyField] || 0) * Number(line[priceField] || 0);
  //         return sum + lineSub * (Number(line[taxField] || 0) / 100);
  //       }, 0);
  //     }
  //     const grandTotal = subtotal + tax;
  //     form.setFieldsValue({
  //       subtotal,
  //       taxAmount: tax,
  //       grandTotal,
  //     });
  //     // Check for exceeding limits
  //     let newWarning = "";
  //     const currentValues = form.getFieldsValue(true);
  //     const possibleLimitFields = ["totalCredit", "totalDebit", "totalAmount", "budget", "maxAmount"];
  //     const limitField = possibleLimitFields.find((lf) => fields.includes(lf));
  //     if (limitField) {
  //       const limit = Number(currentValues[limitField] || 0);
  //       if (grandTotal > limit) {
  //         newWarning = `Warning: Grand total (${grandTotal.toLocaleString()}) exceeds ${limitField} (${limit.toLocaleString()})`;
  //       }
  //     }
  //     setWarning(newWarning);
  //   }, [form, qtyField, priceField, lineTotalField, taxField, fields]);
    
  const handleAddNewLookup = async () => {
    if (!lookupModalField) return;
   
    try {
      const values = await lookupForm.validateFields();
      const endpoint = lookupEndpointFromField(lookupModalField);
      const res = await fetch(`${apiBaseUrl}/${endpoint}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(values),
      });
      if (!res.ok) throw new Error("create lookup failed");
      message.success("Added successfully");
      setLookupModalVisible(false);
      lookupForm.resetFields();
      await fetchLookups();
    } catch (err) {
      message.error("Failed to add lookup item" + err);
    }
  };
  const handleSaveLines = async () => {
    try {
      const values = await lineForm.validateFields();
      const lines = values.lineItems || [];

      const parentId = currentMaster![fields[0]];

      // Optional: delete old lines first (safe way)
      // You can skip this if you don't mind duplicates during dev
      // Or implement proper delete-by-ID if needed

      for (const line of lines) {
        const normalizedLine: any = {};
        Object.keys(line).forEach((key) => {
          normalizedLine[toCamelCase(key)] = line[key];
        });
        normalizedLine[toCamelCase(effectiveDetailConfig!.foreignKey)] = parentId;

        effectiveDetailConfig!.fields.forEach((f) => {
          const camelKey = toCamelCase(f);
          if (normalizedLine[camelKey] && moment.isMoment(normalizedLine[camelKey])) {
            normalizedLine[camelKey] = normalizedLine[camelKey].format("YYYY-MM-DD");
          }
        });

        await fetch(`${apiBaseUrl}/${effectiveDetailConfig!.resourceName}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(normalizedLine),
        });
      }

      message.success("Line items saved successfully");
      setLineModalVisible(false);
      lineForm.resetFields();
      setCurrentMaster(null);
      setLineItemRows([]);
      fetchData();
    } catch (err) {
      message.error("Failed to save line items");
    }
  };
  // ==================== Table Columns ====================
  const handleTableChange = (_pagination: any, _filters: any, sorter: any) => {
    setSortedInfo(sorter);
  };

  const columns: ColumnsType<Record<string, any>> = [
    {
      title: "Actions",
      key: "actions",
      fixed: "left",
      width: 140,
      render: (_: any, record: any) => (
        <Space>
          <Button type="link" onClick={() => handleEdit(record)}>Edit</Button>
          {isMaster && <Button type="link" onClick={() => handleManageLines(record)}>Lines</Button>}
          <Button type="link" danger onClick={() => handleDelete(record)}>Delete</Button>
        </Space>
      ),
    },
    ...fields.slice(0, showAllFields ? fields.length : 6).map((f) => {
      const isNumberField = /amount|price|total|qty|quantity|rate|balance|number/i.test(f.toLowerCase());
      const isDateField = /date|year|month|edat/i.test(f.toLowerCase());
      return {
        title: f,
        dataIndex: f,
        key: f,
        align: isNumberField ? ("right" as const) : ("left" as const),
        sorter: isDateField
          ? (a: any, b: any) => (a[f] ? new Date(a[f]).getTime() : 0) - (b[f] ? new Date(b[f]).getTime() : 0)
          : isNumberField
          ? (a: any, b: any) => (a[f] || 0) - (b[f] || 0)
          : (a: any, b: any) => String(a[f] || "").localeCompare(String(b[f] || "")),
        sortOrder: sortedInfo.columnKey === f ? sortedInfo.order : undefined,
        ...getColumnSearchProps(f),
        render: (value: any) => {
          if (f.toLowerCase().endsWith("id") && lookupData[f]?.length) {
            const item = lookupData[f].find((i) => Number(i.id) === Number(value));
            return item ? item.label : value;
          }
          if (isNumberField && !isNaN(Number(value))) {
            return <div style={{ textAlign: "right" }}>{Number(value).toLocaleString()}</div>;
          }
          if (isDateField && value) {
            return moment(value).format(f.toLowerCase().includes("year") ? "YYYY" : "YYYY-MM-DD");
          }
          return value ?? "-";
        },
      };
    }),
  ];

  const filteredData = data.filter((item) =>
    fields.some((field) => {
      const value = item[field];
      return value != null && String(value).toLowerCase().includes(globalSearch.toLowerCase());
    })
  );

  // ==================== JSX ====================
  return (
    <div style={{ padding: 20 }}>
      <Row style={{ marginBottom: 16 }} gutter={8} justify="space-between">
        <Col>
          <Button type="primary" onClick={() => {
            setEditingItem(null);
            form.resetFields();
            setLineItemRows([]);
            setModalVisible(true);
          }}>
            Add {resourceName}
          </Button>
        </Col>
        <Col flex="auto" style={{ textAlign: 'right' }}>
          <Input
            placeholder="Search all records..."
            prefix={<SearchOutlined />}
            allowClear
            value={globalSearch}
            onChange={(e) => setGlobalSearch(e.target.value)}
            style={{ width: 300 }}
          />
        </Col>
        <Col>
          <Button onClick={() => setShowAllFields((p) => !p)}>
            {showAllFields ? "Show Less" : "Show More Fields"}
          </Button>
        </Col>
        <Col>
          <input type="color" value={rowColor} onChange={(e) => setRowColor(e.target.value)} title="Select Row Color" style={{ width: 40, height: 32, border: "none" }} />
        </Col>
      </Row>

      <Table
        dataSource={globalSearch ? filteredData : data}
        columns={columns}
        rowKey={getRowKey}
        loading={loading}
        scroll={{ x: "max-content" }}
        onChange={handleTableChange}
        rowClassName={(_record, index) => (index % 2 === 0 ? "even-row" : "odd-row")}
        style={{ "--row-bg-even": rowColor, "--row-bg-odd": shadeColor(rowColor, -0.05) } as any}
        locale={{ emptyText: `No ${resourceName} found` }}
        onRow={(record) => ({ onDoubleClick: () => handleEdit(record) })}
      />

      <Modal
        title={editingItem ? `Edit ${resourceName}` : `Add ${resourceName}`}
        open={modalVisible}
        width={1300}
        onCancel={closeModal}
        onOk={() => form.submit()}
        destroyOnClose
      >
        <Form form={form} onFinish={handleSave} layout="vertical" onValuesChange={handleValuesChange}>
          <Row gutter={16}>
            {fields.map((f, idx) => (
              <Col span={8} key={f}>
                {renderFormItem(f, idx)}
              </Col>
            ))}
          </Row>

          {isMaster && effectiveDetailConfig && (
            <>
              <Divider orientation="left">Line Items</Divider>

              <Form.List name="lineItems">
                {(fields, { add, remove }) => {
                  useEffect(() => {
                    const currentData = form.getFieldValue("lineItems") || [];
                    const diff = currentData.length - fields.length;
                    if (diff > 0) {
                      for (let i = 0; i < diff; i++) add();
                    } else if (diff < 0) {
                      for (let i = 0; i < -diff; i++) {
                        remove(fields.length - 1);
                      }
                    }
                  }, [lineItemRows.length]);

                  return (
                    <>
                      <Table
                        dataSource={lineItemRows}
                        pagination={false}
                        size="small"
                        rowKey={(_, index) => index ?? 0}
                        columns={[
                          ...effectiveDetailConfig.fields.map((f) => ({
                            title: f,
                            width: 200,
                            render: (value: any, _: any, index: number) => (
                              <Form.Item name={[index, f]} noStyle initialValue={value}>
                                {renderFormItemComponent(f, true)}
                              </Form.Item>
                            ),
                          })),
                          {
                            title: "Action",
                            width: 100,
                            render: (_, __, index) => (
                              <Button
                                danger
                                size="small"
                                onClick={() => {
                                  remove(index);
                                  setLineItemRows((prev) => prev.filter((_, i) => i !== index));
                                }}
                              >
                                Delete
                              </Button>
                            ),
                          },
                        ]}
                      />

                      <Button
                        type="dashed"
                        onClick={() => {
                          const defaultLine = { [qtyField]: 1, [priceField]: 0 };
                          add(defaultLine);
                          setLineItemRows((prev) => [...prev, defaultLine]);
                        }}
                        block
                        icon={<PlusOutlined />}
                        style={{ marginTop: 16 }}
                      >
                        Add Line Item
                      </Button>
                    </>
                  );
                }}
              </Form.List>

              {warning && <Alert message={warning} type="warning" showIcon style={{ marginTop: 16 }} />}
            </>
          )}
        </Form>
      </Modal>
      {/* Manage Lines Modal */}
      <Modal
        title={`Manage Line Items - ${resourceName} #${currentMaster ? currentMaster[fields.find(f => f.toLowerCase().includes("number")) || fields[0]] : ""}`}
        open={lineModalVisible}
        width={1300}
        onCancel={() => {
          setLineModalVisible(false);
          lineForm.resetFields();
          setCurrentMaster(null);
          setLineItemRows([]);
          setLineWarning("");
        }}
        onOk={() => lineForm.submit()}
        destroyOnClose
      >
        <Form form={lineForm} onFinish={handleSaveLines} layout="vertical">
          <Form.List name="lineItems">
            {(fields, { add, remove }) => {
              useEffect(() => {
                const currentData = lineForm.getFieldValue("lineItems") || [];
                const diff = currentData.length - fields.length;
                if (diff > 0) {
                  for (let i = 0; i < diff; i++) add();
                } else if (diff < 0) {
                  for (let i = 0; i < -diff; i++) {
                    remove(fields.length - 1);
                  }
                }
              }, [lineItemRows.length]);

              return (
                <>
                  <Table
                    dataSource={lineItemRows}
                    pagination={false}
                    size="small"
                    rowKey={(_, index) => index ?? 0}
                    columns={[
                      ...effectiveDetailConfig!.fields.map((f) => ({
                        title: f,
                        width: 200,
                        render: (value: any, _: any, index: number) => (
                          <Form.Item name={[index, f]} noStyle initialValue={value}>
                            {renderFormItemComponent(f, true)}
                          </Form.Item>
                        ),
                      })),
                      {
                        title: "Action",
                        width: 100,
                        render: (_, __, index) => (
                          <Button
                            danger
                            size="small"
                            onClick={() => {
                              remove(index);
                              setLineItemRows(prev => prev.filter((_, i) => i !== index));
                            }}
                          >
                            Delete
                          </Button>
                        ),
                      },
                    ]}
                  />

                  <Button
                    type="dashed"
                    onClick={() => {
                      const defaultLine = { [qtyField]: 1, [priceField]: 0 };
                      add(defaultLine);
                      setLineItemRows(prev => [...prev, defaultLine]);
                    }}
                    block
                    icon={<PlusOutlined />}
                    style={{ marginTop: 16 }}
                  >
                    Add Line Item
                  </Button>
                </>
              );
            }}
          </Form.List>
          {lineWarning && <Alert message={lineWarning} type="warning" showIcon style={{ marginTop: 16 }} />}
        </Form>
      </Modal>
            {/* Line Items Modal */}
            <Modal
              title={`Manage Line Items for ${resourceName} #${currentMaster ? currentMaster[fields.find((f) => f.toLowerCase().includes("number")) || fields[0]] : ""}`}
              open={lineModalVisible}
              width={1300}
              onCancel={() => {
                setLineModalVisible(false);
                lineForm.resetFields();
                setCurrentMaster(null);
                setLineWarning("");
              }}
              onOk={() => lineForm.submit()}
              destroyOnHidden
            >
              <Form form={lineForm} onFinish={handleSaveLines} layout="vertical" onValuesChange={handleLineValuesChange}>
                <Form.List name="lineItems">
                  {(lineFields, { add, remove }) => (
                    <>
                      <Table
                        dataSource={lineFields}
                        pagination={false}
                        size="small"
                        rowKey={(field) => field.key}
                        columns={[
                          ...effectiveDetailConfig!.fields.map((f) => ({
                            title: f,
                            width: 200,
                            render: (_: any, __: any, index: number) => (
                              <Form.Item name={[lineFields[index].name, f]} noStyle>
                                {renderFormItemComponent(f, true)}
                              </Form.Item>
                            ),
                          })),
                          {
                            title: "Action",
                            width: 100,
                            render: (_: any, __: any, index: number) => (
                              <Button danger size="small" onClick={() => remove(index)}>
                                Delete
                              </Button>
                            ),
                          },
                        ]}
                      />
                      <Button
                        type="dashed"
                        onClick={() => add({ [qtyField]: 1, [priceField]: 0 })}
                        block
                        icon={<PlusOutlined />}
                        style={{ marginTop: 16 }}
                      >
                        Add Line Item
                      </Button>
                    </>
                  )}
                </Form.List>
                {lineWarning && <Alert message={lineWarning} type="warning" showIcon style={{ marginTop: 16 }} />}
              </Form>
            </Modal>

      <Modal
        title={`Add New ${lookupModalField}`}
        open={lookupModalVisible}
        width={900}
        onCancel={() => {
          setLookupModalVisible(false);
          lookupForm.resetFields();
          setLookupModalField(null);
        }}
        onOk={() => lookupForm.submit()}
        destroyOnClose
      >
        <Form
          form={lookupForm}
          layout="vertical"
          onFinish={handleAddNewLookup}
        >
          <Row gutter={16}>
            {lookupModalField &&
              (fieldsForLookup[lookupModalField] || [])
                .filter((field: string, index: number, array: string[]) => {
                  // If there are no fields, don't filter
                  if (array.length === 0) return true;
                  const lowerField = field.toLowerCase();
                  const isFirstField = index === 0;
                  // Derive expected table name from the lookup field (e.g., "CustomerId" → "customer")
                  const lookupFieldLower = lookupModalField!.toLowerCase();
                  let expectedTableName = lookupEndpointFromField(lookupModalField!); // e.g., "customers"
                 
                  // Fallback: extract from field name (remove "Id" and pluralize rules)
                  if (lookupFieldLower.endsWith("id")) {
                    let base = lookupModalField!.slice(0, -2); // remove "Id"
                    // Simple plural to singular guess
                    if (base.endsWith("ies")) base = base.slice(0, -3) + "y";
                    else if (base.endsWith("s")) base = base.slice(0, -1);
                    expectedTableName = base.toLowerCase();
                  }
                  const expectedPkPattern = new RegExp(`^${expectedTableName}id$`, "i");
                  // Hide only if:
                  // - It's the first field AND
                  // - Its name matches the expected primary key pattern (e.g., CustomerId for customers)
                  const isPrimaryKey = isFirstField && expectedPkPattern.test(field);
                  return !isPrimaryKey;
                })
                .map((field: string) => (
                  <Col span={8} key={field}>
                    <Form.Item
                      label={field}
                      name={field}
                      rules={[
                        {
                          required: /name|code|title|description|label/i.test(field),
                          message: `${field} is required`,
                        },
                      ]}
                    >
                      {renderFormItemComponent(field)}
                    </Form.Item>
                  </Col>
                ))}
          </Row>
        </Form>
      </Modal>
      {/* Other modals (Manage Lines, Lookup) remain unchanged or can be updated similarly if needed */}

      <style>{`
        .even-row { background-color: var(--row-bg-even, #ffffff); }
        .odd-row { background-color: var(--row-bg-odd, #f9f9f9); }
      `}</style>
    </div>
  );
};

export default GenericResourcePage;