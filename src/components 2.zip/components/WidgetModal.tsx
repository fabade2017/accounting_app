// src/components/WidgetModal.tsx
import { Modal, Form, Input, InputNumber, Button, Select, message, Row, Col } from "antd";
import { useEffect, useState } from "react";

const { Option } = Select;

interface Widget {
  DashboardWidgetId: number;
  DashboardId: number;
  WidgetId: number;
  WidgetName?: string;
  Type?: string;
  Settings: string;
  PositionX: number;
  PositionY: number;
  Width: number;
  Height: number;
}

interface ProcParam {
  name: string;
  type: "string" | "number";
  required: boolean;
}

interface Procedure {
  ProcedureId: number;
  ProcedureName: string;
}

interface WidgetModalProps {
  modalVisible: boolean;
  setModalVisible: (v: boolean) => void;
  editingWidget: Widget | null;
  setEditingWidget: (w: Widget | null) => void;
  form: any;
  procParamsDef: ProcParam[];
  setProcParamsDef: (v: ProcParam[]) => void;
  previewData: any[];
  setPreviewData: (v: any[]) => void;
  selectedProc: number | null;
  setSelectedProc: (v: number | null) => void;
  procedures: Procedure[]; // array of { ProcedureId, ProcedureName }
  callProcAndGetResultSets: (procName: string, params: Record<string, any>) => Promise<any[]>;
  onSave: (widget: Widget) => void;
}

export const WidgetModal = ({
  modalVisible,
  setModalVisible,
  editingWidget,
  setEditingWidget,
  form,
  procParamsDef,
  setProcParamsDef,
  previewData,
  setPreviewData,
  selectedProc,
  setSelectedProc,
  procedures,
  callProcAndGetResultSets,
  onSave
}: WidgetModalProps) => {
  const [loadingPreview, setLoadingPreview] = useState(false);
interface ProcParamRaw {
  Id: number;
  ProcedureName: string;
  ParameterName: string;
  ParameterType: string;
  IsRequired: boolean;
}
  useEffect(() => {
    if (modalVisible && selectedProc !== null) {
      fetchProcParams(selectedProc);
    }
  }, [modalVisible, selectedProc]);

  // Fetch params by procedure ID
  const fetchProcParams = async (procId: number | string) => {
    try {
      if (!procId) return;
//console.log(procId);
    //   const res = await fetch(`http://localhost:5017/api/proceduremetadata/${procId}`);
 const res = await fetch(`http://localhost:5017/api/procedures/sp_FetchProcedureMetadata`, {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
  },
  body: JSON.stringify({ ProcedureName: procId }), // sending procId as ProcedureName
});
// if (!res.ok) throw new Error(`Failed to fetch params: ${res.status}`);
// const data = await res.json();

      if (!res.ok) throw new Error(`Failed to fetch params: ${res.status}`);

    //   const data: {
    //     Id: number;
    //     ProcedureName: string;
    //     Parameters: Array<{ ParameterName: string; ParameterType: string; IsRequired: boolean }>;
    //     ParameterName: string;
    //     ParameterType: string;
    //     IsRequired: boolean ;
    //   } = await res.json();
//console.log("Procedure params:ok", JSON.stringify(data));
 const data: ProcParamRaw[] = await res.json(); // <-- data is an array

    const paramsDef: ProcParam[] = data.map(p => ({
      name: p.ParameterName.replace(/^@/, ""),
      type: ["int", "decimal", "bigint", "float", "numeric"].includes(p.ParameterType.toLowerCase())
        ? "number"
        : "string",
      required: p.IsRequired
    }));


console.log("Procedure params:",JSON.stringify(paramsDef) );
      setProcParamsDef(paramsDef);

      // Initialize form: set procId and procName (string) and blank params
         const initialValues: Record<string, any> = {};
      paramsDef.forEach(p => initialValues[p.name] = '');
   form.setFieldsValue({ proc: data[0]?.ProcedureName || "", params: initialValues });

    } catch (err) {
      console.error("Failed to fetch procedure params", err);
      message.error("Failed to fetch procedure parameters");
      setProcParamsDef([]);
    }
  };

  // Preview (resolve procName from procId)
  const handlePreview = async () => {
    try {
      const values = form.getFieldsValue();
      const params = values.params || {};
      const procId = values.procId;
      // resolve procName from procedures list first, else use procName field
      const procName = procedures.find(p => p.ProcedureId === Number(procId))?.ProcedureName || values.procName;
      if (!procName) {
        message.error("Procedure name not available for preview");
        return;
      }
      setLoadingPreview(true);
      const data = await callProcAndGetResultSets(procName, params);
      setPreviewData(data);
    } catch (err) {
      console.error(err);
      message.error("Failed to fetch preview data");
    } finally {
      setLoadingPreview(false);
    }
  };

  const handleOk = async () => {
    try {
      const values = form.getFieldsValue();
      const procId = values.procId;
      const procName = procedures.find(p => p.ProcedureId === Number(procId))?.ProcedureName || values.procName;
      if (!procName) throw new Error("Procedure not selected");

      const widgetSettings = { proc: procName, procId: Number(procId), params: values.params || {}, chartType: values.chartType };

      let newWidget: Widget;
      if (editingWidget) {
        newWidget = { ...editingWidget, Settings: JSON.stringify(widgetSettings) };
        onSave(newWidget);
      } else {
        newWidget = {
          DashboardWidgetId: 0,
          DashboardId: 2,
          WidgetId: 0,
          WidgetName: values.WidgetName || "New Widget",
          Type: "Chart",
          Settings: JSON.stringify(widgetSettings),
          PositionX: 0,
          PositionY: 0,
          Width: 2,
          Height: 2
        };

        const res = await fetch(`http://localhost:5017/api/dashboardwidgets`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(newWidget)
        });
        const saved = await res.json();
        onSave(saved);
      }

      message.success("Widget saved!");
      setModalVisible(false);
      setEditingWidget(null);
      form.resetFields();
    } catch (err) {
      console.error(err);
      message.error("Failed to save widget");
    }
  };

  return (
    <Modal
      title={editingWidget ? "Edit Widget" : "Add Widget"}
      open={modalVisible}
      onCancel={() => { setModalVisible(false); form.resetFields(); setEditingWidget(null); }}
      onOk={handleOk}
      width={600}
      okText="Save"
    >
      <Form form={form} layout="vertical">
        <Form.Item label="Widget Name" name="WidgetName" rules={[{ required: true, message: "Enter widget name" }]}>
          <Input />
        </Form.Item>

        {/* store procId (number) in the form; procName is also stored for clarity */}
        <Form.Item label="Procedure" required>
          <Row gutter={8}>
            <Col flex="auto">
              <Form.Item noStyle name="procId" rules={[{ required: true, message: "Select procedure" }]}>
                <Select
                  placeholder="Select a procedure"
                  onChange={(v: number) => {
                    const id = Number(v);
                    setSelectedProc(id);
                    // fetch params for this id
                    fetchProcParams(id);
                  }}
                >
                  {procedures.map(p => (
                    <Option key={p.ProcedureId} value={p.ProcedureId}>
                      {p.ProcedureName.replace(/^sp_/i, "")}
                    </Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
            <Col flex="120px">
              {/* visible procName field (read-only) to show actual name */}
              <Form.Item noStyle name="procName">
                <Input readOnly placeholder="Procedure name" />
              </Form.Item>
            </Col>
          </Row>
        </Form.Item>

        {procParamsDef.length > 0 && (
          <div>
            <h4>Parameters:</h4>
            {procParamsDef.map(p => (
              <Form.Item
                key={p.name}
                label={p.name}
                name={['params', p.name]}
                rules={[{ required: p.required, message: `${p.name} is required` }]}
              >
                {p.type === "number" ? <InputNumber style={{ width: "100%" }} /> : <Input />}
              </Form.Item>
            ))}
          </div>
        )}

        <Form.Item label="Chart Type" name="chartType">
          <Select>
            <Option value="bar">Bar</Option>
            <Option value="line">Line</Option>
            <Option value="pie">Pie</Option>
            <Option value="table">Table</Option>
            <Option value="card">Card</Option>
          </Select>
        </Form.Item>

        <Row justify="end" gutter={8}>
          <Col>
            <Button onClick={handlePreview} loading={loadingPreview}>Preview</Button>
          </Col>
        </Row>

        {previewData.length > 0 && (
          <div style={{ marginTop: 16, maxHeight: 200, overflow: "auto" }}>
            <pre>{JSON.stringify(previewData, null, 2)}</pre>
          </div>
        )}
      </Form>
    </Modal>
  );
};
