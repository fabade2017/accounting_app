import { useEffect, useState } from "react";
import {
  Table,
  DatePicker,
  Input,
  Button,
  Form,
  message,
  Select,
  Card,
  Space,
} from "antd";
import type { ColumnType } from "antd/es/table";
import dayjs from "dayjs";
import { Pie, Bar } from "@ant-design/plots";
import { exportToExcel, exportToCSV } from "../utils/export";

type ReportRow = Record<string, any>;

interface GroupedRow {
  Group: string;
  Total: number;
  children: ReportRow[];
  _uniqueKey: string;
}

interface GenericReportPageProps {
  resourceName: string;
  apiBaseUrl: string;
  fields: string[];
}

export const GenericReportPage: React.FC<GenericReportPageProps> = ({
  resourceName,
  apiBaseUrl,
  fields,
}) => {
  const [form] = Form.useForm();

  const [data, setData] = useState<ReportRow[]>([]);
  const [grouped, setGrouped] = useState<GroupedRow[]>([]);
  const [loading, setLoading] = useState(false);

  const [groupBy, setGroupBy] = useState<string | null>(null);
  const [aggCol, setAggCol] = useState<string | null>(null);
  const [aggType, setAggType] = useState<"SUM" | "AVG" | "COUNT">("SUM");
  const [chartType, setChartType] = useState<"none" | "pie" | "bar">("none");

  const endpoint = `${apiBaseUrl}/procedures/${resourceName}`;
type GenericRow = Record<string, unknown>;
  // Set default filter values
  useEffect(() => {
    const defaults: Record<string, any> = {};
    fields.forEach((f) => {
      const key = f.toLowerCase();
      if (key.includes("date")) defaults[f] = dayjs();
      if (key.includes("company")) defaults[f] = 1;
    });
    form.setFieldsValue(defaults);
  }, [fields, form]);

  // Build request body
  const buildRequestBody = () => {
    const values = form.getFieldsValue();
    const body: Record<string, any> = {};
    Object.keys(values).forEach((k) => {
      const v = values[k];
      body[k] = dayjs.isDayjs(v) ? v.format("YYYY-MM-DD") : v;
    });
    return body;
  };

  // Load report data
  const loadReport = async () => {
    setLoading(true);
    setData([]);
    setGrouped([]);
    setGroupBy(null);
    setAggCol(null);
    setAggType("SUM");
    setChartType("none");

    try {
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(buildRequestBody()),
      });

      if (!res.ok) throw new Error("Failed to load report");
      const json = await res.json();
      setData(Array.isArray(json) ? json : []);
    } catch (err: any) {
      message.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  // Grouping & aggregation
  useEffect(() => {
    if (!groupBy || !aggCol || data.length === 0) {
      setGrouped([]);
      return;
    }

    const map: Record<string, { total: number; count: number; children: ReportRow[] }> = {};

    data.forEach((row, idx) => {
      const key = String(row[groupBy] ?? "Unknown");
      if (!map[key]) map[key] = { total: 0, count: 0, children: [] };

      map[key].children.push({ ...row, _uniqueKey: `row-${idx}` });

      const val = Number(row[aggCol]) || 0;
      if (aggType === "SUM") map[key].total += val;
      if (aggType === "AVG") {
        map[key].total += val;
        map[key].count++;
      }
      if (aggType === "COUNT") map[key].count++;
    });

    const result: GroupedRow[] = Object.keys(map).map((k, i) => {
      const e = map[k];
      const total =
        aggType === "AVG"
          ? e.total / (e.count || 1)
          : aggType === "COUNT"
          ? e.count
          : e.total;

      return {
        Group: k,
        Total: total,
        children: e.children,
        _uniqueKey: `group-${i}`,
      };
    });

    setGrouped(result);
  }, [data, groupBy, aggCol, aggType]);

  // Columns for table
  const columns: ColumnType<ReportRow>[] =
    data.length > 0
      ? Object.keys(data[0]).map((k) => ({
          title: k,
          dataIndex: k,
          key: k,
          sorter: (a, b) =>
            typeof a[k] === "number" && typeof b[k] === "number"
              ? a[k] - b[k]
              : String(a[k] ?? "").localeCompare(String(b[k] ?? "")),
        }))
      : [];

  // Totals per column for summary
  const getTotals = (rows: ReportRow[]) => {
    const totals: Record<string, number> = {};
    rows.forEach((r) =>
      columns.forEach((c) => {
        if ("dataIndex" in c) {
          const v = Number(r[c.dataIndex as string]) || 0;
          totals[c.dataIndex as string] =
            (totals[c.dataIndex as string] || 0) + v;
        }
      })
    );
    return totals;
  };

  // Chart data
  const chartData = grouped.map((g) => ({ type: g.Group, value: g.Total }));

  // Export data
  const exportData =
    grouped.length > 0
      ? grouped.flatMap((g) => g.children.map((c) => ({ Group: g.Group, ...c })))
      : data;

  return (
    <div>
      <h2>{resourceName.toUpperCase()}</h2>

      {/* FILTER */}
      <Form form={form} layout="inline" onFinish={loadReport}>
        {fields.map((f) => (
          <Form.Item key={f} name={f} label={f}>
            {f.toLowerCase().includes("date") ? <DatePicker /> : <Input />}
          </Form.Item>
        ))}
        <Button type="primary" htmlType="submit" loading={loading}>
          Run Report
        </Button>
      </Form>

      {/* CONTROLS */}
      {data.length > 0 && (
        <Card style={{ marginTop: 16 }}>
          <Space>
            <Select
              placeholder="Group By"
              value={groupBy}
              onChange={setGroupBy}
              allowClear
              style={{ width: 180 }}
            >
              {columns.map((c) => (
                <Select.Option
                  key={String(c.key ?? c.dataIndex)}
                  value={String(c.dataIndex)}
                >
                  {typeof c.title === "function" ? c.title({} as any) : c.title}
                </Select.Option>
              ))}
            </Select>

            <Select
              placeholder="Aggregate Column"
              value={aggCol}
              onChange={setAggCol}
              style={{ width: 180 }}
            >
              {columns.map((c) => (
                <Select.Option
                  key={String(c.key ?? c.dataIndex)}
                  value={String(c.dataIndex)}
                >
                  {typeof c.title === "function" ? c.title({} as any) : c.title}
                </Select.Option>
              ))}
            </Select>

            <Select value={aggType} onChange={setAggType} style={{ width: 120 }}>
              <Select.Option value="SUM">SUM</Select.Option>
              <Select.Option value="AVG">AVG</Select.Option>
              <Select.Option value="COUNT">COUNT</Select.Option>
            </Select>

            <Select
              value={chartType}
              onChange={setChartType}
              style={{ width: 120 }}
            >
              <Select.Option value="none">None</Select.Option>
              <Select.Option value="pie">Pie</Select.Option>
              <Select.Option value="bar">Bar</Select.Option>
            </Select>

            <Button onClick={() => exportToExcel(exportData, resourceName)}>
              Export Excel
            </Button>
            <Button onClick={() => exportToCSV(exportData, resourceName)}>
              Export CSV
            </Button>
          </Space>
        </Card>
      )}

      {/* TABLE */}
      <Table
        style={{ marginTop: 16 }}
        dataSource={grouped.length ? grouped : data}
        columns={
          grouped.length
            ? [
                { title: "Group", dataIndex: "Group", key: "Group" },
                { title: "Total", dataIndex: "Total", key: "Total" },
              ]
            : columns
        }
        expandable={
          grouped.length
            ? {
                rowExpandable: (record) =>
                  Array.isArray(record.children) && record.children.length > 0,
                expandedRowRender: (record, parentIndex) => {
                  // Filter out children with no meaningful data
                 const childrenRows = ((record.children || []) as GenericRow[])
  .filter((r: GenericRow) =>
    r &&
    Object.keys(r).some(
      (k) =>
        k !== "_uniqueKey" &&
        r[k] !== null &&
        r[k] !== undefined &&
        r[k] !== ""
    )
  )
  .map((r: GenericRow, i: number) => ({
    ...r,
    _uniqueKey: `child-${parentIndex}-${i}`,
  }));

                  if (childrenRows.length === 0) return null;

                  const totals = getTotals(childrenRows);

                  return (
                    <Table
                      dataSource={childrenRows}
                      columns={columns}
                      pagination={false}
                      rowKey={(child) => child._uniqueKey}
                      summary={() => (
                        <Table.Summary.Row>
                          {columns.map((c, i) => {
                            if (!("dataIndex" in c)) return null;
                            const val = totals[c.dataIndex as string];
                            return (
                              <Table.Summary.Cell
                                key={`summary-${parentIndex}-${i}`}
                                index={i}
                              >
                                {val != null ? val : 0}
                              </Table.Summary.Cell>
                            );
                          })}
                        </Table.Summary.Row>
                      )}
                    />
                  );
                },
              }
            : undefined
        }
        rowKey={(record) =>
          "_uniqueKey" in record ? record._uniqueKey : JSON.stringify(record)
        }
        loading={loading}
      />

      {/* CHART */}
      {chartType !== "none" && grouped.length > 0 && (
        <Card style={{ marginTop: 16 }}>
          {chartType === "pie" && (
            <Pie data={chartData} angleField="value" colorField="type" radius={0.9} />
          )}
          {chartType === "bar" && (
            <Bar
              data={chartData}
              xField="value"
              yField="type"
              seriesField="type"
              label={{ position: "middle" }}
              tooltip={{ showTitle: true }}
            />
          )}
        </Card>
      )}
    </div>
  );
};

// import { useEffect, useState } from "react";
          // import {
          //   Table,
          //   DatePicker,
          //   Input,
          //   Button,
          //   Form,
          //   message,
          //   Select,
          //   Card,
          //   Space,
          // } from "antd";
          // import type { ColumnType } from "antd/es/table";
          // import dayjs from "dayjs";
          // import { Pie, Bar } from "@ant-design/plots";
          // import { exportToExcel, exportToCSV } from "../utils/export";

          // type ReportRow = Record<string, any>;

          // interface GroupedRow {
          //   Group: string;
          //   Total: number;
          //   children: ReportRow[];
          // }

          // interface GenericReportPageProps {
          //   resourceName: string;
          //   apiBaseUrl: string;
          //   fields: string[];
          // }

          // export const GenericReportPage: React.FC<GenericReportPageProps> = ({
          //   resourceName,
          //   apiBaseUrl,
          //   fields,
          // }) => {
          //   const [form] = Form.useForm();

          //   const [data, setData] = useState<ReportRow[]>([]);
          //   const [grouped, setGrouped] = useState<GroupedRow[]>([]);
          //   const [loading, setLoading] = useState(false);

          //   const [groupBy, setGroupBy] = useState<string | null>(null);
          //   const [aggCol, setAggCol] = useState<string | null>(null);
          //   const [aggType, setAggType] = useState<"SUM" | "AVG" | "COUNT">("SUM");
          //   const [chartType, setChartType] = useState<"none" | "pie" | "bar">("none");

          //   const endpoint = `${apiBaseUrl}/procedures/${resourceName}`;

          //   // Set default filter values
          //   useEffect(() => {
          //     const defaults: Record<string, any> = {};
          //     fields.forEach((f) => {
          //       const key = f.toLowerCase();
          //       if (key.includes("date")) defaults[f] = dayjs();
          //       if (key.includes("company")) defaults[f] = 1;
          //     });
          //     form.setFieldsValue(defaults);
          //   }, [fields, form]);

          //   const buildRequestBody = () => {
          //     const values = form.getFieldsValue();
          //     const body: Record<string, any> = {};
          //     Object.keys(values).forEach((k) => {
          //       const v = values[k];
          //       body[k] = dayjs.isDayjs(v) ? v.format("YYYY-MM-DD") : v;
          //     });
          //     return body;
          //   };

          //   const loadReport = async () => {
          //     setLoading(true);
          //     setData([]);
          //     setGrouped([]);
          //     setGroupBy(null);
          //     setAggCol(null);
          //     setAggType("SUM");
          //     setChartType("none");

          //     try {
          //       const res = await fetch(endpoint, {
          //         method: "POST",
          //         headers: { "Content-Type": "application/json" },
          //         body: JSON.stringify(buildRequestBody()),
          //       });

          //       if (!res.ok) throw new Error("Failed to load report");
          //       const json = await res.json();
          //       setData(json || []);
          //     } catch (err: any) {
          //       message.error(err.message);
          //     } finally {
          //       setLoading(false);
          //     }
          //   };

          //   // Grouping & aggregation
          //   useEffect(() => {
          //     if (!groupBy || !aggCol || data.length === 0) {
          //       setGrouped([]);
          //       return;
          //     }

          //     const map: Record<string, { total: number; count: number; children: ReportRow[] }> = {};

          //     data.forEach((row) => {
          //       if (!row) return;
          //       const key = String(row[groupBy]);
          //       if (!map[key]) map[key] = { total: 0, count: 0, children: [] };
          //       map[key].children.push(row);

          //       const val = Number(row[aggCol]) || 0;
          //       if (aggType === "SUM") map[key].total += val;
          //       if (aggType === "AVG") {
          //         map[key].total += val;
          //         map[key].count++;
          //       }
          //       if (aggType === "COUNT") map[key].count++;
          //     });

          //     const validGrouped: GroupedRow[] = Object.keys(map)
          //       .map((k) => {
          //         const e = map[k];
          //         const total =
          //           aggType === "AVG"
          //             ? e.total / (e.count || 1)
          //             : aggType === "COUNT"
          //             ? e.count
          //             : e.total;

          //         const validChildren = (e.children || []).filter(
          //           (r) => r && Object.keys(r).length > 0
          //         );
          //         if (validChildren.length === 0) return null;

          //         return { Group: k, Total: total, children: validChildren };
          //       })
          //       .filter(Boolean) as GroupedRow[];

          //     setGrouped(validGrouped);
          //   }, [data, groupBy, aggCol, aggType]);

          //   const columns: ColumnType<ReportRow>[] =
          //     data.length > 0
          //       ? Object.keys(data[0])
          //           .filter((k) => k !== "_rowKey")
          //           .map((k) => ({
          //             title: k,
          //             dataIndex: k,
          //             key: k,
          //             sorter: (a, b) =>
          //               typeof a[k] === "number" && typeof b[k] === "number"
          //                 ? a[k] - b[k]
          //                 : String(a[k]).localeCompare(String(b[k])),
          //           }))
          //       : [];

          //   const chartData = grouped.map((g) => ({ type: g.Group, value: g.Total }));

          //   const getTotals = (rows: ReportRow[]) => {
          //     const totals: Record<string, number> = {};
          //     rows.forEach((r) =>
          //       columns.forEach((c) => {
          //         if ("dataIndex" in c) {
          //           const v = Number(r[c.dataIndex as string]) || 0;
          //           totals[c.dataIndex as string] =
          //             (totals[c.dataIndex as string] || 0) + v;
          //         }
          //       })
          //     );
          //     return totals;
          //   };

          //   const exportData =
          //     grouped.length > 0
          //       ? grouped.flatMap((g) => g.children.map((c) => ({ Group: g.Group, ...c })))
          //       : data;

          //   return (
          //     <div>
          //       <h2>{resourceName.toUpperCase()}</h2>

          //       <Form form={form} layout="inline" onFinish={loadReport}>
          //         {fields.map((f) => (
          //           <Form.Item key={f} name={f} label={f}>
          //             {f.toLowerCase().includes("date") ? <DatePicker /> : <Input />}
          //           </Form.Item>
          //         ))}
          //         <Button type="primary" htmlType="submit" loading={loading}>
          //           Run Report
          //         </Button>
          //       </Form>

          //       {data.length > 0 && (
          //         <Card style={{ marginTop: 16 }}>
          //           <Space>
          //             <Select
          //               placeholder="Group By"
          //               value={groupBy}
          //               onChange={setGroupBy}
          //               allowClear
          //               style={{ width: 180 }}
          //             >
          //               {columns.map((c) => (
          //                 <Select.Option
          //                   key={String(c.key ?? c.dataIndex)}
          //                   value={String(c.dataIndex)}
          //                 >
          //                   {c.title as string}
          //                 </Select.Option>
          //               ))}
          //             </Select>

          //             <Select
          //               placeholder="Aggregate Column"
          //               value={aggCol}
          //               onChange={setAggCol}
          //               style={{ width: 180 }}
          //             >
          //               {columns.map((c) => (
          //                 <Select.Option
          //                   key={String(c.key ?? c.dataIndex)}
          //                   value={String(c.dataIndex)}
          //                 >
          //                   {c.title as string}
          //                 </Select.Option>
          //               ))}
          //             </Select>

          //             <Select value={aggType} onChange={setAggType} style={{ width: 120 }}>
          //               <Select.Option value="SUM">SUM</Select.Option>
          //               <Select.Option value="AVG">AVG</Select.Option>
          //               <Select.Option value="COUNT">COUNT</Select.Option>
          //             </Select>

          //             <Select
          //               value={chartType}
          //               onChange={setChartType}
          //               style={{ width: 120 }}
          //             >
          //               <Select.Option value="none">None</Select.Option>
          //               <Select.Option value="pie">Pie</Select.Option>
          //               <Select.Option value="bar">Bar</Select.Option>
          //             </Select>

          //             <Button onClick={() => exportToExcel(exportData, resourceName)}>
          //               Export Excel
          //             </Button>
          //             <Button onClick={() => exportToCSV(exportData, resourceName)}>
          //               Export CSV
          //             </Button>
          //           </Space>
          //         </Card>
          //       )}

          //       <Table
          //         style={{ marginTop: 16 }}
          //         dataSource={grouped.length ? grouped : data}
          //         columns={
          //           grouped.length
          //             ? [
          //                 { title: "Group", dataIndex: "Group", key: "Group" },
          //                 { title: "Total", dataIndex: "Total", key: "Total" },
          //               ]
          //             : columns
          //         }
          //         expandable={
          //           grouped.length
          //             ? {
          //                 rowExpandable: (record) => (record.children || []).length > 0,
          //                 expandedRowRender: (record, parentIndex) => {
          //                   const childrenRows = (record.children || []).filter(
          //                     (r) => r && Object.keys(r).length > 0
          //                   );
          //                   if (!childrenRows.length) return null;

          //                   const totals = getTotals(childrenRows);

          //                   return (
          //                     <Table
          //                       dataSource={childrenRows}
          //                       columns={columns}
          //                       pagination={false}
          //                       rowKey={(_, i) => `child-${parentIndex}-${i}`}
          //                       summary={() => (
          //                         <Table.Summary.Row>
          //                           {columns.map((c, i) => {
          //                             if (!("dataIndex" in c)) return null;
          //                             const val = totals[c.dataIndex as string];
          //                             return (
          //                               <Table.Summary.Cell
          //                                 key={`summary-${i}`}
          //                                 index={i}
          //                               >
          //                                 {val != null ? val : 0}
          //                               </Table.Summary.Cell>
          //                             );
          //                           })}
          //                         </Table.Summary.Row>
          //                       )}
          //                     />
          //                   );
          //                 },
          //               }
          //             : undefined
          //         }
          //         rowKey={(record, index) =>
          //           grouped.length ? `group-${index}` : index
          //         }
          //         loading={loading}
          //       />

          //       {chartType !== "none" && grouped.length > 0 && (
          //         <Card style={{ marginTop: 16 }}>
          //           {chartType === "pie" && (
          //             <Pie data={chartData} angleField="value" colorField="type" radius={0.9} />
          //           )}
          //           {chartType === "bar" && (
          //             <Bar
          //               data={chartData}
          //               xField="value"
          //               yField="type"
          //               seriesField="type"
          //               label={{ position: "middle" }}
          //               tooltip={{ showTitle: true }}
          //             />
          //           )}
          //         </Card>
          //       )}
          //     </div>
          //   );
          // };


// import { useEffect, useState } from "react";
// import {
//   Table,
//   DatePicker,
//   Input,
//   Button,
//   Form,
//   message,
//   Select,
//   Card,
//   Space,
// } from "antd";
// import type { ColumnType } from "antd/es/table";
// import dayjs from "dayjs";
// import { Pie, Bar } from "@ant-design/plots";
// import { exportToExcel, exportToCSV } from "../utils/export";

// type ReportRow = Record<string, any>;

// interface GroupedRow {
//   Group: string;
//   Total: number;
//   children: ReportRow[];
// }

// interface GenericReportPageProps {
//   resourceName: string;
//   apiBaseUrl: string;
//   fields: string[];
// }

// export const GenericReportPage: React.FC<GenericReportPageProps> = ({
//   resourceName,
//   apiBaseUrl,
//   fields,
// }) => {
//   const [form] = Form.useForm();
//   const [data, setData] = useState<ReportRow[]>([]);
//   const [grouped, setGrouped] = useState<GroupedRow[]>([]);
//   const [loading, setLoading] = useState(false);

//   const [groupBy, setGroupBy] = useState<string | null>(null);
//   const [aggCol, setAggCol] = useState<string | null>(null);
//   const [aggType, setAggType] = useState<"SUM" | "AVG" | "COUNT">("SUM");
//   const [chartType, setChartType] = useState<"none" | "pie" | "bar">("none");

//   const endpoint = `${apiBaseUrl}/procedures/${resourceName}`;

//   // Default filters
//   useEffect(() => {
//     const defaults: Record<string, any> = {};
//     fields.forEach((f) => {
//       const key = f.toLowerCase();
//       if (key.includes("date")) defaults[f] = dayjs();
//       if (key.includes("company")) defaults[f] = 1;
//     });
//     form.setFieldsValue(defaults);
//   }, [fields, form]);

//   const buildRequestBody = () => {
//     const values = form.getFieldsValue();
//     const body: Record<string, any> = {};
//     Object.keys(values).forEach((k) => {
//       const v = values[k];
//       body[k] = dayjs.isDayjs(v) ? v.format("YYYY-MM-DD") : v;
//     });
//     return body;
//   };

//   const loadReport = async () => {
//     setLoading(true);
//     setData([]);
//     setGrouped([]);
//     setGroupBy(null);
//     setAggCol(null);
//     setAggType("SUM");
//     setChartType("none");

//     try {
//       const res = await fetch(endpoint, {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify(buildRequestBody()),
//       });

//       if (!res.ok) throw new Error("Failed to load report");
//       const json = await res.json();
//       setData(json);
//     } catch (err: any) {
//       message.error(err.message);
//     } finally {
//       setLoading(false);
//     }
//   };

//   // Group & aggregate
//   useEffect(() => {
//     if (!groupBy || !aggCol || data.length === 0) {
//       setGrouped([]);
//       return;
//     }

//     const map: Record<string, { total: number; count: number; children: ReportRow[] }> = {};

//     data.forEach((row) => {
//       if (!row || row[groupBy] == null) return;

//       const key = String(row[groupBy]);
//       if (!map[key]) map[key] = { total: 0, count: 0, children: [] };

//       map[key].children.push(row);

//       const val = parseFloat(String(row[aggCol]).replace(/,/g, ""));
//       if (!isNaN(val)) {
//         if (aggType === "SUM" || aggType === "AVG") map[key].total += val;
//         if (aggType === "COUNT") map[key].count++;
//         if (aggType === "AVG") map[key].count++;
//       }
//     });

//     const result: GroupedRow[] = Object.keys(map).map((k) => {
//       const e = map[k];
//       const total =
//         aggType === "AVG"
//           ? e.count > 0
//             ? e.total / e.count
//             : 0
//           : aggType === "COUNT"
//           ? e.count
//           : e.total;

//       return { Group: k, Total: total, children: e.children };
//     });

//     setGrouped(result);
//   }, [data, groupBy, aggCol, aggType]);

//   const columns: ColumnType<ReportRow>[] =
//     data.length > 0
//       ? Object.keys(data[0]).map((k) => ({
//           title: k,
//           dataIndex: k,
//           key: k,
//           sorter: (a, b) =>
//             typeof a[k] === "number" && typeof b[k] === "number"
//               ? a[k] - b[k]
//               : String(a[k]).localeCompare(String(b[k])),
//         }))
//       : [];

//   const chartData = grouped.map((g) => ({ type: g.Group, value: g.Total }));

//   const getTotals = (rows: ReportRow[]) => {
//     const totals: Record<string, number> = {};
//     rows.forEach((r) =>
//       columns.forEach((c) => {
//         if ("dataIndex" in c) {
//           const v = parseFloat(String(r[c.dataIndex as string]).replace(/,/g, ""));
//           totals[c.dataIndex as string] = (totals[c.dataIndex as string] || 0) + (isNaN(v) ? 0 : v);
//         }
//       })
//     );
//     return totals;
//   };

//   const exportData =
//     grouped.length > 0
//       ? grouped.flatMap((g) => g.children.map((c) => ({ Group: g.Group, ...c })))
//       : data;

//   return (
//     <div>
//       <h2>{resourceName.toUpperCase()}</h2>

//       <Form form={form} layout="inline" onFinish={loadReport}>
//         {fields.map((f) => (
//           <Form.Item key={f} name={f} label={f}>
//             {f.toLowerCase().includes("date") ? <DatePicker /> : <Input />}
//           </Form.Item>
//         ))}
//         <Button type="primary" htmlType="submit" loading={loading}>
//           Run Report
//         </Button>
//       </Form>

//       {data.length > 0 && (
//         <Card style={{ marginTop: 16 }}>
//           <Space>
//             <Select
//               placeholder="Group By"
//               value={groupBy}
//               onChange={setGroupBy}
//               allowClear
//               style={{ width: 180 }}
//             >
//               {columns.map((c) => (
//                 <Select.Option
//                   key={String(c.key ?? c.dataIndex)}
//                   value={String(c.dataIndex)}
//                 >
//                   {typeof c.title === "function" ? c.title({} as any) : c.title}
//                 </Select.Option>
//               ))}
//             </Select>

//             <Select
//               placeholder="Aggregate Column"
//               value={aggCol}
//               onChange={setAggCol}
//               style={{ width: 180 }}
//             >
//               {columns.map((c) => (
//                 <Select.Option
//                   key={String(c.key ?? c.dataIndex)}
//                   value={String(c.dataIndex)}
//                 >
//                   {typeof c.title === "function" ? c.title({} as any) : c.title}
//                 </Select.Option>
//               ))}
//             </Select>

//             <Select value={aggType} onChange={setAggType} style={{ width: 120 }}>
//               <Select.Option value="SUM">SUM</Select.Option>
//               <Select.Option value="AVG">AVG</Select.Option>
//               <Select.Option value="COUNT">COUNT</Select.Option>
//             </Select>

//             <Select
//               value={chartType}
//               onChange={setChartType}
//               style={{ width: 120 }}
//             >
//               <Select.Option value="none">None</Select.Option>
//               <Select.Option value="pie">Pie</Select.Option>
//               <Select.Option value="bar">Bar</Select.Option>
//             </Select>

//             <Button onClick={() => exportToExcel(exportData, resourceName)}>
//               Export Excel
//             </Button>
//             <Button onClick={() => exportToCSV(exportData, resourceName)}>
//               Export CSV
//             </Button>
//           </Space>
//         </Card>
//       )}

//  <Table
//   style={{ marginTop: 16 }}
//   dataSource={grouped.length ? grouped : data}
//   columns={
//     grouped.length
//       ? [
//           { title: "Group", dataIndex: "Group", key: "Group" },
//           { title: "Total", dataIndex: "Total", key: "Total" },
//         ]
//       : columns
//   }
//   expandable={
//     grouped.length
//       ? {
//           expandedRowRender: (record, parentIndex) => {
//             // Only keep valid child rows
//             const childrenRows = (record.children || []).filter(
//               (r) => r && Object.keys(r).length > 0
//             );

//             if (!childrenRows.length) return null;

//             const totals = getTotals(childrenRows);

//             return (
//               <Table
//                 dataSource={childrenRows}
//                 columns={columns}
//                 pagination={false}
//                 rowKey={(_, i) => `child-${parentIndex}-${i}`} // unique per child row
//                 summary={() => (
//                   <Table.Summary.Row>
//                     {columns.map((c, i) => {
//                       if (!("dataIndex" in c)) return null;
//                       const val = totals[c.dataIndex as string];
//                       return (
//                         <Table.Summary.Cell
//                           key={String(c.key ?? c.dataIndex)}
//                           index={i}
//                         >
//                           {val != null ? val : 0}
//                         </Table.Summary.Cell>
//                       );
//                     })}
//                   </Table.Summary.Row>
//                 )}
//               />
//             );
//           },
//         }
//       : undefined
//   }
//   // Unique parent row key
//   rowKey={(r, i) => `group-${i}-${r.Group}`}
//   loading={loading}
// />


//       {chartType !== "none" && grouped.length > 0 && (
//         <Card style={{ marginTop: 16 }}>
//           {chartType === "pie" && (
//             <Pie data={chartData} angleField="value" colorField="type" radius={0.9} />
//           )}
//           {chartType === "bar" && (
//             <Bar
//               data={chartData}
//               xField="value"
//               yField="type"
//               seriesField="type"
//               label={{ position: "middle" }}
//               tooltip={{ showTitle: true }}
//             />
//           )}
//         </Card>
//       )}
//     </div>
//   );
// };

// // src/pages/GenericReportPage.tsx
// import { useEffect, useState } from "react";
// import {
//   Table,
//   DatePicker,
//   Input,
//   Button,
//   Form,
//   message,
//   Select,
//   Card,
//   Space,
// } from "antd";
// import type { ColumnType } from "antd/es/table";
// import dayjs from "dayjs";
// import { Pie, Bar } from "@ant-design/plots";
// import { exportToExcel, exportToCSV } from "../utils/export";

// type ReportRow = Record<string, any>;

// interface GroupedRow {
//   Group: string;
//   Total: number;
//   children: ReportRow[];
// }

// interface GenericReportPageProps {
//   resourceName: string;
//   apiBaseUrl: string;
//   fields: string[];
// }

// export const GenericReportPage: React.FC<GenericReportPageProps> = ({
//   resourceName,
//   apiBaseUrl,
//   fields,
// }) => {
//   const [form] = Form.useForm();

//   const [data, setData] = useState<ReportRow[]>([]);
//   const [grouped, setGrouped] = useState<GroupedRow[]>([]);
//   const [loading, setLoading] = useState(false);

//   const [groupBy, setGroupBy] = useState<string | null>(null);
//   const [aggCol, setAggCol] = useState<string | null>(null);
//   const [aggType, setAggType] = useState<"SUM" | "AVG" | "COUNT">("SUM");
//   const [chartType, setChartType] = useState<"none" | "pie" | "bar">("none");

//   const endpoint = `${apiBaseUrl}/procedures/${resourceName}`;

//   // -------------------------------
//   // Set default filter values
//   // -------------------------------
//   useEffect(() => {
//     const defaults: Record<string, any> = {};
//     fields.forEach((f) => {
//       const key = f.toLowerCase();
//       if (key.includes("date")) defaults[f] = dayjs();
//       if (key.includes("company")) defaults[f] = 1;
//     });
//     form.setFieldsValue(defaults);
//   }, [fields, form]);

//   // -------------------------------
//   // Build request body
//   // -------------------------------
//   const buildRequestBody = () => {
//     const values = form.getFieldsValue();
//     const body: Record<string, any> = {};
//     Object.keys(values).forEach((k) => {
//       const v = values[k];
//       body[k] = dayjs.isDayjs(v) ? v.format("YYYY-MM-DD") : v;
//     });
//     return body;
//   };

//   // -------------------------------
//   // Load report data
//   // -------------------------------
//   const loadReport = async () => {
//     setLoading(true);
//     setData([]);
//     setGrouped([]);
//     setGroupBy(null);
//     setAggCol(null);
//     setAggType("SUM");
//     setChartType("none");

//     try {
//       const res = await fetch(endpoint, {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify(buildRequestBody()),
//       });

//       if (!res.ok) throw new Error("Failed to load report");
//       const json = await res.json();
//       setData(json);
//     } catch (err: any) {
//       message.error(err.message);
//     } finally {
//       setLoading(false);
//     }
//   };

//   // -------------------------------
//   // Grouping & aggregation
//   // -------------------------------
//   useEffect(() => {
//     if (!groupBy || !aggCol || data.length === 0) {
//       setGrouped([]);
//       return;
//     }

//     const map: Record<
//       string,
//       { total: number; count: number; children: ReportRow[] }
//     > = {};

//     data.forEach((row, idx) => {
//       const key = String(row[groupBy]);
//       if (!map[key]) map[key] = { total: 0, count: 0, children: [] };
//       map[key].children.push({ ...row, _rowKey: `${key}-${idx}` });

//       const val = Number(row[aggCol]) || 0;
//       if (aggType === "SUM") map[key].total += val;
//       if (aggType === "AVG") {
//         map[key].total += val;
//         map[key].count++;
//       }
//       if (aggType === "COUNT") map[key].count++;
//     });

//     const result: GroupedRow[] = Object.keys(map).map((k) => {
//       const e = map[k];
//       const total =
//         aggType === "AVG"
//           ? e.total / (e.count || 1)
//           : aggType === "COUNT"
//           ? e.count
//           : e.total;
//       return { Group: k, Total: total, children: e.children };
//     });

//     setGrouped(result);
//   }, [data, groupBy, aggCol, aggType]);

//   // -------------------------------
//   // Columns for table
//   // -------------------------------
//   const columns: ColumnType<ReportRow>[] =
//     data.length > 0
//       ? Object.keys(data[0]).map((k) => ({
//           title: k,
//           dataIndex: k,
//           key: k,
//           sorter: (a, b) =>
//             typeof a[k] === "number" && typeof b[k] === "number"
//               ? a[k] - b[k]
//               : String(a[k]).localeCompare(String(b[k])),
//         }))
//       : [];

//   // -------------------------------
//   // Totals helper
//   // -------------------------------
//   const getTotals = (rows: ReportRow[]) => {
//     const totals: Record<string, number> = {};
//     rows.forEach((r) =>
//       columns.forEach((c) => {
//         if ("dataIndex" in c) {
//           const val = Number(r[c.dataIndex as string]) || 0;
//           totals[c.dataIndex as string] =
//             (totals[c.dataIndex as string] || 0) + val;
//         }
//       })
//     );
//     return totals;
//   };

//   // -------------------------------
//   // Export data
//   // -------------------------------
//   const exportData =
//     grouped.length > 0
//       ? grouped.flatMap((g) => g.children.map((c) => ({ Group: g.Group, ...c })))
//       : data;

//   // -------------------------------
//   // Chart data
//   // -------------------------------
//   const chartData = grouped.map((g) => ({ type: g.Group, value: g.Total }));

//   return (
//     <div>
//       <h2>{resourceName.toUpperCase()}</h2>

//       {/* FILTER */}
//       <Form form={form} layout="inline" onFinish={loadReport}>
//         {fields.map((f) => (
//           <Form.Item key={f} name={f} label={f}>
//             {f.toLowerCase().includes("date") ? <DatePicker /> : <Input />}
//           </Form.Item>
//         ))}
//         <Button type="primary" htmlType="submit" loading={loading}>
//           Run Report
//         </Button>
//       </Form>

//       {/* CONTROLS */}
//       {data.length > 0 && (
//         <Card style={{ marginTop: 16 }}>
//           <Space>
//             <Select
//               placeholder="Group By"
//               value={groupBy}
//               onChange={setGroupBy}
//               allowClear
//               style={{ width: 180 }}
//             >
//               {columns.map((c) => (
//                 <Select.Option
//                   key={String(c.key ?? c.dataIndex)}
//                   value={String(c.dataIndex)}
//                 >
//                   {c.title}
//                 </Select.Option>
//               ))}
//             </Select>

//             <Select
//               placeholder="Aggregate Column"
//               value={aggCol}
//               onChange={setAggCol}
//               style={{ width: 180 }}
//             >
//               {columns.map((c) => (
//                 <Select.Option
//                   key={String(c.key ?? c.dataIndex)}
//                   value={String(c.dataIndex)}
//                 >
//                   {c.title}
//                 </Select.Option>
//               ))}
//             </Select>

//             <Select value={aggType} onChange={setAggType} style={{ width: 120 }}>
//               <Select.Option value="SUM">SUM</Select.Option>
//               <Select.Option value="AVG">AVG</Select.Option>
//               <Select.Option value="COUNT">COUNT</Select.Option>
//             </Select>

//             <Select
//               value={chartType}
//               onChange={setChartType}
//               style={{ width: 120 }}
//             >
//               <Select.Option value="none">None</Select.Option>
//               <Select.Option value="pie">Pie</Select.Option>
//               <Select.Option value="bar">Bar</Select.Option>
//             </Select>

//             <Button onClick={() => exportToExcel(exportData, resourceName)}>
//               Export Excel
//             </Button>
//             <Button onClick={() => exportToCSV(exportData, resourceName)}>
//               Export CSV
//             </Button>
//           </Space>
//         </Card>
//       )}

//       {/* TABLE */}
//       <Table
//         style={{ marginTop: 16 }}
//         dataSource={grouped.length ? grouped : data}
//         columns={
//           grouped.length
//             ? [
//                 { title: "Group", dataIndex: "Group", key: "Group" },
//                 { title: "Total", dataIndex: "Total", key: "Total" },
//               ]
//             : columns
//         }
//         expandable={
//           grouped.length
//             ? {
//                 expandedRowRender: (record: any) => {
//                   const totals = getTotals(record.children);
//                   return (
//                     <Table
//                       dataSource={record.children}
//                       columns={columns}
//                       pagination={false}
//                       rowKey={(r) => r._rowKey ?? JSON.stringify(r)}
//                       summary={() => (
//                         <Table.Summary.Row>
//                           {columns.map((c, i) => {
//                             if (!("dataIndex" in c)) return null;
//                             return (
//                               <Table.Summary.Cell
//                                 key={String(c.key ?? c.dataIndex)}
//                                 index={i}
//                               >
//                                 {totals[c.dataIndex as string]}
//                               </Table.Summary.Cell>
//                             );
//                           })}
//                         </Table.Summary.Row>
//                       )}
//                     />
//                   );
//                 },
//               }
//             : undefined
//         }
//         rowKey={(r) => r._rowKey ?? JSON.stringify(r)}
//         loading={loading}
//       />

//       {/* CHART */}
//       {chartType !== "none" && grouped.length > 0 && (
//         <Card style={{ marginTop: 16 }}>
//           {chartType === "pie" && (
//             <Pie data={chartData} angleField="value" colorField="type" radius={0.9} />
//           )}
//           {chartType === "bar" && (
//             <Bar
//               data={chartData}
//               xField="value"
//               yField="type"
//               seriesField="type"
//               label={{ position: "middle" }}
//               tooltip={{ showTitle: true }}
//             />
//           )}
//         </Card>
//       )}
//     </div>
//   );
// };

// export default GenericReportPage;
