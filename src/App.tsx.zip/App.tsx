// import { Authenticated, GitHubBanner, Refine } from "@refinedev/core";
// import { DevtoolsPanel, DevtoolsProvider } from "@refinedev/devtools";
// import { RefineKbar, RefineKbarProvider } from "@refinedev/kbar";

// import {
//   ErrorComponent,
//   ThemedLayout,
//   ThemedSider,
//   useNotificationProvider,
// } from "@refinedev/antd";
// import "@refinedev/antd/dist/reset.css";

// import routerProvider, {
//   CatchAllNavigate,
//   DocumentTitleHandler,
//   NavigateToResource,
//   UnsavedChangesNotifier,
// } from "@refinedev/react-router";
// import dataProvider from "@refinedev/simple-rest";
// import { App as AntdApp } from "antd";
// import { BrowserRouter, Outlet, Route, Routes } from "react-router";
// import { authProvider } from "./authProvider";
// import { Header } from "./components/header";
// import { ColorModeContextProvider } from "./contexts/color-mode";
// import {
//   BlogPostCreate,
//   BlogPostEdit,
//   BlogPostList,
//   BlogPostShow,
// } from "./pages/blog-posts";
// import {
//   CategoryCreate,
//   CategoryEdit,
//   CategoryList,
//   CategoryShow,
// } from "./pages/categories";
// import { ForgotPassword } from "./pages/forgotPassword";
// import { Login } from "./pages/login";
// import { Register } from "./pages/register";
// import { DashboardPage } from "./pages/dashboard";
// import { DashboardOutlined } from "@ant-design/icons";
// //import BucketMenu from "./components/sidebar/BucketMenu";
// import { CustomBucketSider } from "./components/sidebar/CustomBucketSider";
// //import dataProvider from "@refinedev/simple-rest";

// const API_URL = "http://localhost:5017/api"; // Your base URL

  // dataProvider={dataProvider("https://api.fake-rest.refine.dev")}
// src/App.tsx
// src/App.tsx
// src/App.tsx
/*import React from "react";
import { Refine, NotificationProvider } from "@refinedev/core";
import dataProviderSimpleRest from "@refinedev/simple-rest";
import { Layout } from "antd";
import { BrowserRouter, Routes, Route, Outlet, Navigate } from "react-router-dom";

import { CustomBucketSider } from "./components/sidebar/CustomBucketSider";
import { GenericCrud } from "./components/GenericCrud";
import { resources } from "./resources";

import "@refinedev/antd/dist/reset.css";

const API_URL = "http://localhost:5017/api";

// Default notification provider (built-in)
const notificationProvider: NotificationProvider = {
  open: ({ message, type }) => {
    // You can replace this with Ant Design message, toast, etc.
    console.log(type, message);
  },
};

const MainLayout = () => (
  <Layout hasSider style={{ minHeight: "100vh" }}>
    <CustomBucketSider />
    <Layout style={{ marginLeft: 280 }}>
      <Layout.Content style={{ padding: 24, background: "#f5f0f0ff", minHeight: "100vh" }}>
        <Outlet />
      </Layout.Content>
    </Layout>
  </Layout>
);

export default function App() {
  return (
    <BrowserRouter future={{ v7_startTransition: true }}>
      <Refine
        dataProvider={dataProviderSimpleRest(API_URL)}
        resources={resources}
        notificationProvider={notificationProvider}  // ← Correct way
      >
        <Routes>
          <Route element={<MainLayout />}>
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
            <Route path="/dashboard" element={
              <div style={{ padding: 80, fontSize: 48, fontWeight: "bold", color: "#1890ff", textAlign: "center" }}>
                My ERP Pro
              </div>
            } />
            <Route path="/:resource/*" element={<GenericCrud />} />
          </Route>
        </Routes>
      </Refine>
    </BrowserRouter>
  );
}
*/
/*import React from "react";
import { Refine } from "@refinedev/core";
import dataProviderSimpleRest from "@refinedev/simple-rest";
import { useNotificationProvider } from "@refinedev/antd";
import { BrowserRouter, Routes, Route, Outlet, Navigate } from "react-router-dom";

import { CustomBucketSider } from "./components/sidebar/CustomBucketSider";
import { GenericCrud } from "./components/GenericCrud";
import { resources } from "./resources";

// Import Ant Design Layout directly
import { Layout } from "antd";

import "@refinedev/antd/dist/reset.css";

const API_URL = "http://localhost:5017/api";

const MainLayout = () => (
  <Layout hasSider style={{ minHeight: "100vh" }}>
    <CustomBucketSider />
    <Layout style={{ marginLeft: 280 }}>
      <Layout.Content style={{ padding: 24, background: "#f5f5f5", minHeight: "100vh" }}>
        <Outlet />
      </Layout.Content>
    </Layout>
  </Layout>
);

export default function App() {
  return (
    <BrowserRouter>
      <Refine
        dataProvider={dataProviderSimpleRest(API_URL)}
        resources={resources}
        notificationProvider={useNotificationProvider}
      >
        <Routes>
          <Route element={<MainLayout />}>
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
            <Route path="/dashboard" element={<div style={{ padding: 60, fontSize: 42, fontWeight: "bold", color: "#1890ff" }}>My ERP Pro</div>} />
            <Route path="/:resource/*" element={<GenericCrud />} />
          </Route>
        </Routes>
      </Refine>
    </BrowserRouter>
  );
}*/
//                 {
//   name: "dashboard",
//   list: "/dashboard",
//   meta: {
//     label: "Dashboard",
//     icon: <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"><path d="M3 4a1 1 0 011-1h12a1 1 0 011 1v2a1 1 0 01-1 1H4a1 1 0 01-1-1V4zM3 10a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H4a1 1 0 01-1-1v-6zM14 9a1 1 0 00-1 1v6a1 1 0 001 1h2a1 1 0 001-1v-6a1 1 0 00-1-1h-2z"/></svg>,
//   },
// },


// src/App.tsx
import React from "react";
import { Refine } from "@refinedev/core";
import dataProviderSimpleRest from "@refinedev/simple-rest";
import { Layout } from "antd";
import {
  BrowserRouter,
  Routes,
  Route,
  Outlet,
  Navigate,
} from "react-router-dom";

import { CustomBucketSider } from "./components/sidebar/CustomBucketSider";
import { GenericCrud } from "./components/GenericCrud";
import { resources } from "./resources";

import "@refinedev/antd/dist/reset.css";
import { DashboardPage } from "./pages/dashboard";

const API_URL = "http://localhost:5017/api";

const MainLayout = () => (
  <Layout hasSider style={{ minHeight: "100vh" }}>
    <CustomBucketSider />
    <Layout style={{ marginLeft: 280 }}>
      <Layout.Content
        style={{ padding: 24, background: "#f5f5f5", minHeight: "100vh" }}
      >
        <Outlet />
      </Layout.Content>
    </Layout>
  </Layout>
);
//  <BrowserRouter future={{ v7_startTransition: true }}>
export default function App() {
  return (
   <BrowserRouter future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
      <Refine
        dataProvider={dataProviderSimpleRest(API_URL)}
        resources={resources}
        // notificationProvider is completely REMOVED (deprecated & optional)
        // Refine + Ant Design now use AntD's built-in notification automatically
      >
        <Routes>
          <Route element={<MainLayout />}>
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
            
          <Route path="/dashboard" element={<DashboardPage />} />
            <Route path="/:resource/*" element={<GenericCrud />} />
          </Route>
        </Routes>
      </Refine>
    </BrowserRouter>
  );
}