// src/App.tsx
import { useEffect, useState } from "react";
import { Layout, Menu } from "antd";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import { GenericResourcePage } from "./components/GenericResourcePage";

const { Sider, Content } = Layout;

export const App = () => {
  const [menuData, setMenuData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  // =============================
  // Load 2-Level Sidebar (Bucket → SubBucket)
  // =============================
  const loadData = async () => {
    const [bucketsRes, subBucketsRes] = await Promise.all([
      fetch("http://localhost:3000/api/Buckets"),
      fetch("http://localhost:3000/api/SubBuckets"),
    ]);

    const buckets = await bucketsRes.json();
    const subBuckets = await subBucketsRes.json();

    // Build menu: Bucket → SubBucket
    const finalMenu = buckets.map((bucket: any) => ({
      key: `bucket_${bucket.Id}`,
      label: bucket.Name,

      children: subBuckets
        .filter((sb: any) => sb.BucketId === bucket.Id)
        .map((sb: any) => ({
          key: `${sb.Name.toLowerCase()}`,
          label: (
            <Link to={`${sb.Name.toLowerCase()}`}>{sb.Name}</Link>
          ),
        })),
    }));

    setMenuData(finalMenu);
    setLoading(false);
  };

  if (loading) return <div>Loading menu...</div>;

  // Convert into AntD Menu format
  const getMenuItems = () =>
    menuData.map((bucket) => ({
      key: bucket.key,
      label: bucket.label,
      children: bucket.children,
    }));

  // =============================
  // Build Routes (SubBuckets only)
  // =============================
  const moduleRoutes = menuData.flatMap((bucket) => bucket.children);

  return (
    <BrowserRouter>
      <Layout style={{ minHeight: "100vh" }}>
        
        {/* ==============================
            SIDEBAR
        =============================== */}
        <Sider width={250}>
          <Menu mode="inline" items={getMenuItems()} />
        </Sider>

        {/* ==============================
            MAIN CONTENT AREA (Routes)
        =============================== */}
        <Layout>
          <Content style={{ padding: 20 }}>
            <Routes>

              {/* Auto-generated module routes for each SubBucket */}
              {moduleRoutes.map((route: any) => (
                <Route
                  key={route.key}
                  path={route.key}
                  element={
                    <GenericResourcePage
                      resourceName={route.label.props.children}
                      apiBaseUrl={import.meta.env.VITE_API_BASE_URL}
                      fields={[]} // You can populate Swagger fields later
                    />
                  }
                />
              ))}

              {/* Default page */}
              <Route path="/" element={<h2>Select a Module</h2>} />

            </Routes>
          </Content>
        </Layout>

      </Layout>
    </BrowserRouter>
  );
};

export default App;
