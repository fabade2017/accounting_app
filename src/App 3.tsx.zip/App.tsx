
// src/App.tsx
import { useEffect, useState } from "react";
import { Layout, Menu } from "antd";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import { getSwaggerResources, SwaggerResource } from "./utils/swaggerResources";
import { GenericResourcePage } from "./components/GenericResourcePage";

const { Sider, Content } = Layout;
export const App = () => {
    const [resources, setResources] = useState<SwaggerResource[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        getSwaggerResources().then((res) => {
            setResources(res);
            setLoading(false);
        });
    }, []);

    if (loading) return <div>Loading modules...</div>;

    return (
        <BrowserRouter>
            <Layout style={{ minHeight: "100vh" }}>
                <Sider>
                    <Menu mode="inline">
                        {resources.map((res) => (
                            <Menu.Item key={res.name}>
                                <Link to={`/${res.name}`}>{res.name}</Link>
                            </Menu.Item>
                        ))}
                    </Menu>
                </Sider>

                <Layout>
                    <Content>
                        <Routes>
                            {resources.map((res) => (
                                <Route
                                    key={res.name}
                                    path={`/${res.name}`}
                                    element={
                                        <GenericResourcePage
                                            resourceName={res.name}
                                            apiBaseUrl="http://localhost:5017/api"
                                            fields={res.fields}   // <-- NEW
                                        />
                                    }
                                />
                            ))}

                            {/* Default Page */}
                            <Route path="/" element={<h2>Select a Module</h2>} />
                        </Routes>
                    </Content>
                </Layout>
            </Layout>
        </BrowserRouter>
    );
};

export default App;

// export const App = () => {
//   console.log(JSON.stringify("resources"));

//     const [resources, setResources] = useState<any[]>([]);
// console.log(JSON.stringify(resources));
//     useEffect(() => {
//         getSwaggerResources().then(setResources);
//     }, []);

//     return (
//         <BrowserRouter>
//             <Layout style={{ minHeight: "100vh" }}>
//                 <Sider>
//                     <Menu mode="inline">
//                         {resources.map((res) => (
//                             <Menu.Item key={res.name}>
//                                 <Link to={`/${res.name}`}>{res.name}</Link>
//                             </Menu.Item>
//                         ))}
//                     </Menu>
//                 </Sider>
//                 <Layout>
//                     <Content style={{ padding: 24 }}>
//                         <Routes>
//                             {resources.map((res) => (
//                                 <Route
//                                     key={res.name}
//                                     path={`/${res.name}`}
//                                     element={<GenericResourcePage resourceName={res.name} />}
//                                 />
//                             ))}
//                         </Routes>
//                     </Content>
//                 </Layout>
//             </Layout>
//         </BrowserRouter>
//     );
// };

/*import React from "react";
import { Refine } from "@refinedev/core";
import dataProviderSimpleRest from "@refinedev/simple-rest";
import { Layout } from "antd";
import {
  BrowserRouter,
  Routes,
  Route,
  Outlet,
  Navigate,
} from "react-router-dom";

import { CustomBucketSider } from "./components/sidebar/CustomBucketSider";
import { GenericCrud } from "./components/GenericCrud";
import { resources } from "./resources";

import "@refinedev/antd/dist/reset.css";
import { DashboardPage } from "./pages/dashboard";

const API_URL = "http://localhost:5017/api";

const MainLayout = () => (
  <Layout hasSider style={{ minHeight: "100vh" }}>
    <CustomBucketSider />
    <Layout style={{ marginLeft: 280 }}>
      <Layout.Content
        style={{ padding: 24, background: "#f5f5f5", minHeight: "100vh" }}
      >
        <Outlet />
      </Layout.Content>
    </Layout>
  </Layout>
);
//  <BrowserRouter future={{ v7_startTransition: true }}>
export default function App() {
  return (
   <BrowserRouter future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
      <Refine
        dataProvider={dataProviderSimpleRest(API_URL)}
        resources={resources}
        // notificationProvider is completely REMOVED (deprecated & optional)
        // Refine + Ant Design now use AntD's built-in notification automatically
      >
        <Routes>
          <Route element={<MainLayout />}>
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
            
          <Route path="/dashboard" element={<DashboardPage />} />
            <Route path="/:resource/*" element={<GenericCrud />} />
          </Route>
        </Routes>
      </Refine>
    </BrowserRouter>
  );
}

*/