// src/App.tsx
import { useEffect, useState } from "react";
import { Layout, Menu } from "antd";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import { GenericResourcePage } from "./components/GenericResourcePage";
import { getSwaggerResources, SwaggerResource } from "./utils/swaggerResources";
import { pluralize } from "./Pluralize";
import { AdminDashboard } from "./pages/AdminDashboard";
import { ThemeEditorDashboard}  from "./pages/ThemeEditorDashboard";
import { GenericReportPage } from "./components/GenericReportPage";
import { ThemeProvider } from "./contexts/ThemeContext";
import { authProvider } from "./authProvider";
import { Login } from "./pages/login";
import { AppHeader } from "./components/AppHeader";
import { PrivateRoute } from "./components/PrivateRoute";
const { Sider, Content } = Layout;

export const App = () => {
  const token = localStorage.getItem("token");
  if (!token && window.location.pathname !== "/login") {
  return <div>Redirecting...</div>; // nothing renders
};
  const [menuData, setMenuData] = useState<any[]>([]);
  const [resources, setResources] = useState<SwaggerResource[]>([]);
  const [loading, setLoading] = useState(true);



  useEffect(() => {
    
      const token = localStorage.getItem("token");

  if (!token && window.location.pathname !== "/login") {
    window.location.href = "/login";
  }
    loadMenu();
    loadSwagger();
  }, []);

  // ------------------------------
  // Load Buckets & SubBuckets
  // ------------------------------
  const loadMenu = async () => {
    const [bucketsRes, subBucketsRes] = await Promise.all([
      
      fetch("http://localhost:3000/api/Buckets", {
  headers: { Authorization: `Bearer ${localStorage.getItem("token")}` }
}),
      fetch("http://localhost:3000/api/SubBuckets", {
  headers: { Authorization: `Bearer ${localStorage.getItem("token")}` }
}),
    ]);

    const buckets = await bucketsRes.json();
    const subBuckets = await subBucketsRes.json();

    // build 2-level hierarchy
    const menu = buckets.map((bucket: any) => ({
      key: `bucket_${bucket.Id}`,
      label: bucket.Name,
      children: subBuckets
        .filter((sb: any) => sb.BucketId === bucket.Id)
        .map((sb: any) => ({
          key: `/${sb.Name.toLowerCase()}`,
          label: <Link to={`/${sb.Name.toLowerCase()}`}>{sb.Name}</Link>,
       //   resourceName: sb.Name,
        })),
    }));
  //Add Admin Dashboard at the top
    menu.unshift({
    key: "/theme-editor",
    label: <Link to="/theme-editor">Theme Editor</Link>,
  //  resourceName: []
  });
  menu.unshift({
    key: "/admin-dashboard",
    label: <Link to="/admin-dashboard">Admin Dashboard</Link>,
  //  resourceName: []
  });


    setMenuData(menu);
  };

  // ------------------------------
  // Load Swagger Resources (for fields)
  // ------------------------------
  const loadSwagger = async () => {
    const swagger = await getSwaggerResources();
    setResources(swagger);
    setLoading(false);
  };

  if (loading) return <div>Loading modules...</div>;

  // ------------------------------
  // Extract ALL SubBucket routes
  // ------------------------------
  //const moduleRoutes = menuData.flatMap((b) => b.children ?? []);
const moduleRoutes = menuData
  .flatMap((b) => b.children ?? [])
  .map((r) => ({ ...r, resourceName: r.key.replace("/", "") })); // derive resourceName from key
  // Helper - return fields matching resourceName
 // console.log(JSON.stringify(resources));
  const getFieldsFor = (name: string) => {
    const match = resources.find(
      (r) => (r.name).toLowerCase() === pluralize(name).toLowerCase()
    );
       //console.log(name);

   // if(match?.fields) { console.log(`found: ${name}`);} else { console.log(`Not found: ${name}`)}
    return match?.fields ?? [];
  };
  const getReportFieldsFor = (name: string) => {
    const match = resources.find(
      (r) => (r.name).toLowerCase() === (name).toLowerCase()
    );
       //console.log(name);

 
         if(match?.fields) { console.log(`found Report: ${name}`);} else { console.log(`Not Available: ${name}`)};
    return match?.fields ?? [];
  };
function toReadableName(d) {
  if (!d || typeof d !== "string") return d;

  let value = d;

  // 1. Handle stored procedures (sp_*)
  if (value.toLowerCase().startsWith("sp_")) {
    value = value.substring(3); // remove "sp_"
  }

  // 2. Replace underscores with spaces
  value = value.replace(/_/g, " ");

  // 3. Insert spaces before capital letters (e.g. SalesReport → Sales Report)
  value = value.replace(/([a-z])([A-Z])/g, "$1 $2");

  // 4. Capitalize each word
  value = value.replace(/\b\w/g, (c) => c.toUpperCase());

  return value.trim();
}
const logoutUser = () => {
  localStorage.removeItem("token");
  window.location.href = "/login";
};

  return (
     <ThemeProvider>
    <BrowserRouter>
      <Layout style={{ minHeight: "100vh" }} >
        {/* Sidebar */}
        <Sider width={250}  style={{ background: "var(--sidebar-bg)" }} >
     
          {/* <Menu mode="inline" items={menuData} style={{ background: "var(--sidebar-bg)" }}/> */}
       <Menu
  mode="inline"
  style={{ background: "var(--sidebar-bg)" }}
  items={[
    ...menuData,
    {
      key: "logout",
      label: <a onClick={() => logoutUser()}>Logout</a>,
    },
  ]}
/>
        </Sider>

        {/* Main content */}
        <Layout>
           <AppHeader />
          <Content style={{
  background: "var(--background-color)",
  color: "var(--text-color)",
  minHeight: "100vh",
  padding: 20
}}>
            <Routes>
             <Route path="/admin-dashboard" element={<AdminDashboard />} />
               <Route path="/theme-editor" element={<ThemeEditorDashboard />} />
               <Route path="/login" element={<Login />} />
            
              {moduleRoutes.map((route: any) => {
                const resourceName = route.resourceName;
               if (resourceName.toLowerCase().includes("report")) {
           //       console.log(`The Reports:${resourceName}`);
           //       console.log(JSON.stringify(getFieldsFor(resourceName)));
  //  return <GenericReportPage resourceName={resourceName} apiBaseUrl={apiBaseUrl} />;
               return (
                  
                  <Route
                    key={route.key}
                    path={route.key}
                    element={
                          <PrivateRoute>
                      <GenericReportPage
                        resourceName={resourceName}
                        apiBaseUrl="http://localhost:5017/api"
                       fields={getReportFieldsFor(resourceName)} // <-- AUTO Swagger fields
                      />
                      </PrivateRoute>
                    }
                  />
                );
            
}
//return <GenericResourcePage resourceName={resourceName} apiBaseUrl={apiBaseUrl} fields={fields} />;
                return (
                  
                  <Route
                    key={route.key}
                    path={route.key}
                    element={
                      <PrivateRoute>
                      <GenericResourcePage
                        resourceName={resourceName}
                        apiBaseUrl="http://localhost:5017/api"
                        fields={getFieldsFor(resourceName)} // <-- AUTO Swagger fields
                      /></PrivateRoute>
                    }
                  />
                );
              })}

              <Route path="/" element={<h2>Select a module</h2>} />
            </Routes>
          </Content>
        </Layout>
      </Layout>
    </BrowserRouter>
    </ThemeProvider>
  );
};

export default App;
