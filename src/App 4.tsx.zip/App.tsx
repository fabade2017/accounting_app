
// src/App.tsx
import { useEffect, useState } from "react";
import { Layout, Menu } from "antd";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import { getSwaggerResources, SwaggerResource } from "./utils/swaggerResources";
import { GenericResourcePage } from "./components/GenericResourcePage";

const { Sider, Content } = Layout;
export const App = () => {
    const [resources, setResources] = useState<SwaggerResource[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        getSwaggerResources().then((res) => {
            setResources(res);
            setLoading(false);
        });
    }, []);

    if (loading) return <div>Loading modules...</div>;

    return (
        <BrowserRouter>
            <Layout style={{ minHeight: "100vh" }}>
                <Sider>
                    <Menu mode="inline">
                        {resources.map((res) => (
                            <Menu.Item key={res.name}>
                                <Link to={`/${res.name}`}>{res.name}</Link>
                            </Menu.Item>
                        ))}
                    </Menu>
                </Sider>

                <Layout>
                    <Content>
                        <Routes>
                            {resources.map((res) => (
                                <Route
                                    key={res.name}
                                    path={`/${res.name}`}
                                    element={
                                        <GenericResourcePage
                                            resourceName={res.name}
                                            apiBaseUrl="http://localhost:5017/api"
                                            fields={res.fields}   // <-- NEW
                                        />
                                    }
                                />
                            ))}

                            {/* Default Page */}
                            <Route path="/" element={<h2>Select a Module</h2>} />
                        </Routes>
                    </Content>
                </Layout>
            </Layout>
        </BrowserRouter>
    );
};

export default App;
