import React, { useEffect, useRef, useState } from "react";
import {
  Table,
  Button,
  Modal,
  Form,
  Input,
  Select,
  Space,
  message,
  Checkbox,
  Row,
  Col,
  DatePicker,
  InputNumber,
  InputRef,
} from "antd";
import { SearchOutlined } from '@ant-design/icons';
import { ColumnsType, ColumnType } from "antd/es/table";
import moment from "moment";
import Highlighter from 'react-highlight-words';

interface Props {
  resourceName: string;
  apiBaseUrl?: string;
  fields: string[];
}

interface LookupItem {
  id: string | number;
  label: string;
  [k: string]: any;
}

export const GenericResourcePage: React.FC<Props> = ({
  resourceName,
  apiBaseUrl = "",
  fields,
}) => {
  const [data, setData] = useState<Record<string, any>[]>([]);
  const [loading, setLoading] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [editingItem, setEditingItem] = useState<Record<string, any> | null>(null);
  const [lookupData, setLookupData] = useState<Record<string, LookupItem[]>>({});
  const [fieldsForLookup, setFieldsForLookup] = useState<Record<string, string[]>>({});
  const [form] = Form.useForm();
  const [showAllFields, setShowAllFields] = useState(false);
  const [rowColor, setRowColor] = useState("#ffffff");
  const loggedInUserId = Number(localStorage.getItem("userid") || 0);

  // Lookup modal state
  const [lookupModalVisible, setLookupModalVisible] = useState(false);
  const [lookupModalField, setLookupModalField] = useState<string | null>(null);
  const [lookupForm] = Form.useForm();

  const isReport = resourceName.toLowerCase().includes("report");
  const [reportParams, setReportParams] = useState<Record<string, any>>({});
  const [reportData, setReportData] = useState<any[]>([]);

  // Search and sort
  const [searchText, setSearchText] = useState('');
  const [searchedColumn, setSearchedColumn] = useState('');
  const [sortedInfo, setSortedInfo] = useState<{ columnKey?: string; order?: 'ascend' | 'descend' }>({});
  const searchInput = useRef<InputRef>(null);

  // --- Endpoint mapping for foreign keys ---
  const endpointMap: Record<string, string> = {
    invoiceId: "invoice",
    invoiceLineId: "invoicelineitems",
    supplierId: "supplier",
    supplierInvoiceLineId: "supplierinvoicelineitems",
    accountId: "bankaccount",
    userId: "user",
  };

  const lookupEndpointFromField = (f: string) => {
    const key = f.trim();
    return endpointMap[key] || f.replace(/Id$/i, "s").toLowerCase();
  };

  // --- Helpers ---
  const handleSearch = (
    selectedKeys: string[],
    confirm: (param?: any) => void,
    dataIndex: string,
  ) => {
    confirm();
    setSearchText(selectedKeys[0]);
    setSearchedColumn(dataIndex);
  };

  const handleReset = (clearFilters: () => void) => {
    clearFilters();
    setSearchText('');
  };

  const getColumnSearchProps = (dataIndex: string): ColumnType<any> => ({
    filterDropdown: ({ setSelectedKeys, selectedKeys, confirm, clearFilters }) => (
      <div style={{ padding: 8 }} onKeyDown={(e) => e.stopPropagation()}>
        <Input
          ref={searchInput}
          placeholder={`Search ${dataIndex}`}
          value={selectedKeys[0]}
          onChange={(e) => setSelectedKeys(e.target.value ? [e.target.value] : [])}
          onPressEnter={() => handleSearch(selectedKeys as string[], confirm, dataIndex)}
          style={{ marginBottom: 8, display: 'block' }}
        />
        <Space>
          <Button
            type="primary"
            onClick={() => handleSearch(selectedKeys as string[], confirm, dataIndex)}
            icon={<SearchOutlined />}
            size="small"
            style={{ width: 90 }}
          >
            OK
          </Button>
          <Button
            onClick={() => clearFilters && handleReset(clearFilters)}
            size="small"
            style={{ width: 90 }}
          >
            Reset
          </Button>
        </Space>
      </div>
    ),
    filterIcon: (filtered: boolean) => (
      <SearchOutlined style={{ color: filtered ? '#1677ff' : undefined }} />
    ),
    onFilter: (value, record) => {
      const recordValue = record[dataIndex];
      if (recordValue === null || recordValue === undefined) return false;
      return String(recordValue)
        .toLowerCase()
        .includes((value as string).toLowerCase());
    },
    onFilterDropdownOpenChange: (visible) => {
      if (visible) {
        setTimeout(() => searchInput.current?.select(), 100);
      }
    },
    render: (text) =>
      searchedColumn === dataIndex ? (
        <Highlighter
          highlightStyle={{ backgroundColor: '#ffc069', padding: 0 }}
          searchWords={[searchText]}
          autoEscape
          textToHighlight={text ? text.toString() : ''}
        />
      ) : (
        text
      ),
  });

  const shadeColor = (color: string, percent: number) => {
    let R = parseInt(color.substring(1, 3), 16);
    let G = parseInt(color.substring(3, 5), 16);
    let B = parseInt(color.substring(5, 7), 16);
    R = Math.min(255, Math.max(0, Math.round(R + R * percent)));
    G = Math.min(255, Math.max(0, Math.round(G + G * percent)));
    B = Math.min(255, Math.max(0, Math.round(B + B * percent)));
    const RR = R.toString(16).padStart(2, "0");
    const GG = G.toString(16).padStart(2, "0");
    const BB = B.toString(16).padStart(2, "0");
    return `#${RR}${GG}${BB}`;
  };

  const generateNumberField = (fieldName: string) => {
    const letters = (fieldName.match(/[A-Z]/g) || []).join("") || "";
    const datePart = moment().format("YYYYMMDD");
    const randomPart = Math.floor(Math.random() * 1_000_000_0000)
      .toString()
      .padStart(10, "0");
    return `${letters}${datePart}${randomPart}`;
  };

  // --- Fetch data ---
  const fetchData = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${apiBaseUrl}/${resourceName}`);
      const json = await res.json();
      setData(Array.isArray(json) ? json : []);
    } catch (err) {
      console.error(err);
      message.error("Failed to load data");
    } finally {
      setLoading(false);
    }
  };

  // --- Fetch lookups ---
  const fetchLookups = async () => {
    const newLookup: Record<string, LookupItem[]> = {};
    const newFieldsForLookup: Record<string, string[]> = {};

    const lookupFields = fields.filter(
      (f) =>
        f.toLowerCase().endsWith("id") ||
        f.toLowerCase().endsWith("by") ||
        f.toLowerCase().endsWith("currency") ||
        f.toLowerCase().endsWith("company")
    );

    for (const f of lookupFields) {
      const endpoint = lookupEndpointFromField(f);
      try {
        const res = await fetch(`${apiBaseUrl}/${endpoint}`);
        if (!res.ok) {
          console.warn(`Lookup fetch failed for ${endpoint}`);
          newLookup[f] = [];
          continue;
        }
        const items = await res.json();
        if (!Array.isArray(items) || items.length === 0) {
          newLookup[f] = [];
          continue;
        }

        const sample = items[0];
        const keys = Object.keys(sample);
        const labelCandidates = keys.filter((k) => /name|title|code|desc|label/i.test(k));
        const labelKeys = labelCandidates.length ? labelCandidates.slice(0, 2) : keys.slice(1, 4);

        newLookup[f] = items.map((i: any) => {
          const labelParts = labelKeys.map((k) => i[k]).filter(Boolean);
          const label = labelParts.length ? labelParts.join(" - ") : String(i[keys[0]]);
          return { id: i.id ?? i[Object.keys(i)[0]], label, ...i };
        });

        newFieldsForLookup[f] = keys;
      } catch (err) {
        console.error(`Failed to fetch lookup for ${f}`, err);
        newLookup[f] = [];
      }
    }

    setLookupData(newLookup);
    setFieldsForLookup(newFieldsForLookup);
  };

  useEffect(() => {
    if (isReport) runReport();
    else fetchData();
    fetchLookups();
  }, [resourceName]);

  // --- Other handlers: edit, delete, save, add new lookup ---
  const handleEdit = (record: Record<string, any>) => {
    setEditingItem({ ...record });
    setModalVisible(true);
  };

  const handleDelete = async (record: Record<string, any>) => {
    const rowKey = getRowKey(record);
    try {
      const res = await fetch(`${apiBaseUrl}/${resourceName}/${rowKey}`, { method: "DELETE" });
      if (!res.ok) throw new Error("delete failed");
      message.success("Deleted successfully");
    } catch (err) {
      console.error(err);
      message.error("Delete failed");
    } finally {
      fetchData();
    }
  };

  const handleSave = async (values: Record<string, any>) => {
    fields.forEach((f) => {
      if (values[f] && moment.isMoment(values[f])) values[f] = values[f].format("YYYY-MM-DD");
      if (!editingItem && f.toLowerCase().includes("by")) values[f] = loggedInUserId;
      if (!editingItem && f.toLowerCase().includes("number")) values[f] = generateNumberField(f);
    });

    let method = "POST";
    let url = `${apiBaseUrl}/${resourceName}`;
    if (editingItem) {
      method = "PUT";
      const pkField = fields[0];
      const pkValue = editingItem[pkField];
      if (pkField) delete values[pkField];
      url = `${apiBaseUrl}/${resourceName}/${pkValue}`;
    }

    try {
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(values),
      });
      if (!res.ok) throw new Error("Save failed");
      message.success("Saved successfully");
    } catch (err) {
      console.error(err);
      message.error("Save failed");
    } finally {
      setModalVisible(false);
      setEditingItem(null);
      form.resetFields();
      fetchData();
      fetchLookups();
    }
  };

  const handleAddNewLookup = async () => {
    if (!lookupModalField) return;
    try {
      const values = await lookupForm.validateFields().catch(() => null);
      let payload: Record<string, any> = {};
      if (values && Object.keys(values).length > 0) payload = values;
      else {
        const single = lookupForm.getFieldValue("name");
        payload = { name: single ?? lookupForm.getFieldValue(Object.keys(fieldsForLookup[lookupModalField] || {})[0]) ?? "" };
      }

      const endpoint = lookupEndpointFromField(lookupModalField);
      const res = await fetch(`${apiBaseUrl}/${endpoint}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!res.ok) throw new Error("create lookup failed");
      message.success("Added successfully");
      setLookupModalVisible(false);
      lookupForm.resetFields();
      await fetchLookups();
    } catch (err) {
      console.error(err);
      message.error("Failed to add lookup item");
    }
  };

  const getRowKey = (record: Record<string, any>) => {
    const idField = fields.find((f) => f.toLowerCase().endsWith("id"));
    return idField && record[idField] !== undefined ? String(record[idField]) : JSON.stringify(record);
  };

  // --- Columns with search/sort and lookup rendering ---
  const handleTableChange = (pagination: any, filters: any, sorter: any) => {
    setSortedInfo(sorter);
  };

  const columns: ColumnsType<Record<string, any>> = [
    {
      title: "Actions",
      key: "actions",
      fixed: "left" as const,
      width: 140,
      render: (_v, record) => (
        <Space>
          <Button type="link" onClick={() => handleEdit(record)}>
            Edit
          </Button>
          <Button type="link" danger onClick={() => handleDelete(record)}>
            Delete
          </Button>
        </Space>
      ),
    },
    ...fields
      .slice(0, showAllFields ? fields.length : 6)
      .map((f) => {
        const isNumberField =
          f.toLowerCase().includes("amount") ||
          f.toLowerCase().includes("price") ||
          f.toLowerCase().includes("total") ||
          f.toLowerCase().includes("qty") ||
          f.toLowerCase().includes("quantity") ||
          f.toLowerCase().includes("rate") ||
          f.toLowerCase().includes("balance") ||
          f.toLowerCase().includes("number");

        const isDateField = f.toLowerCase().includes("date") || f.toLowerCase().includes("year") || f.toLowerCase().includes("month");

        return {
          title: f,
          dataIndex: f,
          key: f,
          align: isNumberField ? ("right" as const) : ("left" as const),
          sorter: isDateField
            ? (a: any, b: any) => {
                const dateA = a[f] ? new Date(a[f]).getTime() : 0;
                const dateB = b[f] ? new Date(b[f]).getTime() : 0;
                return dateA - dateB;
              }
            : isNumberField
            ? (a: any, b: any) => (a[f] || 0) - (b[f] || 0)
            : (a: any, b: any) =>
                String(a[f] || "").localeCompare(String(b[f] || "")),
          sortOrder: sortedInfo.columnKey === f ? sortedInfo.order : undefined,
          ...getColumnSearchProps(f),
          render: (value: any) => {
            if (f.toLowerCase().endsWith("id") && lookupData[f]?.length) {
              const item = lookupData[f].find((i) => Number(i.id) === Number(value));
              return item ? item.label : value;
            }
            if ((typeof value === "number" || (!isNaN(Number(value)) && value !== "")) && isNumberField) {
              return <div style={{ textAlign: "right" }}>{Number(value).toLocaleString("en-US")}</div>;
            }
            if (isDateField && value) {
              return moment(value).format(f.toLowerCase().includes("year") ? "YYYY" : "YYYY-MM-DD");
            }
            return value?.toString() || "-";
          },
        };
      }),
  ];

  const [globalSearch, setGlobalSearch] = useState("");
  const filteredData = data.filter((item) =>
    fields.some((field) => {
      const value = item[field];
      if (value === null || value === undefined) return false;
      return String(value).toLowerCase().includes(globalSearch.toLowerCase());
    })
  );

  // --- Form render ---
  const renderFormItem = (f: string, idx: number) => {
    if (!editingItem && idx === 0) return null;
    if (editingItem && idx === 0)
      return (
        <Form.Item key={f} label={f} name={f}>
          <Input disabled />
        </Form.Item>
      );

    if (
      f.toLowerCase().endsWith("id") ||
      f.toLowerCase().endsWith("currency") ||
      f.toLowerCase().endsWith("company") ||
      f.toLowerCase().endsWith("by")
    ) {
      const options = lookupData[f]?.map((i) => ({ label: i.label, value: i.id })) || [];
      return (
        <Form.Item key={f} label={
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <span>{f}</span>
            {!f.toLowerCase().includes("by") && (
              <Button
                size="small"
                onClick={() => {
                  setLookupModalField(f);
                  setLookupModalVisible(true);
                }}
                style={{ marginLeft: 8 }}
              >
                + Add
              </Button>
            )}
          </div>
        } name={f} rules={[{ required: false }]}>
          <Select
            options={options}
            placeholder={`Select ${f}`}
            showSearch
            optionFilterProp="label"
            disabled={f.toLowerCase().includes("by")}
            allowClear
          />
        </Form.Item>
      );
    }

    // ...handle dates, numbers, checkboxes, other types as in original code
    return (
      <Form.Item key={f} label={f} name={f}>
        <Input />
      </Form.Item>
    );
  };

  return (
    <div style={{ padding: 20 }}>
      <Row style={{ marginBottom: 16 }} gutter={8} justify="space-between">
        <Col>
          <Button type="primary" onClick={() => { setModalVisible(true); setEditingItem(null); }}>
            Add {resourceName}
          </Button>
        </Col>
        <Col flex="auto" style={{ textAlign: 'right' }}>
          <Input
            placeholder="Search all records..."
            prefix={<SearchOutlined />}
            allowClear
            value={globalSearch}
            onChange={(e) => setGlobalSearch(e.target.value)}
            style={{ width: 300 }}
          />
        </Col>
        <Col>
          <Button onClick={() => setShowAllFields(p => !p)}>
            {showAllFields ? "Show Less" : "Show More Fields"}
          </Button>
        </Col>
        <Col>
          <input
            type="color"
            value={rowColor}
            onChange={(e) => setRowColor(e.target.value)}
            title="Row Color"
            style={{ width: 40, height: 32, border: "none" }}
          />
        </Col>
      </Row>

      <Table
        dataSource={globalSearch ? filteredData : data}
        columns={columns}
        rowKey={getRowKey}
        loading={loading}
        scroll={{ x: "max-content" }}
        onChange={handleTableChange}
        rowClassName={(record, index) => (index % 2 === 0 ? "even-row" : "odd-row")}
        style={{ ["--row-bg-even" as any]: rowColor, ["--row-bg-odd" as any]: shadeColor(rowColor, -0.05) } as any}
        locale={{ emptyText: `No ${resourceName} found` }}
      />

      <Modal
        title={editingItem ? `Edit ${resourceName}` : `Add ${resourceName}`}
        open={modalVisible}
        onCancel={() => { setModalVisible(false); setEditingItem(null); form.resetFields(); }}
        onOk={() => form.submit()}
        width={900}
      >
        <Form form={form} onFinish={handleSave} layout="vertical">
          <Row gutter={16}>
            {fields.map((f, idx) => (
              <Col span={8} key={f}>
                {renderFormItem(f, idx)}
              </Col>
            ))}
          </Row>
        </Form>
      </Modal>

      <Modal
        title={lookupModalField ? `Add New ${lookupModalField}` : "Add New"}
        open={lookupModalVisible}
        onCancel={() => { setLookupModalVisible(false); lookupForm.resetFields(); setLookupModalField(null); }}
        onOk={handleAddNewLookup}
        width={900}
      >
        <Form form={lookupForm} layout="vertical">
          <Row gutter={16}>
            {lookupModalField && fieldsForLookup[lookupModalField] ? (
              fieldsForLookup[lookupModalField].map((k) => (
                <Col span={8} key={k}>
                  <Form.Item name={k} label={k} rules={[{ required: k.toLowerCase().includes("name") }]}>
                    <Input />
                  </Form.Item>
                </Col>
              ))
            ) : (
              <Col span={8}>
                <Form.Item name="name" label="Name" rules={[{ required: true }]}>
                  <Input />
                </Form.Item>
              </Col>
            )}
          </Row>
        </Form>
      </Modal>

      <style>{`
        .even-row { background-color: var(--row-bg-even, #ffffff); }
        .odd-row { background-color: var(--row-bg-odd, #f9f9f9); }
      `}</style>
    </div>
  );
};

export default GenericResourcePage;
